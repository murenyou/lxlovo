<?php

/* ---------------------------------------------------------------------------
 * lxlovo Android JSON API
 * ------------------------------------------------------------------------- */

function api_input(string $key, mixed $default = null): mixed
{
    if (array_key_exists($key, $_POST)) {
        return $_POST[$key];
    }
    if (array_key_exists($key, $_GET)) {
        return $_GET[$key];
    }
    return $default;
}

function api_response(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function api_fail(string $message, int $status = 400): never
{
    api_response(['ok' => false, 'message' => $message], $status);
}

function api_require_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        api_fail('该操作需要 POST 请求。', 405);
    }
}

function api_bearer_token(): ?string
{
    $authorization = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if ($authorization === '' && function_exists('getallheaders')) {
        foreach (getallheaders() as $name => $value) {
            if (strcasecmp($name, 'Authorization') === 0) {
                $authorization = $value;
                break;
            }
        }
    }
    if (!preg_match('/Bearer\s+([a-f0-9]{64})/i', (string) $authorization, $match)) {
        return null;
    }
    return strtolower($match[1]);
}

function api_current_user(bool $touch = true): ?array
{
    static $loaded = false;
    static $user = null;
    if ($loaded) {
        return $user;
    }
    $loaded = true;
    $raw = api_bearer_token();
    if ($raw === null) {
        return null;
    }
    $user = db_one(
        "SELECT u.* FROM app_tokens t JOIN users u ON u.id = t.user_id
         WHERE t.token_hash = ? AND t.expires_at > NOW() AND u.status = 'active' LIMIT 1",
        [hash('sha256', $raw)]
    );
    if ($user && $touch) {
        db_exec('UPDATE app_tokens SET last_used_at = NOW() WHERE token_hash = ?', [hash('sha256', $raw)]);
    }
    return $user;
}

function api_require_user(): array
{
    $user = api_current_user();
    if ($user === null) {
        api_fail('请先登录。', 401);
    }
    return $user;
}

function api_issue_token(int $userId, string $deviceName = ''): string
{
    $raw = bin2hex(random_bytes(32));
    db_exec('DELETE FROM app_tokens WHERE expires_at <= NOW()');
    db_insert(
        'INSERT INTO app_tokens (user_id, token_hash, device_name, last_used_at, expires_at)
         VALUES (?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 180 DAY))',
        [$userId, hash('sha256', $raw), mb_substr($deviceName, 0, 120)]
    );
    return $raw;
}

function api_media_url(string $path): string
{
    if ($path === '') {
        return '';
    }
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    return absolute_url(media_url($path));
}

function api_badge_payload(array $badge): array
{
    return [
        'id' => (int) $badge['id'],
        'code' => $badge['code'],
        'name' => $badge['name'],
        'type' => $badge['type'],
        'color' => $badge['color'],
    ];
}

function api_badges_for(int $userId): array
{
    return array_map('api_badge_payload', user_badges($userId));
}

function api_user_payload(array $user, bool $private = false): array
{
    $levelInfo = level_progress($user);
    $payload = [
        'id' => (int) $user['id'],
        'username' => $user['username'],
        'avatar_url' => absolute_url(avatar_url($user)),
        'bio' => $user['bio'] ?? '',
        'level' => (int) $user['level'],
        'level_name' => $levelInfo['current']['name'],
        'level_color' => $levelInfo['current']['color'],
        'level_progress' => $levelInfo['progress'],
        'exp' => (int) $user['exp'],
        'to_next' => $levelInfo['to_next'],
        'badges' => api_badges_for((int) $user['id']),
        'is_admin' => is_admin($user),
        'created_at' => $user['created_at'] ?? null,
        'last_active_at' => $user['last_active_at'] ?? null,
    ];
    if ($private) {
        $payload += [
            'email' => $user['email'] ?? '',
            'email_verified' => !empty($user['email_verified_at']),
            'coins' => (int) $user['coins'],
            'checkin_streak' => (int) $user['checkin_streak'],
            'last_checkin_date' => $user['last_checkin_date'] ?? null,
            'show_official_badge' => (int) ($user['show_official_badge'] ?? 1),
            'notify_comment' => (int) ($user['notify_comment'] ?? 1),
            'notify_mention' => (int) ($user['notify_mention'] ?? 1),
            'notify_message' => (int) ($user['notify_message'] ?? 1),
            'notify_system' => (int) ($user['notify_system'] ?? 1),
            'notify_email' => (int) ($user['notify_email'] ?? 1),
        ];
    }
    return $payload;
}

function api_author_from_post(array $post): array
{
    $user = [
        'id' => (int) $post['user_id'],
        'username' => $post['username'] ?? '',
        'avatar' => $post['avatar'] ?? '',
        'bio' => $post['bio'] ?? '',
        'level' => (int) ($post['level'] ?? 0),
        'exp' => (int) ($post['exp'] ?? 0),
        'show_official_badge' => $post['show_official_badge'] ?? 1,
    ];
    $levelInfo = level_progress($user);
    return [
        'id' => $user['id'],
        'username' => $user['username'],
        'avatar_url' => absolute_url(avatar_url($user)),
        'bio' => $user['bio'],
        'level' => $levelInfo['current']['level'],
        'level_name' => $levelInfo['current']['name'],
        'level_color' => $levelInfo['current']['color'],
        'badges' => api_badges_for($user['id']),
        'is_official' => is_official_card_enabled($user['id'], $user),
    ];
}

function api_post_card(array $post): array
{
    $author = api_author_from_post($post);
    return [
        'id' => (int) $post['id'],
        'title' => $post['title'],
        'excerpt' => post_excerpt($post, 150),
        'cover_url' => api_media_url((string) ($post['cover'] ?? '')),
        'board_id' => (int) $post['board_id'],
        'board_name' => $post['board_name'] ?? '',
        'board_color' => $post['board_color'] ?? '#4F5BD5',
        'author' => $author,
        'is_pinned' => (int) ($post['is_pinned'] ?? 0) === 1,
        'is_featured' => (int) ($post['is_featured'] ?? 0) === 1,
        'is_official' => $author['is_official'],
        'views' => (int) ($post['views'] ?? 0),
        'likes' => (int) ($post['likes_count'] ?? 0),
        'favorites' => (int) ($post['favorites_count'] ?? 0),
        'comments' => (int) ($post['comments_count'] ?? 0),
        'created_at' => $post['created_at'] ?? null,
        'updated_at' => $post['updated_at'] ?? null,
    ];
}

function api_post_cards(array $posts): array
{
    preload_posts_badges($posts);
    return array_map('api_post_card', $posts);
}

function api_comment_payload(array $comment, array $likedIds = []): array
{
    $user = [
        'id' => (int) $comment['user_id'],
        'username' => $comment['username'] ?? '',
        'avatar' => $comment['avatar'] ?? '',
        'show_official_badge' => $comment['show_official_badge'] ?? 1,
        'exp' => $comment['exp'] ?? 0,
    ];
    $levelInfo = level_progress($user);
    return [
        'id' => (int) $comment['id'],
        'post_id' => (int) $comment['post_id'],
        'parent_id' => $comment['parent_id'] !== null ? (int) $comment['parent_id'] : null,
        'content' => $comment['content'],
        'is_pinned' => (int) ($comment['is_pinned'] ?? 0) === 1,
        'likes' => (int) ($comment['likes_count'] ?? 0),
        'liked' => isset($likedIds[(int) $comment['id']]),
        'created_at' => $comment['created_at'] ?? null,
        'reply_to_user_id' => !empty($comment['reply_to_user_id']) ? (int) $comment['reply_to_user_id'] : null,
        'reply_to_username' => $comment['reply_to_username'] ?? null,
        'user' => [
            'id' => $user['id'],
            'username' => $user['username'],
            'avatar_url' => absolute_url(avatar_url($user)),
            'level' => (int) $levelInfo['current']['level'],
            'level_name' => $levelInfo['current']['name'],
            'level_color' => $levelInfo['current']['color'],
            'badges' => api_badges_for($user['id']),
        ],
    ];
}

function api_home(): void
{
    $carousels = db_all('SELECT * FROM carousels WHERE enabled = 1 ORDER BY sort ASC, id ASC');
    $boards = db_all(
        "SELECT b.*, (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count
         FROM boards b WHERE b.status = 'active' ORDER BY b.sort ASC, b.id ASC"
    );
    $pinned = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.is_pinned = 1 ORDER BY p.updated_at DESC LIMIT 5");
    $latest = db_all(post_select_sql() . " WHERE p.status = 'published' ORDER BY p.created_at DESC LIMIT 10");
    $hot = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY (p.views + p.likes_count * 8 + p.comments_count * 12) DESC, p.created_at DESC LIMIT 8");
    $featured = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.is_featured = 1 ORDER BY p.updated_at DESC LIMIT 5");
    $random = db_all(post_select_sql() . " WHERE p.status = 'published' ORDER BY RAND() LIMIT 5");
    $online = db_all(
        'SELECT id, username, avatar, exp, level, last_active_at FROM users
         WHERE status = "active" AND last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
         ORDER BY last_active_at DESC LIMIT 16',
        [setting_int('online_minutes', 15)]
    );
    $announcements = db_all(
        "SELECT id, title, content, display_mode, created_at FROM announcements
         WHERE enabled = 1 AND (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at >= NOW())
         ORDER BY sort ASC, id ASC"
    );
    $stats = site_stats();
    api_response([
        'ok' => true,
        'carousels' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'title' => $item['title'],
            'subtitle' => $item['subtitle'],
            'image_url' => api_media_url($item['image']),
            'link' => $item['link'],
        ], $carousels),
        'boards' => array_map('api_board_payload', $boards),
        'pinned' => api_post_cards($pinned),
        'latest' => api_post_cards($latest),
        'hot' => api_post_cards($hot),
        'featured' => api_post_cards($featured),
        'random' => api_post_cards($random),
        'online' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'username' => $item['username'],
            'avatar_url' => absolute_url(avatar_url($item)),
            'level' => (int) $item['level'],
        ], $online),
        'announcements' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'title' => $item['title'],
            'content' => $item['content'],
            'display_mode' => $item['display_mode'],
        ], $announcements),
        'stats' => $stats,
    ]);
}

function api_board_payload(array $board): array
{
    return [
        'id' => (int) $board['id'],
        'name' => $board['name'],
        'slug' => $board['slug'],
        'description' => $board['description'],
        'icon' => $board['icon'],
        'color' => $board['color'],
        'post_count' => (int) ($board['post_count'] ?? 0),
    ];
}

function api_posts(): void
{
    $boardId = (int) api_input('board', 0);
    $q = trim((string) api_input('q', ''));
    $sort = (string) api_input('sort', 'latest');
    $page = max(1, (int) api_input('page', 1));
    $per = min(30, max(6, (int) api_input('per', 15)));
    if (!in_array($sort, ['latest', 'hot', 'featured'], true)) {
        $sort = 'latest';
    }
    $where = "p.status = 'published'";
    $params = [];
    if ($boardId > 0) {
        $where .= ' AND p.board_id = ?';
        $params[] = $boardId;
    }
    if ($q !== '') {
        $where .= ' AND (p.title LIKE ? OR p.content_text LIKE ?)';
        $params[] = like_escape($q);
        $params[] = like_escape($q);
    }
    if ($sort === 'featured') {
        $where .= ' AND p.is_featured = 1';
    }
    $order = $sort === 'hot'
        ? '(p.views + p.likes_count * 8 + p.comments_count * 12 + p.favorites_count * 6) DESC, p.created_at DESC'
        : 'p.is_pinned DESC, p.created_at DESC';
    $total = (int) db_value("SELECT COUNT(*) FROM posts p WHERE {$where}", $params, 0);
    $offset = ($page - 1) * $per;
    $posts = db_all(post_select_sql() . " WHERE {$where} ORDER BY {$order} LIMIT {$per} OFFSET {$offset}", $params);
    api_response([
        'ok' => true,
        'items' => api_post_cards($posts),
        'total' => $total,
        'page' => $page,
        'per' => $per,
        'pages' => max(1, (int) ceil($total / $per)),
        'sort' => $sort,
        'q' => $q,
    ]);
}

function api_post_detail(): void
{
    $id = (int) api_input('id', 0);
    $post = post_by_id($id, true);
    if (!$post || $post['status'] !== 'published') {
        api_fail('帖子不存在。', 404);
    }
    db_exec('UPDATE posts SET views = views + 1 WHERE id = ?', [$id]);
    $post['views'] = (int) $post['views'] + 1;
    $user = api_current_user();
    $liked = false;
    $favorited = false;
    if ($user) {
        $liked = db_value('SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND user_id = ?', [$id, (int) $user['id']], 0) > 0;
        $favorited = db_value('SELECT COUNT(*) FROM post_favorites WHERE post_id = ? AND user_id = ?', [$id, (int) $user['id']], 0) > 0;
    }
    $commentsRaw = db_all(
        "SELECT c.*, u.username, u.avatar, u.level, u.exp, u.show_official_badge, ru.username AS reply_to_username
         FROM comments c JOIN users u ON u.id = c.user_id
         LEFT JOIN users ru ON ru.id = c.reply_to_user_id
         WHERE c.post_id = ? AND c.status = 'published'
         ORDER BY c.is_pinned DESC, c.created_at ASC",
        [$id]
    );
    preload_badges(array_map(fn ($item) => (int) $item['user_id'], $commentsRaw));
    $likedIds = [];
    if ($user && $commentsRaw !== []) {
        $commentIds = array_map(fn ($item) => (int) $item['id'], $commentsRaw);
        $ph = implode(',', array_fill(0, count($commentIds), '?'));
        foreach (db_all("SELECT comment_id FROM comment_likes WHERE user_id = ? AND comment_id IN ({$ph})", array_merge([(int) $user['id']], $commentIds)) as $row) {
            $likedIds[(int) $row['comment_id']] = true;
        }
    }
    $threads = [];
    $replies = [];
    foreach ($commentsRaw as $comment) {
        $item = api_comment_payload($comment, $likedIds);
        if (empty($comment['parent_id'])) {
            $item['replies'] = [];
            $threads[(int) $comment['id']] = $item;
        } else {
            $replies[(int) $comment['parent_id']][] = $item;
        }
    }
    foreach ($replies as $parentId => $items) {
        if (isset($threads[$parentId])) {
            $threads[$parentId]['replies'] = $items;
        }
    }
    $related = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.board_id = ? AND p.id <> ? ORDER BY p.created_at DESC LIMIT 5", [(int) $post['board_id'], $id]);
    $rewardTotal = (int) db_value('SELECT COALESCE(SUM(amount), 0) FROM post_rewards WHERE post_id = ?', [$id], 0);
    $card = api_post_card($post);
    $card['content_html'] = $post['content'];
    $card['content_text'] = $post['content_text'] ?? '';
    $card['author'] = api_author_from_post($post);
    $card['liked'] = $liked;
    $card['favorited'] = $favorited;
    $card['reward_total'] = $rewardTotal;
    $card['comments_count'] = (int) $post['comments_count'];
    $card['comments'] = array_values($threads);
    $card['related'] = api_post_cards($related);
    $card['can_pin'] = $user && ((int) $post['user_id'] === (int) $user['id'] || is_admin($user) || can_moderate_board((int) $post['board_id'], $user));
    $card['can_moderate'] = $card['can_pin'];
    $card['can_edit'] = $user && can_edit_post($post, $user);
    $card['can_feature'] = $user && (is_admin($user) || is_official_user((int) $user['id']));
    api_response(['ok' => true, 'post' => $card]);
}

function api_login(): void
{
    api_require_post();
    $login = trim((string) api_input('login', ''));
    $password = (string) api_input('password', '');
    $user = find_user_by_login($login);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        api_fail('账号或密码不正确。', 401);
    }
    if ($user['status'] === 'banned') {
        api_fail('该账号已被封禁。', 403);
    }
    db_exec('UPDATE users SET last_active_at = NOW() WHERE id = ?', [(int) $user['id']]);
    $token = api_issue_token((int) $user['id'], (string) api_input('device', 'Android'));
    api_response(['ok' => true, 'token' => $token, 'user' => api_user_payload($user, true)]);
}

function api_register(): void
{
    api_require_post();
    [$ok, $message, $user] = register_user(
        (string) api_input('username', ''),
        (string) api_input('email', ''),
        (string) api_input('password', ''),
        (string) api_input('password_confirm', '')
    );
    if (!$ok || !$user) {
        api_fail($message, 422);
    }
    $token = api_issue_token((int) $user['id'], (string) api_input('device', 'Android'));
    api_response(['ok' => true, 'token' => $token, 'message' => $message, 'user' => api_user_payload($user, true)]);
}

function api_logout(): void
{
    api_require_post();
    $raw = api_bearer_token();
    if ($raw !== null) {
        db_exec('DELETE FROM app_tokens WHERE token_hash = ?', [hash('sha256', $raw)]);
    }
    api_response(['ok' => true]);
}

function api_me(): void
{
    $user = api_require_user();
    $stats = [
        'posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE user_id = ? AND status = 'published'", [(int) $user['id']], 0),
        'comments' => (int) db_value("SELECT COUNT(*) FROM comments WHERE user_id = ? AND status = 'published'", [(int) $user['id']], 0),
        'favorites' => (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE pf.user_id = ? AND p.status = 'published'", [(int) $user['id']], 0),
        'likes' => (int) db_value('SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE user_id = ? AND status = "published"', [(int) $user['id']], 0),
    ];
    $posts = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.user_id = ? ORDER BY p.created_at DESC LIMIT 6", [(int) $user['id']]);
    $rewards = db_all('SELECT streak_days, exp, coins FROM checkin_rewards ORDER BY streak_days ASC');
    $checkinHistory = db_all('SELECT checkin_date, streak, exp, coins FROM checkins WHERE user_id = ? ORDER BY checkin_date DESC LIMIT 14', [(int) $user['id']]);
    api_response([
        'ok' => true,
        'user' => api_user_payload($user, true),
        'stats' => $stats,
        'recent_posts' => api_post_cards($posts),
        'checked_in_today' => ($user['last_checkin_date'] ?? '') === date('Y-m-d'),
        'checkin_rewards' => $rewards,
        'checkin_history' => array_map(fn ($item) => [
            'date' => $item['checkin_date'],
            'streak' => (int) $item['streak'],
            'exp' => (int) $item['exp'],
            'coins' => (int) $item['coins'],
        ], $checkinHistory),
        'certifications' => api_badges_for((int) $user['id']),
        'pending_applications' => (int) db_value("SELECT COUNT(*) FROM verify_applications WHERE user_id = ? AND status = 'pending'", [(int) $user['id']], 0),
        'unread_notifications' => notification_count((int) $user['id']),
        'unread_messages' => unread_message_count((int) $user['id']),
    ]);
}

function api_checkin(): void
{
    api_require_post();
    $user = api_require_user();
    [$ok, $message, $data] = apply_checkin($user);
    if (!$ok) {
        api_fail($message, 409);
    }
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    api_response([
        'ok' => true,
        'message' => $message,
        'reward' => [
            'streak_days' => (int) ($data['streak'] ?? 0),
            'exp' => (int) ($data['exp'] ?? 0),
            'coins' => (int) ($data['coins'] ?? 0),
        ],
        'user' => api_user_payload($fresh, true),
    ]);
}

function api_post_like(): void
{
    api_require_post();
    $user = api_require_user();
    $postId = (int) api_input('post_id', 0);
    $post = post_by_id($postId);
    if (!$post || $post['status'] !== 'published') {
        api_fail('帖子不存在。', 404);
    }
    $exists = db_value('SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM post_likes WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO post_likes (post_id, user_id) VALUES (?, ?)', [$postId, (int) $user['id']]);
    }
    sync_post_counters($postId);
    api_response(['ok' => true, 'liked' => !$exists, 'count' => (int) db_value('SELECT likes_count FROM posts WHERE id = ?', [$postId], 0)]);
}

function api_post_favorite(): void
{
    api_require_post();
    $user = api_require_user();
    $postId = (int) api_input('post_id', 0);
    $post = post_by_id($postId);
    if (!$post || $post['status'] !== 'published') {
        api_fail('帖子不存在。', 404);
    }
    $exists = db_value('SELECT COUNT(*) FROM post_favorites WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM post_favorites WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO post_favorites (post_id, user_id) VALUES (?, ?)', [$postId, (int) $user['id']]);
    }
    sync_post_counters($postId);
    api_response(['ok' => true, 'favorited' => !$exists, 'count' => (int) db_value('SELECT favorites_count FROM posts WHERE id = ?', [$postId], 0)]);
}

function api_comment_create(): void
{
    api_require_post();
    $user = api_require_user();
    if (setting_bool('email_verify_required') && empty($user['email_verified_at'])) {
        api_fail('请先在网站完成邮箱验证。', 403);
    }
    $postId = (int) api_input('post_id', 0);
    $post = post_by_id($postId);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    $content = comment_text((string) api_input('content', ''));
    if ($content === '' || mb_strlen($content) > 1000) {
        api_fail('评论长度需为 1-1000 个字符。', 422);
    }
    $parentId = null;
    $replyToUserId = null;
    $parentInput = (int) api_input('parent_id', 0);
    if ($parentInput > 0) {
        $parent = comment_by_id($parentInput);
        if (!$parent || (int) $parent['post_id'] !== $postId || $parent['status'] !== 'published') {
            api_fail('回复的评论不存在。', 404);
        }
        $parentId = !empty($parent['parent_id']) ? (int) $parent['parent_id'] : (int) $parent['id'];
        $replyToUserId = (int) $parent['user_id'];
    }
    $commentId = db_insert(
        'INSERT INTO comments (post_id, user_id, parent_id, reply_to_user_id, content) VALUES (?, ?, ?, ?, ?)',
        [$postId, (int) $user['id'], $parentId, $replyToUserId, $content]
    );
    sync_post_counters($postId);
    $comment = comment_by_id($commentId) ?? [];
    notify_new_comment($post, $comment, $user);
    $fresh = db_one(
        'SELECT c.*, u.username, u.avatar, u.level, u.exp, u.show_official_badge, ru.username AS reply_to_username
         FROM comments c JOIN users u ON u.id = c.user_id LEFT JOIN users ru ON ru.id = c.reply_to_user_id
         WHERE c.id = ?',
        [$commentId]
    );
    preload_badges([(int) $user['id']]);
    api_response([
        'ok' => true,
        'comment' => api_comment_payload($fresh, []),
        'comments_count' => (int) db_value('SELECT comments_count FROM posts WHERE id = ?', [$postId], 0),
    ]);
}

function api_comment_like(): void
{
    api_require_post();
    $user = api_require_user();
    $commentId = (int) api_input('comment_id', 0);
    $comment = comment_by_id($commentId);
    if (!$comment || $comment['status'] !== 'published') {
        api_fail('评论不存在。', 404);
    }
    $exists = db_value('SELECT COUNT(*) FROM comment_likes WHERE comment_id = ? AND user_id = ?', [$commentId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?', [$commentId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO comment_likes (comment_id, user_id) VALUES (?, ?)', [$commentId, (int) $user['id']]);
    }
    $count = (int) db_value('SELECT COUNT(*) FROM comment_likes WHERE comment_id = ?', [$commentId], 0);
    db_exec('UPDATE comments SET likes_count = ? WHERE id = ?', [$count, $commentId]);
    api_response(['ok' => true, 'liked' => !$exists, 'count' => $count]);
}

function api_post_create(): void
{
    api_require_post();
    $user = api_require_user();
    if (setting_bool('email_verify_required') && empty($user['email_verified_at'])) {
        api_fail('请先在网站完成邮箱验证。', 403);
    }
    $title = trim((string) api_input('title', ''));
    $boardId = (int) api_input('board_id', 0);
    $content = trim((string) api_input('content', ''));
    $board = board_by_id($boardId);
    if (!$board || $board['status'] !== 'active') {
        api_fail('请选择有效的板块。', 422);
    }
    if (mb_strlen($title) < 2 || mb_strlen($title) > 120) {
        api_fail('标题长度需为 2-120 个字符。', 422);
    }
    if ($content === '' || mb_strlen($content) > 50000) {
        api_fail('正文不能为空，且不能超过 50000 个字符。', 422);
    }
    $html = '<p>' . nl2br(e($content)) . '</p>';
    $cover = trim((string) api_input('cover', ''));
    if ($cover !== '' && !safe_content_url($cover, true)) {
        $cover = '';
    }
    $postId = db_insert(
        'INSERT INTO posts (board_id, user_id, title, content, content_text, cover, status) VALUES (?, ?, ?, ?, ?, ?, "published")',
        [$boardId, (int) $user['id'], $title, $html, $content, $cover]
    );
    notify_mentions($html, $user, $title, url('post', ['id' => $postId]));
    api_response(['ok' => true, 'post_id' => $postId]);
}

function api_post_update(): void
{
    api_require_post();
    $user = api_require_user();
    $id = (int) api_input('id', 0);
    $post = post_by_id($id, true);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    if (!can_edit_post($post, $user)) {
        api_fail('你没有权限编辑这篇帖子。', 403);
    }
    $title = trim((string) api_input('title', ''));
    $boardId = (int) api_input('board_id', $post['board_id']);
    $content = trim((string) api_input('content', ''));
    $board = board_by_id($boardId);
    if (!$board || $board['status'] !== 'active') {
        api_fail('请选择有效的板块。', 422);
    }
    if (mb_strlen($title) < 2 || mb_strlen($title) > 120) {
        api_fail('标题长度需为 2-120 个字符。', 422);
    }
    if ($content === '' || mb_strlen($content) > 50000) {
        api_fail('正文不能为空，且不能超过 50000 个字符。', 422);
    }
    $html = '<p>' . nl2br(e($content)) . '</p>';
    $cover = $post['cover'] ?? '';
    if (array_key_exists('cover', $_POST) || array_key_exists('cover', $_GET)) {
        $cover = trim((string) api_input('cover', ''));
        if ($cover !== '' && !safe_content_url($cover, true)) {
            $cover = '';
        }
    }
    db_exec(
        'UPDATE posts SET board_id = ?, title = ?, content = ?, content_text = ?, cover = ?, updated_at = NOW() WHERE id = ?',
        [$boardId, $title, $html, $content, $cover, $id]
    );
    api_response(['ok' => true, 'post_id' => $id, 'message' => '帖子已更新。']);
}

function api_post_delete(): void
{
    api_require_post();
    $user = api_require_user();
    $id = (int) api_input('id', 0);
    $post = post_by_id($id, true);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    if (!can_edit_post($post, $user)) {
        api_fail('你没有权限删除这篇帖子。', 403);
    }
    db_exec('UPDATE posts SET status = "deleted" WHERE id = ?', [$id]);
    api_response(['ok' => true, 'message' => '帖子已删除。']);
}

function api_post_feature(): void
{
    api_require_post();
    $user = api_require_user();
    if (!is_admin($user) && !is_official_user((int) $user['id'])) {
        api_fail('只有官方认证账号可以设置精选帖子。', 403);
    }
    $postId = (int) api_input('post_id', 0);
    $post = post_by_id($postId);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    $newValue = (int) $post['is_featured'] === 1 ? 0 : 1;
    db_exec('UPDATE posts SET is_featured = ?, featured_by = ? WHERE id = ?', [$newValue, $newValue ? (int) $user['id'] : null, $postId]);
    api_response(['ok' => true, 'featured' => $newValue === 1]);
}

function api_comment_pin(): void
{
    api_require_post();
    $user = api_require_user();
    $commentId = (int) api_input('comment_id', 0);
    $comment = comment_by_id($commentId);
    if (!$comment || $comment['status'] !== 'published') {
        api_fail('评论不存在。', 404);
    }
    $post = post_by_id((int) $comment['post_id'], true);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    if ((int) $post['user_id'] !== (int) $user['id'] && !is_admin($user) && !can_moderate_board((int) $post['board_id'], $user)) {
        api_fail('只有帖主或板块管理员可以置顶评论。', 403);
    }
    $pinned = (int) $comment['is_pinned'] === 1;
    db_exec('UPDATE comments SET is_pinned = 0 WHERE post_id = ?', [(int) $post['id']]);
    if (!$pinned) {
        db_exec('UPDATE comments SET is_pinned = 1 WHERE id = ?', [$commentId]);
    }
    api_response(['ok' => true, 'pinned' => !$pinned]);
}

function api_comment_delete(): void
{
    api_require_post();
    $user = api_require_user();
    $commentId = (int) api_input('comment_id', 0);
    $comment = comment_by_id($commentId);
    if (!$comment) {
        api_fail('评论不存在。', 404);
    }
    $post = post_by_id((int) $comment['post_id'], true);
    if (!$post) {
        api_fail('帖子不存在。', 404);
    }
    $allowed = is_admin($user)
        || (int) $comment['user_id'] === (int) $user['id']
        || (int) $post['user_id'] === (int) $user['id']
        || can_moderate_board((int) $post['board_id'], $user);
    if (!$allowed) {
        api_fail('你没有权限删除这条评论。', 403);
    }
    db_exec('UPDATE comments SET status = "deleted" WHERE id = ? OR parent_id = ?', [$commentId, $commentId]);
    sync_post_counters((int) $post['id']);
    api_response(['ok' => true]);
}

function api_upload_image(): void
{
    api_require_post();
    $user = api_require_user();
    if (!can_upload_posts($user)) {
        api_fail('你的账号暂时没有上传图片的权限。', 403);
    }
    try {
        $path = upload_image($_FILES['image'] ?? [], 'post');
    } catch (RuntimeException $error) {
        api_fail($error->getMessage(), 422);
    }
    api_response(['ok' => true, 'url' => absolute_url(media_url($path)), 'path' => media_url($path)]);
}

function api_online(): void
{
    $users = db_all(
        'SELECT id, username, avatar, bio, exp, level, last_active_at FROM users
         WHERE status = "active" AND last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
         ORDER BY last_active_at DESC LIMIT 100',
        [setting_int('online_minutes', 15)]
    );
    preload_badges(array_map(fn ($user) => (int) $user['id'], $users));
    api_response([
        'ok' => true,
        'items' => array_map(fn ($user) => api_user_payload($user), $users),
        'online_minutes' => setting_int('online_minutes', 15),
    ]);
}

function api_about(): void
{
    $links = db_all('SELECT * FROM friend_links WHERE enabled = 1 ORDER BY sort ASC, id ASC');
    api_response([
        'ok' => true,
        'site_name' => setting('site_name', 'lxlovo'),
        'about_content' => setting('about_content', ''),
        'stats' => site_stats(),
        'online' => array_map(fn ($user) => api_user_payload($user), online_users(12)),
        'links' => array_map(fn ($link) => [
            'id' => (int) $link['id'],
            'name' => $link['name'],
            'url' => $link['url'],
            'description' => $link['description'],
            'tag' => $link['tag'],
        ], $links),
    ]);
}

function api_favorites(): void
{
    $user = api_require_user();
    $page = max(1, (int) api_input('page', 1));
    $per = 15;
    $offset = ($page - 1) * $per;
    $total = (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE pf.user_id = ? AND p.status = 'published'", [(int) $user['id']], 0);
    $posts = db_all(
        post_select_sql() . ' JOIN post_favorites pf ON pf.post_id = p.id
         WHERE pf.user_id = ? AND p.status = "published"
         ORDER BY pf.created_at DESC LIMIT ' . $per . ' OFFSET ' . $offset,
        [(int) $user['id']]
    );
    api_response([
        'ok' => true,
        'items' => api_post_cards($posts),
        'total' => $total,
        'page' => $page,
        'pages' => max(1, (int) ceil($total / $per)),
    ]);
}

function api_my_posts(): void
{
    $user = api_require_user();
    $page = max(1, (int) api_input('page', 1));
    $per = 15;
    $offset = ($page - 1) * $per;
    $total = (int) db_value('SELECT COUNT(*) FROM posts WHERE user_id = ? AND status <> "deleted"', [(int) $user['id']], 0);
    $posts = db_all(
        post_select_sql() . ' WHERE p.user_id = ? AND p.status <> "deleted" ORDER BY p.created_at DESC LIMIT ' . $per . ' OFFSET ' . $offset,
        [(int) $user['id']]
    );
    api_response([
        'ok' => true,
        'items' => api_post_cards($posts),
        'total' => $total,
        'page' => $page,
        'pages' => max(1, (int) ceil($total / $per)),
    ]);
}

function api_notifications(): void
{
    $user = api_require_user();
    $page = max(1, (int) api_input('page', 1));
    $per = min(50, max(10, (int) api_input('per', 20)));
    $offset = ($page - 1) * $per;
    $total = (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [(int) $user['id']], 0);
    $items = db_all(
        'SELECT n.*, u.username AS actor_name, u.avatar AS actor_avatar
         FROM notifications n LEFT JOIN users u ON u.id = n.actor_id
         WHERE n.user_id = ? ORDER BY n.created_at DESC LIMIT ' . $per . ' OFFSET ' . $offset,
        [(int) $user['id']]
    );
    api_response([
        'ok' => true,
        'items' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'type' => $item['type'],
            'message' => $item['message'],
            'link' => $item['link'],
            'is_read' => (int) $item['is_read'] === 1,
            'created_at' => $item['created_at'],
            'actor_name' => $item['actor_name'],
            'actor_avatar_url' => $item['actor_avatar'] ? absolute_url(media_url($item['actor_avatar'])) : '',
        ], $items),
        'total' => $total,
        'unread' => notification_count((int) $user['id']),
        'page' => $page,
    ]);
}

function api_notifications_read(): void
{
    api_require_post();
    $user = api_require_user();
    mark_all_notifications_read((int) $user['id']);
    api_response(['ok' => true, 'unread' => 0]);
}

function api_messages_conversations(): void
{
    $user = api_require_user();
    $uid = (int) $user['id'];
    $rows = db_all(
        'SELECT m.*, u.id AS other_id, u.username, u.avatar, u.last_active_at
         FROM messages m
         JOIN users u ON u.id = CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END
         WHERE m.sender_id = ? OR m.receiver_id = ?
         ORDER BY m.created_at DESC LIMIT 200',
        [$uid, $uid, $uid]
    );
    $conversations = [];
    foreach ($rows as $row) {
        $other = (int) $row['other_id'];
        if (!isset($conversations[$other])) {
            $conversations[$other] = $row;
        }
    }
    $unread = [];
    foreach (db_all('SELECT sender_id, COUNT(*) AS c FROM messages WHERE receiver_id = ? AND is_read = 0 GROUP BY sender_id', [$uid]) as $row) {
        $unread[(int) $row['sender_id']] = (int) $row['c'];
    }
    api_response([
        'ok' => true,
        'items' => array_map(fn ($row) => [
            'user' => [
                'id' => (int) $row['other_id'],
                'username' => $row['username'],
                'avatar_url' => absolute_url(avatar_url($row)),
                'online' => is_online($row),
            ],
            'last_message' => text_excerpt($row['content'], 60),
            'last_sender_id' => (int) $row['sender_id'],
            'last_time' => $row['created_at'],
            'unread' => $unread[(int) $row['other_id']] ?? 0,
        ], array_values($conversations)),
        'total_unread' => unread_message_count($uid),
    ]);
}

function api_messages_thread(): void
{
    $user = api_require_user();
    $uid = (int) $user['id'];
    $otherId = (int) api_input('user_id', 0);
    $other = db_one("SELECT id, username, avatar, last_active_at FROM users WHERE id = ? AND status = 'active'", [$otherId]);
    if (!$other) {
        api_fail('用户不存在。', 404);
    }
    $messages = db_all(
        'SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
         ORDER BY created_at ASC LIMIT 200',
        [$uid, $otherId, $otherId, $uid]
    );
    db_exec('UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0', [$otherId, $uid]);
    api_response([
        'ok' => true,
        'user' => [
            'id' => (int) $other['id'],
            'username' => $other['username'],
            'avatar_url' => absolute_url(avatar_url($other)),
            'online' => is_online($other),
        ],
        'items' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'sender_id' => (int) $item['sender_id'],
            'content' => $item['content'],
            'is_read' => (int) $item['is_read'] === 1,
            'created_at' => $item['created_at'],
        ], $messages),
    ]);
}

function api_messages_send(): void
{
    api_require_post();
    $user = api_require_user();
    $receiverId = (int) api_input('user_id', 0);
    $content = trim((string) api_input('content', ''));
    $receiver = db_one("SELECT * FROM users WHERE id = ? AND status = 'active'", [$receiverId]);
    if (!$receiver) {
        api_fail('收信人不存在。', 404);
    }
    if ($receiverId === (int) $user['id']) {
        api_fail('不能给自己发私信。', 422);
    }
    if ($content === '' || mb_strlen($content) > 1000) {
        api_fail('私信长度需为 1-1000 个字符。', 422);
    }
    $id = db_insert('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)', [(int) $user['id'], $receiverId, $content]);
    notify_new_message($user, $receiverId, $content);
    $message = db_one('SELECT * FROM messages WHERE id = ?', [$id]);
    api_response([
        'ok' => true,
        'message' => [
            'id' => (int) $message['id'],
            'sender_id' => (int) $message['sender_id'],
            'content' => $message['content'],
            'is_read' => (int) $message['is_read'] === 1,
            'created_at' => $message['created_at'],
        ],
    ]);
}

function api_user_detail(): void
{
    $id = (int) api_input('id', 0);
    $user = db_one('SELECT * FROM users WHERE id = ? AND status = "active"', [$id]);
    if (!$user) {
        api_fail('用户不存在。', 404);
    }
    $stats = [
        'posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE user_id = ? AND status = 'published'", [$id], 0),
        'comments' => (int) db_value("SELECT COUNT(*) FROM comments WHERE user_id = ? AND status = 'published'", [$id], 0),
        'likes' => (int) db_value('SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE user_id = ? AND status = "published"', [$id], 0),
        'favorites' => (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE p.user_id = ? AND p.status = 'published'", [$id], 0),
    ];
    $posts = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.user_id = ? ORDER BY p.created_at DESC LIMIT 10", [$id]);
    $comments = db_all(
        "SELECT c.id, c.content, c.created_at, p.id AS post_id, p.title AS post_title
         FROM comments c JOIN posts p ON p.id = c.post_id
         WHERE c.user_id = ? AND c.status = 'published' AND p.status = 'published'
         ORDER BY c.created_at DESC LIMIT 10",
        [$id]
    );
    api_response([
        'ok' => true,
        'user' => api_user_payload($user),
        'stats' => $stats,
        'posts' => api_post_cards($posts),
        'comments' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'content' => $item['content'],
            'created_at' => $item['created_at'],
            'post_id' => (int) $item['post_id'],
            'post_title' => $item['post_title'],
        ], $comments),
    ]);
}

function api_boards(): void
{
    $boards = db_all(
        "SELECT b.*, (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count
         FROM boards b WHERE b.status = 'active' ORDER BY b.sort ASC, b.id ASC"
    );
    foreach ($boards as &$board) {
        $board['latest_post'] = db_one(
            "SELECT id, title, created_at FROM posts WHERE board_id = ? AND status = 'published' ORDER BY created_at DESC LIMIT 1",
            [(int) $board['id']]
        );
        $board['moderators'] = db_all(
            'SELECT u.id, u.username, u.avatar, bm.role FROM board_moderators bm
             JOIN users u ON u.id = bm.user_id WHERE bm.board_id = ? ORDER BY bm.role ASC, bm.id ASC',
            [(int) $board['id']]
        );
    }
    unset($board);
    api_response(['ok' => true, 'items' => array_map(function ($board) {
        $payload = api_board_payload($board);
        $payload['latest_post'] = $board['latest_post'] ? [
            'id' => (int) $board['latest_post']['id'],
            'title' => $board['latest_post']['title'],
            'created_at' => $board['latest_post']['created_at'],
        ] : null;
        $payload['moderators'] = array_map(fn ($mod) => [
            'id' => (int) $mod['id'],
            'username' => $mod['username'],
            'avatar_url' => absolute_url(avatar_url($mod)),
            'role' => $mod['role'],
        ], $board['moderators']);
        return $payload;
    }, $boards)]);
}

function api_board_create(): void
{
    api_require_post();
    $user = api_require_user();
    if (!is_admin($user)) {
        api_fail('只有管理员可以创建板块。', 403);
    }
    $name = trim((string) api_input('name', ''));
    $slug = trim((string) api_input('slug', ''));
    $description = trim((string) api_input('description', ''));
    $color = trim((string) api_input('color', '#4F5BD5'));
    $icon = trim((string) api_input('icon', 'board'));
    $sort = (int) api_input('sort', 0);
    if (mb_strlen($name) < 2 || mb_strlen($name) > 40) {
        api_fail('板块名称需为 2-40 个字符。', 422);
    }
    if (!preg_match('/^[a-z0-9][a-z0-9_-]{1,59}$/i', $slug)) {
        api_fail('板块标识需为字母、数字、下划线或短横线。', 422);
    }
    if (mb_strlen($description) > 255) {
        api_fail('板块简介不能超过 255 个字符。', 422);
    }
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $color)) {
        $color = '#4F5BD5';
    }
    if (db_value('SELECT COUNT(*) FROM boards WHERE slug = ?', [$slug], 0) > 0) {
        api_fail('这个板块标识已经存在。', 409);
    }
    $id = db_insert(
        'INSERT INTO boards (name, slug, description, icon, color, sort, status) VALUES (?, ?, ?, ?, ?, ?, "active")',
        [$name, $slug, $description, mb_substr($icon, 0, 40), $color, $sort]
    );
    $board = board_by_id($id);
    api_response(['ok' => true, 'board' => api_board_payload($board)]);
}

function api_search(): void
{
    $q = trim((string) api_input('q', ''));
    if ($q === '') {
        api_response(['ok' => true, 'posts' => [], 'users' => [], 'boards' => []]);
    }
    $like = like_escape($q);
    $posts = db_all(post_select_sql() . " WHERE p.status = 'published' AND (p.title LIKE ? OR p.content_text LIKE ?) ORDER BY p.created_at DESC LIMIT 20", [$like, $like]);
    $users = db_all('SELECT * FROM users WHERE status = "active" AND (username LIKE ? OR bio LIKE ?) ORDER BY id ASC LIMIT 10', [$like, $like]);
    $boards = db_all("SELECT b.*, (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count FROM boards b WHERE b.status = 'active' AND (name LIKE ? OR description LIKE ?) LIMIT 10", [$like, $like]);
    api_response([
        'ok' => true,
        'posts' => api_post_cards($posts),
        'users' => array_map(fn ($user) => api_user_payload($user), $users),
        'boards' => array_map('api_board_payload', $boards),
    ]);
}

function api_profile_update(): void
{
    api_require_post();
    $user = api_require_user();
    $bio = trim((string) api_input('bio', $user['bio']));
    if (mb_strlen($bio) > 500) {
        api_fail('简介不能超过 500 个字符。', 422);
    }
    $showBadge = (int) api_input('show_official_badge', (int) $user['show_official_badge']);
    $notifyComment = (int) api_input('notify_comment', (int) $user['notify_comment']);
    $notifyMention = (int) api_input('notify_mention', (int) $user['notify_mention']);
    $notifyMessage = (int) api_input('notify_message', (int) $user['notify_message']);
    $notifySystem = (int) api_input('notify_system', (int) $user['notify_system']);
    $notifyEmail = (int) api_input('notify_email', (int) $user['notify_email']);
    db_exec(
        'UPDATE users SET bio = ?, show_official_badge = ?, notify_comment = ?, notify_mention = ?, notify_message = ?, notify_system = ?, notify_email = ? WHERE id = ?',
        [$bio, $showBadge ? 1 : 0, $notifyComment ? 1 : 0, $notifyMention ? 1 : 0, $notifyMessage ? 1 : 0, $notifySystem ? 1 : 0, $notifyEmail ? 1 : 0, (int) $user['id']]
    );
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    api_response(['ok' => true, 'user' => api_user_payload($fresh, true)]);
}

function api_profile_avatar(): void
{
    api_require_post();
    $user = api_require_user();
    try {
        $path = upload_image($_FILES['avatar'] ?? [], 'avatar');
    } catch (RuntimeException $error) {
        api_fail($error->getMessage(), 422);
    }
    db_exec('UPDATE users SET avatar = ? WHERE id = ?', [$path, (int) $user['id']]);
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    api_response(['ok' => true, 'user' => api_user_payload($fresh, true)]);
}

function api_password_change(): void
{
    api_require_post();
    $user = api_require_user();
    [$ok, $message] = change_password(
        $user,
        (string) api_input('old_password', ''),
        (string) api_input('new_password', ''),
        (string) api_input('new_password_confirm', '')
    );
    if (!$ok) {
        api_fail($message, 422);
    }
    api_response(['ok' => true, 'message' => $message]);
}

function api_email_change(): void
{
    api_require_post();
    $user = api_require_user();
    [$ok, $message] = change_email(
        $user,
        (string) api_input('email', ''),
        (string) api_input('password', '')
    );
    if (!$ok) {
        api_fail($message, 422);
    }
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    api_response(['ok' => true, 'message' => $message, 'user' => api_user_payload($fresh, true)]);
}

function api_email_resend(): void
{
    api_require_post();
    $user = api_require_user();
    if (!empty($user['email_verified_at'])) {
        api_fail('这个邮箱已经验证过了。', 409);
    }
    if (!rate_limit('app_resend_verify_' . (int) $user['id'], 3, 600)) {
        api_fail('发送过于频繁，请十分钟后再试。', 429);
    }
    [$ok, $message] = send_email_verification((int) $user['id']);
    if (!$ok) {
        api_fail($message, 422);
    }
    api_response(['ok' => true, 'message' => '验证邮件已发送，请到邮箱点击链接完成验证。']);
}

function api_verify_apply(): void
{
    api_require_post();
    $user = api_require_user();
    $type = (string) api_input('type', '');
    if (!in_array($type, ['user', 'sponsor'], true)) {
        api_fail('认证类型无效。', 422);
    }
    if (db_value(
        "SELECT COUNT(*) FROM verify_applications WHERE user_id = ? AND type = ? AND status = 'pending'",
        [(int) $user['id'], $type],
        0
    ) > 0) {
        api_fail('你已经提交过该认证申请，请耐心等待审核。', 409);
    }
    if ($type === 'user' && (int) $user['level'] < setting_int('user_verify_min_level', 2)) {
        api_fail('用户认证需要达到 Lv.' . setting_int('user_verify_min_level', 2) . '。', 422);
    }
    $reason = trim((string) api_input('reason', ''));
    $proof = trim((string) api_input('proof', ''));
    if (mb_strlen($reason) < 5 || mb_strlen($reason) > 1000) {
        api_fail('申请理由需为 5-1000 个字符。', 422);
    }
    if (mb_strlen($proof) > 500) {
        api_fail('补充信息不能超过 500 个字符。', 422);
    }
    $id = db_insert(
        'INSERT INTO verify_applications (user_id, type, reason, proof) VALUES (?, ?, ?, ?)',
        [(int) $user['id'], $type, $reason, $proof]
    );
    foreach (db_all("SELECT id FROM users WHERE role = 'admin' AND status = 'active'") as $admin) {
        notify_user(
            (int) $admin['id'],
            (int) $user['id'],
            'system',
            $user['username'] . ' 提交了' . ($type === 'sponsor' ? '赞助认证' : '用户认证') . '申请',
            admin_url('applications', ['id' => $id])
        );
    }
    api_response(['ok' => true, 'id' => $id, 'message' => '认证申请已提交，请耐心等待审核。']);
}

function api_verify_status(): void
{
    $user = api_require_user();
    $applications = db_all(
        'SELECT id, type, status, reason, proof, created_at, reviewed_at FROM verify_applications
         WHERE user_id = ? ORDER BY created_at DESC LIMIT 20',
        [(int) $user['id']]
    );
    api_response([
        'ok' => true,
        'certifications' => api_badges_for((int) $user['id']),
        'applications' => array_map(fn ($item) => [
            'id' => (int) $item['id'],
            'type' => $item['type'],
            'status' => $item['status'],
            'reason' => $item['reason'],
            'proof' => $item['proof'],
            'created_at' => $item['created_at'],
            'reviewed_at' => $item['reviewed_at'],
        ], $applications),
    ]);
}

function api_post_reward(): void
{
    api_require_post();
    $user = api_require_user();
    $postId = (int) api_input('post_id', 0);
    $amount = (int) api_input('amount', 0);
    $post = post_by_id($postId);
    if (!$post || $post['status'] !== 'published') {
        api_fail('帖子不存在。', 404);
    }
    if ((int) $post['user_id'] === (int) $user['id']) {
        api_fail('不能打赏自己的帖子。', 422);
    }
    if ($amount < 1 || $amount > 1000) {
        api_fail('打赏金额需在 1-1000 之间。', 422);
    }
    try {
        db_transaction(function (PDO $pdo) use ($user, $post, $amount, $postId) {
            $stmt = $pdo->prepare('SELECT coins FROM users WHERE id = ? FOR UPDATE');
            $stmt->execute([(int) $user['id']]);
            $coins = (int) $stmt->fetchColumn();
            if ($coins < $amount) {
                throw new RuntimeException('金币不足。');
            }
            $pdo->prepare('UPDATE users SET coins = coins - ? WHERE id = ?')->execute([$amount, (int) $user['id']]);
            $pdo->prepare('UPDATE users SET coins = coins + ? WHERE id = ?')->execute([$amount, (int) $post['user_id']]);
            $pdo->prepare('INSERT INTO post_rewards (post_id, user_id, amount) VALUES (?, ?, ?)')->execute([$postId, (int) $user['id'], $amount]);
        });
    } catch (RuntimeException $e) {
        api_fail($e->getMessage(), 409);
    }
    sync_post_counters($postId);
    notify_user((int) $post['user_id'], (int) $user['id'], 'reward', $user['username'] . ' 打赏了你的帖子 ' . $amount . ' 金币', url('post', ['id' => $postId]));
    $fresh = db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']]);
    api_response(['ok' => true, 'coins' => (int) $fresh['coins'], 'reward_total' => (int) db_value('SELECT COALESCE(SUM(amount), 0) FROM post_rewards WHERE post_id = ?', [$postId], 0)]);
}

function api_handle(string $action): void
{
    ensure_app_release_schema();
    switch ($action) {
        case 'app.version':
            api_response(app_update_payload(max(0, (int) api_input('version_code', 0)), (string) api_input('version_name', '')));
        case 'ping':
            api_response(['ok' => true, 'name' => 'lxlovo', 'package' => 'com.bbs.lxlovo.top', 'time' => date('c')]);
        case 'auth.login':
            api_login();
        case 'auth.register':
            api_register();
        case 'auth.logout':
            api_logout();
        case 'auth.me':
            api_response(['ok' => true, 'user' => api_user_payload(api_require_user(), true)]);
        case 'home':
            api_home();
        case 'posts':
            api_posts();
        case 'post':
            api_post_detail();
        case 'post.like':
            api_post_like();
        case 'post.favorite':
            api_post_favorite();
        case 'post.reward':
            api_post_reward();
        case 'post.create':
            api_post_create();
        case 'post.update':
            api_post_update();
        case 'post.delete':
            api_post_delete();
        case 'post.feature':
            api_post_feature();
        case 'comment.create':
            api_comment_create();
        case 'comment.like':
            api_comment_like();
        case 'comment.pin':
            api_comment_pin();
        case 'comment.delete':
            api_comment_delete();
        case 'checkin':
            api_checkin();
        case 'me':
            api_me();
        case 'notifications':
            api_notifications();
        case 'notifications.read':
            api_notifications_read();
        case 'messages.conversations':
            api_messages_conversations();
        case 'messages.thread':
            api_messages_thread();
        case 'messages.send':
            api_messages_send();
        case 'user':
            api_user_detail();
        case 'boards':
            api_boards();
        case 'board.create':
            api_board_create();
        case 'search':
            api_search();
        case 'online':
            api_online();
        case 'about':
            api_about();
        case 'favorites':
            api_favorites();
        case 'my.posts':
            api_my_posts();
        case 'upload.image':
            api_upload_image();
        case 'profile.update':
            api_profile_update();
        case 'profile.avatar':
            api_profile_avatar();
        case 'profile.password':
            api_password_change();
        case 'profile.email':
            api_email_change();
        case 'auth.email.resend':
            api_email_resend();
        case 'auth.verify.apply':
            api_verify_apply();
        case 'auth.verify.status':
            api_verify_status();
        default:
            api_fail('接口不存在。', 404);
    }
}
