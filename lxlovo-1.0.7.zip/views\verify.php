<?php
$officialCerts = array_values(array_filter($certifications, fn ($cert) => $cert['type'] === 'official'));
$userCerts = array_values(array_filter($certifications, fn ($cert) => $cert['type'] === 'user'));
$sponsorCerts = array_values(array_filter($certifications, fn ($cert) => $cert['type'] === 'sponsor'));
$userCertDef = null;
$sponsorCertDef = null;
foreach ($certDefs as $def) {
    if ($def['type'] === 'user' && $userCertDef === null) {
        $userCertDef = $def;
    }
    if ($def['type'] === 'sponsor' && $sponsorCertDef === null) {
        $sponsorCertDef = $def;
    }
}
$minLevel = setting_int('user_verify_min_level', 2);
$level = level_for_user($profile);
$canApplyUser = (int) $profile['level'] >= $minLevel;
$sponsorUrl = trim((string) setting('sponsor_url'));
?>
<section class="page-head">
    <div>
        <span class="page-head__eyebrow">Verification</span>
        <h1>账号认证</h1>
        <p>认证是社区身份与信任的标识。请按真实情况提交申请。</p>
    </div>
    <div class="cert-list">
        <?php foreach ($officialCerts as $cert): ?><span class="verify-badge verify-badge--official" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span><?php endforeach; ?>
        <?php foreach ($userCerts as $cert): ?><span class="verify-badge verify-badge--user" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span><?php endforeach; ?>
        <?php foreach ($sponsorCerts as $cert): ?><span class="verify-badge verify-badge--sponsor" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span><?php endforeach; ?>
    </div>
</section>

<div class="verify-grid">
    <article class="verify-card verify-card--official">
        <div class="verify-card__head">
            <span class="verify-card__icon"><?= icon('shield', '', 26) ?></span>
            <div><h2>官方认证 <span class="v-mark v-mark--blue">蓝 V</span></h2><p>由 lxlovo 官方授予的身份认证。</p></div>
        </div>
        <p class="verify-card__desc">官方认证只可以由后台授予，支持同时拥有多个官方身份。认证账号的帖子卡片会带有一抹专属颜色，可在设置中自行关闭展示。</p>
        <?php if ($officialCerts): ?>
            <div class="cert-list"><?php foreach ($officialCerts as $cert): ?><span class="verify-badge verify-badge--official" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span><?php endforeach; ?></div>
            <p class="verify-card__note"><?= icon('check', '', 15) ?>你已拥有官方认证</p>
        <?php else: ?>
            <p class="verify-card__note"><?= icon('lock', '', 15) ?>仅限官方邀请或后台授予，无法自行申请</p>
        <?php endif; ?>
    </article>

    <article class="verify-card verify-card--user">
        <div class="verify-card__head">
            <span class="verify-card__icon"><?= icon('verified', '', 26) ?></span>
            <div><h2>用户认证 <span class="v-mark v-mark--yellow">黄 V</span></h2><p>社区认可的优秀创作者。</p></div>
        </div>
        <p class="verify-card__desc"><?= nl2br(e($userCertDef['description'] ?? '在社区保持友善、原创与活跃，即可申请用户认证。')) ?></p>
        <?php if ($userCertDef && $userCertDef['conditions']): ?><p class="verify-card__conditions"><?= nl2br(e($userCertDef['conditions'])) ?></p><?php endif; ?>
        <div class="requirement">
            <span>等级要求</span>
            <strong class="<?= $canApplyUser ? 'is-ok' : 'is-locked' ?>">Lv.<?= $minLevel ?> <?= $canApplyUser ? icon('check', '', 15) : '（当前 Lv.' . (int) $profile['level'] . '）' ?></strong>
        </div>
        <?php if ($userCerts): ?>
            <p class="verify-card__note"><?= icon('check', '', 15) ?>你已拥有用户认证</p>
        <?php elseif (!empty($pending['user'])): ?>
            <p class="verify-card__note"><?= icon('clock', '', 15) ?>申请审核中，请耐心等待</p>
        <?php elseif ($canApplyUser): ?>
            <details class="apply-details">
                <summary class="btn btn--primary btn--full">申请用户认证</summary>
                <form action="<?= e(url('verify.apply')) ?>" method="post" class="form-stack">
                    <?= csrf_field() ?>
                    <input type="hidden" name="type" value="user">
                    <label class="field"><span class="field__label">申请理由</span><span class="field__box field__box--textarea"><textarea name="reason" rows="4" minlength="5" maxlength="1000" placeholder="介绍你的原创内容、社区贡献或擅长领域…" required></textarea></span></label>
                    <label class="field"><span class="field__label">补充链接（可选）</span><span class="field__box"><?= icon('link') ?><input type="text" name="proof" maxlength="500" placeholder="代表作链接、主页等"></span></label>
                    <button class="btn btn--primary btn--full" type="submit">提交申请</button>
                </form>
            </details>
        <?php else: ?>
            <p class="verify-card__note verify-card__note--muted"><?= icon('lock', '', 15) ?>达到 Lv.<?= $minLevel ?> 后即可申请</p>
        <?php endif; ?>
    </article>

    <article class="verify-card verify-card--sponsor">
        <div class="verify-card__head">
            <span class="verify-card__icon"><?= icon('favorite', '', 26) ?></span>
            <div><h2>赞助认证 <span class="v-mark v-mark--red">红 V</span></h2><p>支持 lxlovo 持续运营的伙伴。</p></div>
        </div>
        <p class="verify-card__desc"><?= nl2br(e(setting('sponsor_note', '完成赞助后提交申请并留下账号 ID，我们会在 3 天内核对并添加认证。'))) ?></p>
        <div class="sponsor-box">
            <span>你的账号 ID</span>
            <strong>#<?= (int) $profile['id'] ?></strong>
        </div>
        <?php if ($sponsorUrl !== ''): ?>
            <a class="btn btn--tonal btn--full" href="<?= e($sponsorUrl) ?>" target="_blank" rel="noopener"><?= icon('external', '', 17) ?>前往赞助页面</a>
        <?php endif; ?>
        <?php if ($sponsorCerts): ?>
            <p class="verify-card__note"><?= icon('check', '', 15) ?>你已拥有赞助认证</p>
        <?php elseif (!empty($pending['sponsor'])): ?>
            <p class="verify-card__note"><?= icon('clock', '', 15) ?>申请审核中，通常 3 天内完成</p>
        <?php else: ?>
            <details class="apply-details">
                <summary class="btn btn--outlined btn--full">提交赞助认证申请</summary>
                <form action="<?= e(url('verify.apply')) ?>" method="post" class="form-stack">
                    <?= csrf_field() ?>
                    <input type="hidden" name="type" value="sponsor">
                    <label class="field"><span class="field__label">赞助信息 / 理由</span><span class="field__box field__box--textarea"><textarea name="reason" rows="4" minlength="5" maxlength="1000" placeholder="请填写赞助时间、渠道、账号 ID 等信息…" required></textarea></span></label>
                    <label class="field"><span class="field__label">订单号或凭证链接（可选）</span><span class="field__box"><?= icon('link') ?><input type="text" name="proof" maxlength="500" placeholder="便于我们快速核对"></span></label>
                    <button class="btn btn--primary btn--full" type="submit">提交申请</button>
                </form>
            </details>
        <?php endif; ?>
    </article>
</div>

<section class="panel">
    <div class="panel__head"><div><h2>申请记录</h2><p>审核结果会通过站内通知与邮件告知。</p></div></div>
    <?php if ($applications): ?>
        <div class="table-wrap">
            <table class="data-table">
                <thead><tr><th>类型</th><th>理由</th><th>提交时间</th><th>状态</th><th>审核备注</th></tr></thead>
                <tbody>
                <?php foreach ($applications as $application): ?>
                    <tr>
                        <td><?= $application['type'] === 'sponsor' ? '赞助认证' : '用户认证' ?></td>
                        <td class="table-cell-clamp"><?= e(text_excerpt($application['reason'], 60)) ?></td>
                        <td><?= e(format_date($application['created_at'], 'Y-m-d H:i')) ?></td>
                        <td>
                            <?php if ($application['status'] === 'pending'): ?><span class="status-chip status-chip--warning">审核中</span>
                            <?php elseif ($application['status'] === 'approved'): ?><span class="status-chip status-chip--success">已通过</span>
                            <?php else: ?><span class="status-chip status-chip--danger">未通过</span><?php endif; ?>
                        </td>
                        <td><?= e($application['admin_note'] ?: '—') ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="empty-state empty-state--small"><?= icon('shield', '', 32) ?><h3>还没有申请记录</h3><p>选择适合你的认证类型开始申请。</p></div>
    <?php endif; ?>
</section>
