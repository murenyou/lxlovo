<?php

/* ---------------------------------------------------------------------------
 * Android 客户端版本与更新
 * ------------------------------------------------------------------------- */

function ensure_app_release_schema(): void
{
    static $ensured = false;
    if ($ensured) {
        return;
    }
    $ensured = true;
    db()->exec(
        "CREATE TABLE IF NOT EXISTS app_releases (
            id INT UNSIGNED NOT NULL AUTO_INCREMENT,
            version_name VARCHAR(40) NOT NULL,
            version_code INT UNSIGNED NOT NULL,
            download_url VARCHAR(1000) NOT NULL DEFAULT '',
            download_mode ENUM('auto','direct','page') NOT NULL DEFAULT 'auto',
            is_forced TINYINT(1) NOT NULL DEFAULT 0,
            changelog TEXT,
            is_enabled TINYINT(1) NOT NULL DEFAULT 1,
            published_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_version_code (version_code),
            KEY idx_enabled_code (is_enabled, version_code)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
    db()->exec(
        "CREATE TABLE IF NOT EXISTS app_tokens (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id INT UNSIGNED NOT NULL,
            token_hash CHAR(64) NOT NULL,
            device_name VARCHAR(120) NOT NULL DEFAULT '',
            last_used_at DATETIME DEFAULT NULL,
            expires_at DATETIME NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_token_hash (token_hash),
            KEY idx_user (user_id),
            KEY idx_expires (expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

function app_releases(bool $enabledOnly = true): array
{
    ensure_app_release_schema();
    $where = $enabledOnly ? 'WHERE is_enabled = 1' : '';
    return db_all("SELECT * FROM app_releases {$where} ORDER BY version_code DESC, id DESC");
}

function latest_app_release(): ?array
{
    $releases = app_releases(true);
    return $releases[0] ?? null;
}

function app_download_is_direct(array $release): bool
{
    $mode = $release['download_mode'] ?? 'auto';
    if ($mode === 'direct') {
        return true;
    }
    if ($mode === 'page') {
        return false;
    }
    $path = parse_url((string) ($release['download_url'] ?? ''), PHP_URL_PATH);
    return is_string($path) && (bool) preg_match('/\.apk$/i', $path);
}

function app_update_payload(int $currentCode, string $currentName = ''): array
{
    $releases = app_releases(true);
    $latest = $releases[0] ?? null;
    $newer = array_values(array_filter($releases, fn ($release) => (int) $release['version_code'] > $currentCode));
    $force = false;
    foreach ($newer as $release) {
        if ((int) $release['is_forced'] === 1) {
            $force = true;
            break;
        }
    }

    $format = function (array $release): array {
        return [
            'id' => (int) $release['id'],
            'version_name' => $release['version_name'],
            'version_code' => (int) $release['version_code'],
            'download_url' => $release['download_url'],
            'download_mode' => $release['download_mode'],
            'direct_download' => app_download_is_direct($release),
            'is_forced' => (int) $release['is_forced'] === 1,
            'changelog' => (string) ($release['changelog'] ?? ''),
            'published_at' => $release['published_at'],
        ];
    };

    $latestData = $latest ? $format($latest) : null;
    return [
        'ok' => true,
        'api_version' => 1,
        'app' => [
            'name' => setting('site_name', 'lxlovo'),
            'package' => 'com.bbs.lxlovo.top',
            'website' => 'https://bbs.lxlovo.top/',
        ],
        'current_version_code' => $currentCode,
        'current_version_name' => $currentName,
        'latest' => $latestData,
        'releases' => array_map($format, $releases),
        'update_available' => $latestData !== null && (int) $latestData['version_code'] > $currentCode,
        'force_update' => $force,
        'in_app_browser_default' => setting_bool('app_inapp_browser_default', true),
        'server_time' => date('c'),
    ];
}
