<?php
$me = current_user();
$homeRoute = 'home';
?>
<section class="hero<?= $carousels ? ' hero--carousel' : ' hero--fallback' ?>">
    <?php if ($carousels): ?>
        <div class="carousel" data-carousel aria-roledescription="轮播图">
            <div class="carousel__track">
                <?php foreach ($carousels as $index => $slide): ?>
                    <article class="carousel__slide<?= $index === 0 ? ' is-active' : '' ?>" data-slide="<?= $index ?>">
                        <img src="<?= e(media_url($slide['image'])) ?>" alt="<?= e($slide['title']) ?>" <?= $index > 0 ? 'loading="lazy"' : '' ?>>
                        <div class="carousel__shade"></div>
                        <div class="carousel__content">
                            <span class="carousel__eyebrow">lxlovo community</span>
                            <h1><?= e($slide['title']) ?></h1>
                            <?php if ($slide['subtitle'] !== ''): ?><p><?= e($slide['subtitle']) ?></p><?php endif; ?>
                            <?php if ($slide['link'] !== ''): ?>
                                <a class="btn btn--on-image" href="<?= e($slide['link']) ?>">去看看<?= icon('chevron_right', '', 18) ?></a>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
            <?php if (count($carousels) > 1): ?>
                <div class="carousel__controls">
                    <button class="carousel__arrow" type="button" data-carousel-prev aria-label="上一张"><?= icon('chevron_left') ?></button>
                    <div class="carousel__dots">
                        <?php foreach ($carousels as $index => $slide): ?>
                            <button class="carousel__dot<?= $index === 0 ? ' is-active' : '' ?>" type="button" data-carousel-dot="<?= $index ?>" aria-label="第 <?= $index + 1 ?> 张"></button>
                        <?php endforeach; ?>
                    </div>
                    <button class="carousel__arrow" type="button" data-carousel-next aria-label="下一张"><?= icon('chevron_right') ?></button>
                </div>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="hero__fallback">
            <div class="hero__glow hero__glow--one"></div>
            <div class="hero__glow hero__glow--two"></div>
            <div class="hero__copy">
                <span class="hero__eyebrow">lxlovo · open community</span>
                <h1><?= e(setting('site_tagline', '让每一次交流，都值得被看见')) ?></h1>
                <p><?= e(setting('site_description')) ?></p>
                <div class="hero__actions">
                    <a class="btn btn--primary" href="<?= e(url('posts')) ?>">开始阅读</a>
                    <a class="btn btn--outlined" href="<?= e($me ? url('publish') : url('register')) ?>">加入社区</a>
                </div>
            </div>
            <div class="hero__stat">
                <strong><?= short_number($stats['posts']) ?></strong><span>篇文章</span>
                <strong><?= short_number($stats['users']) ?></strong><span>位伙伴</span>
            </div>
        </div>
    <?php endif; ?>
</section>

<div class="home-layout">
    <div class="home-main">
        <section class="section">
            <div class="section__head">
                <div>
                    <span class="section__eyebrow">Explore</span>
                    <h2>板块</h2>
                </div>
                <a class="text-link" href="<?= e(url('boards')) ?>">全部板块<?= icon('chevron_right', '', 18) ?></a>
            </div>
            <div class="board-grid board-grid--home">
                <?php foreach (array_slice($boards, 0, 6) as $board): ?>
                    <a class="board-tile" href="<?= e(url('posts', ['board' => (int) $board['id']])) ?>" style="--board-color:<?= e($board['color']) ?>">
                        <span class="board-tile__icon"><?= icon($board['icon'] ?: 'board', '', 22) ?></span>
                        <span class="board-tile__body">
                            <strong><?= e($board['name']) ?></strong>
                            <span><?= e($board['description']) ?></span>
                        </span>
                        <span class="board-tile__count"><?= short_number((int) $board['post_count']) ?> 篇</span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>

        <?php if ($pinned): ?>
            <section class="section">
                <div class="section__head">
                    <div>
                        <span class="section__eyebrow">Pinned</span>
                        <h2>置顶</h2>
                    </div>
                </div>
                <div class="post-list">
                    <?php foreach ($pinned as $post): ?>
                        <?php $showBoard = true; $compact = true; require LXL_VIEWS . '/partials/post-card.php'; ?>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <section class="section">
            <div class="section__head">
                <div>
                    <span class="section__eyebrow">Latest</span>
                    <h2>最新发布</h2>
                </div>
                <a class="text-link" href="<?= e(url('posts')) ?>">查看全部<?= icon('chevron_right', '', 18) ?></a>
            </div>
            <?php if ($latest): ?>
                <div class="post-grid">
                    <?php foreach ($latest as $post): ?>
                        <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state">
                    <?= icon('article', '', 38) ?>
                    <h3>还没有文章</h3>
                    <p>成为第一个在这里分享的人。</p>
                    <a class="btn btn--primary" href="<?= e($me ? url('publish') : url('register')) ?>">发布文章</a>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($featured): ?>
            <section class="section">
                <div class="section__head">
                    <div>
                        <span class="section__eyebrow">Featured</span>
                        <h2>精选推荐</h2>
                    </div>
                    <a class="text-link" href="<?= e(url('posts', ['sort' => 'featured'])) ?>">更多精选<?= icon('chevron_right', '', 18) ?></a>
                </div>
                <div class="featured-strip">
                    <?php foreach ($featured as $post): ?>
                        <a class="featured-item" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>">
                            <span class="featured-item__icon"><?= icon('star', '', 20) ?></span>
                            <span class="featured-item__body">
                                <strong><?= e($post['title']) ?></strong>
                                <span><?= e($post['username']) ?> · <?= e(time_ago($post['created_at'])) ?></span>
                            </span>
                            <?= icon('chevron_right', '', 18) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    </div>

    <aside class="home-sidebar">
        <?php if ($me): ?>
            <?php $levelInfo = level_progress($me); $checkedToday = ($me['last_checkin_date'] ?? '') === date('Y-m-d'); ?>
            <section class="side-card identity-card">
                <div class="identity-card__top">
                    <img class="avatar avatar--lg" src="<?= e(avatar_url($me)) ?>" alt="">
                    <div>
                        <a class="identity-card__name" href="<?= e(url('me')) ?>"><?= e($me['username']) ?></a>
                        <?= badge_html((int) $me['id'], $me) ?>
                        <p><?= e($levelInfo['current']['name']) ?> · Lv.<?= (int) $levelInfo['current']['level'] ?></p>
                    </div>
                </div>
                <div class="level-progress">
                    <div class="level-progress__bar"><span style="width:<?= (int) $levelInfo['progress'] ?>%"></span></div>
                    <div class="level-progress__meta">
                        <span>EXP <?= (int) $me['exp'] ?></span>
                        <span><?= $levelInfo['next'] ? '距 Lv.' . (int) $levelInfo['next']['level'] . ' 还差 ' . (int) $levelInfo['to_next'] : '已达最高等级' ?></span>
                    </div>
                </div>
                <div class="identity-card__stats">
                    <span><strong><?= short_number((int) $me['coins']) ?></strong>金币</span>
                    <span><strong><?= (int) $me['checkin_streak'] ?></strong>连续签到</span>
                </div>
                <?php if (setting_bool('checkin_enabled', true)): ?>
                    <?php if ($checkedToday): ?>
                        <button class="btn btn--tonal btn--full" disabled><?= icon('check', '', 18) ?>今日已签到</button>
                    <?php else: ?>
                        <form action="<?= e(url('checkin')) ?>" method="post">
                            <?= csrf_field() ?>
                            <button class="btn btn--primary btn--full" type="submit"><?= icon('bolt', '', 18) ?>签到领金币</button>
                        </form>
                    <?php endif; ?>
                <?php endif; ?>
            </section>
        <?php else: ?>
            <section class="side-card welcome-card">
                <span class="welcome-card__mark">l</span>
                <h2>加入 <?= e(setting('site_name')) ?></h2>
                <p>注册账号，签到升级，和同频的人认真交流。</p>
                <a class="btn btn--primary btn--full" href="<?= e(url('register')) ?>">创建账号</a>
                <a class="btn btn--text btn--full" href="<?= e(url('login')) ?>">已有账号，去登录</a>
            </section>
        <?php endif; ?>

        <section class="side-card">
            <div class="side-card__head">
                <h2><?= icon('bolt', '', 18) ?>热门</h2>
                <a class="text-link" href="<?= e(url('posts', ['sort' => 'hot'])) ?>">更多</a>
            </div>
            <div class="rank-list">
                <?php foreach ($hot as $index => $post): ?>
                    <a class="rank-item" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>">
                        <span class="rank-item__num<?= $index < 3 ? ' is-top' : '' ?>"><?= $index + 1 ?></span>
                        <span class="rank-item__body">
                            <strong><?= e($post['title']) ?></strong>
                            <span><?= icon('eye', '', 13) ?><?= short_number((int) $post['views']) ?> · <?= icon('comment', '', 13) ?><?= short_number((int) $post['comments_count']) ?></span>
                        </span>
                    </a>
                <?php endforeach; ?>
                <?php if (!$hot): ?><p class="muted-text">暂时还没有热门内容。</p><?php endif; ?>
            </div>
        </section>

        <section class="side-card">
            <div class="side-card__head">
                <h2><?= icon('users', '', 18) ?>在线用户</h2>
                <span class="online-pill"><i></i><?= (int) $stats['online'] ?> 人在线</span>
            </div>
            <div class="online-list">
                <?php foreach ($online as $onlineUser): ?>
                    <a class="online-user" href="<?= e(url('user', ['id' => (int) $onlineUser['id']])) ?>" title="<?= e($onlineUser['username']) ?>">
                        <img class="avatar avatar--sm" src="<?= e(avatar_url($onlineUser)) ?>" alt="<?= e($onlineUser['username']) ?>">
                        <span></span>
                    </a>
                <?php endforeach; ?>
                <?php if (!$online): ?><p class="muted-text">此刻很安静，来成为第一个在线的人吧。</p><?php endif; ?>
            </div>
            <a class="text-link side-card__more" href="<?= e(url('online')) ?>">查看在线用户<?= icon('chevron_right', '', 16) ?></a>
        </section>

        <section class="side-card">
            <div class="side-card__head"><h2><?= icon('refresh', '', 18) ?>随机推荐</h2></div>
            <div class="mini-post-list">
                <?php foreach ($random as $post): ?>
                    <a class="mini-post" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>">
                        <span class="mini-post__title"><?= e($post['title']) ?></span>
                        <span class="mini-post__meta"><?= e($post['board_name']) ?> · <?= e(time_ago($post['created_at'])) ?></span>
                    </a>
                <?php endforeach; ?>
                <?php if (!$random): ?><p class="muted-text">暂无内容。</p><?php endif; ?>
            </div>
        </section>

        <section class="side-card community-stats">
            <div class="community-stats__grid">
                <div><strong><?= short_number($stats['users']) ?></strong><span>成员</span></div>
                <div><strong><?= short_number($stats['posts']) ?></strong><span>文章</span></div>
                <div><strong><?= short_number($stats['comments']) ?></strong><span>评论</span></div>
                <div><strong><?= short_number($stats['today_checkins']) ?></strong><span>今日签到</span></div>
            </div>
            <p class="community-stats__note">今天已有 <?= (int) $stats['today_posts'] ?> 篇新文章</p>
        </section>
    </aside>
</div>
