<?php ?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Broadcast</span><h2>系统广播</h2><p>向所有正常用户发送一条系统消息，可选择同时发送邮件。</p></div></div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>发送广播</h3><span><?= (int) $userCount ?> 位活跃用户</span></div>
        <form action="<?= e(admin_url('broadcast.send')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <label class="field"><span class="field__label">广播内容</span><span class="field__box field__box--textarea"><textarea name="message" rows="7" maxlength="500" placeholder="写下要发送给所有用户的消息…" required></textarea></span><span class="field__hint">最多 500 个字符。用户可以选择关闭系统消息，此类用户不会收到。</span></label>
            <label class="check-line"><input type="checkbox" name="send_email" value="1" <?= $emailReady ? '' : 'disabled' ?>><span>同时发送邮件提醒 <?= $emailReady ? '' : '（SMTP 未配置）' ?></span></label>
            <div class="form-actions"><button class="btn btn--primary" type="submit" data-confirm="确定向所有用户发送这条广播吗？"><?= icon('send', '', 18) ?>发送广播</button></div>
        </form>
    </section>
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>使用建议</h3></div>
        <div class="admin-note">
            <p>广播会为每位用户生成一条独立的系统通知，并出现在「通知」页面。</p>
            <p>勾选邮件后，会逐个用户发送，用户数量较多时可能需要等待较长时间。</p>
            <p>请避免频繁广播，以免打扰社区成员。</p>
        </div>
        <?php if (!$emailReady): ?><div class="notice notice--warning"><?= icon('mail', '', 18) ?>SMTP 未配置，邮件提醒不可用。<a href="<?= e(admin_url('settings') . '#email') ?>">去配置</a></div><?php endif; ?>
    </section>
</div>
