<?php
$buildUrl = function (int $page) use ($q, $status): string {
    $params = ['page' => $page];
    if ($q !== '') { $params['q'] = $q; }
    if ($status !== '') { $params['status'] = $status; }
    return admin_url('users', $params);
};
?>
<div class="admin-page-head">
    <div><span class="admin-eyebrow">People</span><h2>用户管理</h2><p>共 <?= (int) $total ?> 位用户。</p></div>
</div>

<form class="admin-filter" action="<?= e(admin_url('users')) ?>" method="get">
    <input type="hidden" name="r" value="users">
    <label class="admin-search"><?= icon('search', '', 18) ?><input type="search" name="q" value="<?= e($q) ?>" placeholder="搜索用户名、邮箱或 ID"></label>
    <select name="status">
        <option value="">全部状态</option>
        <option value="active" <?= $status === 'active' ? 'selected' : '' ?>>正常</option>
        <option value="banned" <?= $status === 'banned' ? 'selected' : '' ?>>封禁</option>
    </select>
    <button class="btn btn--primary btn--sm" type="submit">筛选</button>
    <?php if ($q !== '' || $status !== ''): ?><a class="btn btn--text btn--sm" href="<?= e(admin_url('users')) ?>">重置</a><?php endif; ?>
</form>

<section class="admin-panel">
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>用户</th><th>邮箱</th><th>等级</th><th>角色</th><th>状态</th><th>注册时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($users as $item): ?>
                <tr>
                    <td>
                        <a class="table-user" href="<?= e(admin_url('user', ['id' => (int) $item['id']])) ?>">
                            <img class="avatar avatar--xs" src="<?= e(avatar_url($item)) ?>" alt="">
                            <span><strong><?= e($item['username']) ?> <?= badge_html((int) $item['id'], $item) ?></strong><small>#<?= (int) $item['id'] ?></small></span>
                        </a>
                    </td>
                    <td><?= e($item['email'] ?: '—') ?><?= empty($item['email_verified_at']) && $item['email'] ? ' <span class="status-chip status-chip--warning">未验证</span>' : '' ?></td>
                    <td>Lv.<?= (int) $item['level'] ?> · <?= (int) $item['exp'] ?> EXP</td>
                    <td><?= $item['role'] === 'admin' ? '<span class="status-chip status-chip--violet">管理员</span>' : '用户' ?></td>
                    <td><?= $item['status'] === 'active' ? '<span class="status-chip status-chip--success">正常</span>' : '<span class="status-chip status-chip--danger">封禁</span>' ?></td>
                    <td><?= e(format_date($item['created_at'], 'Y-m-d')) ?></td>
                    <td><a class="table-action" href="<?= e(admin_url('user', ['id' => (int) $item['id']])) ?>">管理<?= icon('chevron_right', '', 15) ?></a></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (!$users): ?><div class="admin-empty">没有找到用户。</div><?php endif; ?>
    <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
</section>
