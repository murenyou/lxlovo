package com.bbs.lxlovo.top.data

import android.content.Context
import android.content.SharedPreferences

class AppPrefs(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("lxlovo_app", Context.MODE_PRIVATE)

    var useInAppBrowser: Boolean
        get() = prefs.getBoolean(KEY_IN_APP_BROWSER, true)
        set(value) = prefs.edit().putBoolean(KEY_IN_APP_BROWSER, value).apply()

    var skippedVersionCode: Int
        get() = prefs.getInt(KEY_SKIPPED_VERSION, 0)
        set(value) = prefs.edit().putInt(KEY_SKIPPED_VERSION, value).apply()

    var authToken: String?
        get() = prefs.getString(KEY_AUTH_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()

    val isLoggedIn: Boolean
        get() = !authToken.isNullOrBlank()

    val hasBrowserPreference: Boolean
        get() = prefs.contains(KEY_IN_APP_BROWSER)

    fun applyBrowserDefault(value: Boolean) {
        if (!hasBrowserPreference) {
            prefs.edit().putBoolean(KEY_IN_APP_BROWSER, value).apply()
        }
    }

    fun clearAuth() {
        prefs.edit().remove(KEY_AUTH_TOKEN).apply()
    }

    fun clearSkippedVersion() {
        prefs.edit().remove(KEY_SKIPPED_VERSION).apply()
    }

    companion object {
        private const val KEY_IN_APP_BROWSER = "use_in_app_browser"
        private const val KEY_SKIPPED_VERSION = "skipped_version_code"
        private const val KEY_AUTH_TOKEN = "auth_token"
    }
}
