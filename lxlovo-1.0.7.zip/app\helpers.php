<?php

/* ---------------------------------------------------------------------------
 * 基础配置与地址
 * ------------------------------------------------------------------------- */

function config(?string $key = null, mixed $default = null): mixed
{
    $config = $GLOBALS['lxl_config'] ?? [];
    if ($key === null) {
        return $config;
    }
    $value = $config;
    foreach (explode('.', $key) as $segment) {
        if (!is_array($value) || !array_key_exists($segment, $value)) {
            return $default;
        }
        $value = $value[$segment];
    }
    return $value;
}

function base_url(): string
{
    return LXL_BASE_PATH;
}

function site_origin(): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') {
        $scheme = 'https';
    }
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host;
}

function site_root_url(): string
{
    $configured = trim((string) setting('site_url', ''));
    if ($configured !== '') {
        return rtrim($configured, '/');
    }
    return site_origin() . LXL_BASE_PATH;
}

function url(string $route = 'home', array $params = []): string
{
    $url = base_url() . '/index.php?r=' . rawurlencode($route);
    if ($params !== []) {
        $url .= '&' . http_build_query($params);
    }
    return $url;
}

function admin_url(string $route = 'dashboard', array $params = []): string
{
    $url = base_url() . '/admin.php?r=' . rawurlencode($route);
    if ($params !== []) {
        $url .= '&' . http_build_query($params);
    }
    return $url;
}

function asset(string $path): string
{
    return base_url() . '/' . ltrim($path, '/');
}

function absolute_url(string $path): string
{
    if (preg_match('#^https?://#i', $path)) {
        return $path;
    }
    if ($path === '') {
        return site_root_url();
    }
    if ($path[0] === '/') {
        if (base_url() !== '' && str_starts_with($path, base_url() . '/')) {
            return site_origin() . $path;
        }
        return site_origin() . base_url() . '/' . ltrim($path, '/');
    }
    return site_root_url() . '/' . ltrim($path, '/');
}

function media_url(string $path, string $fallback = ''): string
{
    $path = trim($path);
    if ($path === '') {
        return $fallback !== '' ? $fallback : asset('assets/img/default-avatar.svg');
    }
    if (preg_match('#^https?://#i', $path) || str_starts_with($path, 'data:image/')) {
        return $path;
    }
    return base_url() . '/' . ltrim($path, '/');
}

function redirect(string $url, int $status = 302): never
{
    header('Location: ' . $url, true, $status);
    exit;
}

function redirect_back(string $fallback = 'home'): never
{
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    if ($referer !== '' && str_starts_with($referer, site_origin())) {
        redirect($referer);
    }
    redirect(url($fallback));
}

function current_url(): string
{
    return $_SERVER['REQUEST_URI'] ?? base_url() . '/';
}

function is_post(): bool
{
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}

function is_ajax(): bool
{
    return strtolower($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'xmlhttprequest';
}

function e(mixed $value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/* ---------------------------------------------------------------------------
 * 设置
 * ------------------------------------------------------------------------- */

function default_settings(): array
{
    return [
        'site_name' => 'lxlovo',
        'site_tagline' => '让每一次交流，都值得被看见',
        'site_description' => 'lxlovo 是一个开放、自由、原创的中文社区。',
        'site_keywords' => 'lxlovo,论坛,社区',
        'site_url' => '',
        'filing_info' => '',
        'footer_extra' => '',
        'theme_default' => 'light',
        'register_enabled' => '1',
        'checkin_enabled' => '1',
        'official_badge_enabled' => '1',
        'official_card_enabled' => '1',
        'online_minutes' => '15',
        'show_online_users' => '1',
        'email_verify_required' => '0',
        'email_notify_enabled' => '1',
        'smtp_host' => 'smtp.qq.com',
        'smtp_port' => '465',
        'smtp_secure' => 'ssl',
        'smtp_user' => '',
        'smtp_pass' => '',
        'smtp_from' => '',
        'smtp_from_name' => 'lxlovo',
        'upload_enabled' => '1',
        'upload_max_kb' => '100',
        'upload_roles' => 'official,sponsor',
        'upload_max_width' => '1600',
        'avatar_max_kb' => '300',
        'avatar_max_width' => '512',
        'carousel_max_kb' => '500',
        'user_verify_min_level' => '2',
        'user_verify_note' => '',
        'sponsor_url' => '',
        'sponsor_note' => '',
        'announcement_enabled' => '1',
        'app_inapp_browser_default' => '1',
        'about_content' => '',
        'post_per_page' => '12',
    ];
}

function all_settings(bool $refresh = false): array
{
    if (!$refresh && isset($GLOBALS['lxl_settings_cache'])) {
        return $GLOBALS['lxl_settings_cache'];
    }
    $settings = default_settings();
    try {
        foreach (db_all('SELECT skey, svalue FROM settings') as $row) {
            $settings[$row['skey']] = $row['svalue'];
        }
    } catch (Throwable $e) {
        // 安装前或数据表缺失时使用默认值。
    }
    $GLOBALS['lxl_settings_cache'] = $settings;
    return $settings;
}

function setting(string $key, mixed $default = ''): mixed
{
    $settings = all_settings();
    return array_key_exists($key, $settings) ? $settings[$key] : $default;
}

function setting_bool(string $key, bool $default = false): bool
{
    $value = setting($key, $default ? '1' : '0');
    return in_array((string) $value, ['1', 'true', 'on', 'yes'], true);
}

function setting_int(string $key, int $default = 0): int
{
    $value = setting($key, (string) $default);
    return is_numeric($value) ? (int) $value : $default;
}

function set_setting(string $key, mixed $value): void
{
    db_exec(
        'INSERT INTO settings (skey, svalue) VALUES (?, ?) ON DUPLICATE KEY UPDATE svalue = VALUES(svalue)',
        [$key, (string) $value]
    );
    unset($GLOBALS['lxl_settings_cache']);
}

function set_settings(array $values): void
{
    foreach ($values as $key => $value) {
        set_setting($key, $value);
    }
}

/* ---------------------------------------------------------------------------
 * 会话提示、CSRF、旧输入
 * ------------------------------------------------------------------------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['_token'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!is_string($token) || $token === '' || !hash_equals(csrf_token(), $token)) {
        http_response_code(419);
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => '页面已过期，请刷新后重试。'], 419);
        }
        echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>页面已过期</title><body style="font-family:system-ui;background:#fbf8ff;color:#1b1b21;display:grid;place-items:center;min-height:100vh;margin:0"><div style="background:#fff;padding:32px;border-radius:24px;box-shadow:0 10px 40px rgba(0,0,0,.08)"><h1 style="font-size:22px">页面已过期</h1><p>请返回上一页刷新后重试。</p><a href="' . e(url('home')) . '" style="color:#4f5bd5">返回首页</a></div></body></html>';
        exit;
    }
}

function flash(string $type, string $message): void
{
    $_SESSION['flashes'][] = ['type' => $type, 'message' => $message];
}

function take_flashes(): array
{
    $flashes = $_SESSION['flashes'] ?? [];
    unset($_SESSION['flashes']);
    return $flashes;
}

function remember_old(array $data): void
{
    unset($data['password'], $data['password_confirm'], $data['old_password'], $data['_token']);
    $_SESSION['old_input'] = $data;
}

function old(string $key, string $default = ''): string
{
    $value = $_SESSION['old_input'][$key] ?? $default;
    return is_scalar($value) ? (string) $value : $default;
}

function clear_old(): void
{
    unset($_SESSION['old_input']);
}

function fail_back(string $message, string $to, array $old = []): never
{
    flash('error', $message);
    if ($old !== []) {
        remember_old($old);
    }
    redirect($to);
}

function json_response(array $data, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

/* ---------------------------------------------------------------------------
 * 渲染
 * ------------------------------------------------------------------------- */

function render(string $view, array $data = []): void
{
    $file = LXL_VIEWS . '/' . $view . '.php';
    if (!is_file($file)) {
        http_response_code(404);
        $file = LXL_VIEWS . '/404.php';
    }
    $pageTitle = $data['pageTitle'] ?? setting('site_name');
    $pageDescription = $data['pageDescription'] ?? setting('site_description');
    $bodyClass = $data['bodyClass'] ?? '';
    $currentUser = current_user();
    $flashes = take_flashes();
    extract($data, EXTR_SKIP);
    ob_start();
    require $file;
    $content = ob_get_clean();
    require LXL_VIEWS . '/layout.php';
}

function render_admin(string $view, array $data = []): void
{
    $file = LXL_VIEWS . '/admin/' . $view . '.php';
    if (!is_file($file)) {
        http_response_code(404);
        $file = LXL_VIEWS . '/admin/404.php';
    }
    $adminPageTitle = $data['pageTitle'] ?? '后台';
    $currentUser = current_user();
    $flashes = take_flashes();
    extract($data, EXTR_SKIP);
    ob_start();
    require $file;
    $content = ob_get_clean();
    require LXL_VIEWS . '/admin/layout.php';
}

function partial(string $name, array $data = []): void
{
    $file = LXL_VIEWS . '/partials/' . $name . '.php';
    if (!is_file($file)) {
        return;
    }
    extract($data, EXTR_SKIP);
    require $file;
}

/* ---------------------------------------------------------------------------
 * 当前用户、等级、认证
 * ------------------------------------------------------------------------- */

function current_user(bool $refresh = false): ?array
{
    if (!$refresh && array_key_exists('lxl_current_user', $GLOBALS)) {
        return $GLOBALS['lxl_current_user'];
    }
    $id = (int) ($_SESSION['user_id'] ?? 0);
    if ($id <= 0) {
        $GLOBALS['lxl_current_user'] = null;
        return null;
    }
    $user = db_one('SELECT * FROM users WHERE id = ? LIMIT 1', [$id]);
    if (!$user || $user['status'] === 'banned') {
        unset($_SESSION['user_id']);
        $GLOBALS['lxl_current_user'] = null;
        return null;
    }
    $now = time();
    if (($now - (int) ($_SESSION['last_ping'] ?? 0)) > 45) {
        db_exec('UPDATE users SET last_active_at = NOW() WHERE id = ?', [$id]);
        $_SESSION['last_ping'] = $now;
    }
    $GLOBALS['lxl_current_user'] = $user;
    return $user;
}

function refresh_current_user(): void
{
    $GLOBALS['lxl_current_user'] = null;
    current_user(true);
}

function login_user(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['last_ping'] = time();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    db_exec('UPDATE users SET last_active_at = NOW() WHERE id = ?', [(int) $user['id']]);
    $GLOBALS['lxl_current_user'] = null;
    current_user(true);
}

function logout_user(): void
{
    unset($_SESSION['user_id'], $_SESSION['last_ping'], $_SESSION['csrf_token']);
    session_regenerate_id(true);
    $GLOBALS['lxl_current_user'] = null;
}

function is_admin(?array $user = null): bool
{
    $user = $user ?? current_user();
    return $user !== null && ($user['role'] ?? '') === 'admin';
}

function require_login(?string $next = null): array
{
    $user = current_user();
    if ($user === null) {
        flash('warning', '请先登录后再继续。');
        $next = $next ?? current_url();
        redirect(url('login', ['next' => $next]));
    }
    return $user;
}

function require_admin(): array
{
    $user = require_login();
    if (!is_admin($user)) {
        http_response_code(403);
        flash('error', '你没有访问管理后台的权限。');
        redirect(url('home'));
    }
    return $user;
}

function email_verified(?array $user = null): bool
{
    $user = $user ?? current_user();
    return $user !== null && !empty($user['email_verified_at']);
}

function require_verified(): array
{
    $user = require_login();
    if (setting_bool('email_verify_required') && !email_verified($user)) {
        flash('warning', '请先完成邮箱验证，再使用这项功能。');
        redirect(url('verify_email', ['resend' => 1]));
    }
    return $user;
}

function levels(bool $refresh = false): array
{
    if (!$refresh && isset($GLOBALS['lxl_levels_cache'])) {
        return $GLOBALS['lxl_levels_cache'];
    }
    $rows = db_all('SELECT * FROM levels ORDER BY level ASC');
    $GLOBALS['lxl_levels_cache'] = $rows;
    return $rows;
}

function level_for_exp(int $exp): array
{
    $current = null;
    foreach (levels() as $level) {
        if ($exp >= (int) $level['min_exp']) {
            $current = $level;
        }
    }
    if ($current === null) {
        $current = ['id' => 0, 'level' => 0, 'name' => '初来乍到', 'min_exp' => 0, 'max_exp' => 0, 'color' => '#79747E'];
    }
    return $current;
}

function level_for_user(?array $user): array
{
    return level_for_exp((int) ($user['exp'] ?? 0));
}

function level_progress(?array $user): array
{
    $exp = (int) ($user['exp'] ?? 0);
    $current = level_for_exp($exp);
    $next = null;
    foreach (levels() as $level) {
        if ((int) $level['level'] === (int) $current['level'] + 1) {
            $next = $level;
            break;
        }
    }
    $start = (int) $current['min_exp'];
    $end = $next ? (int) $next['min_exp'] : max($exp, 1);
    $span = max(1, $end - $start);
    $progress = $next ? min(100, max(0, round(($exp - $start) / $span * 100))) : 100;
    return [
        'current' => $current,
        'next' => $next,
        'progress' => (int) $progress,
        'to_next' => $next ? max(0, $end - $exp) : 0,
    ];
}

function preload_badges(array $userIds): void
{
    $userIds = array_values(array_unique(array_filter(array_map('intval', $userIds))));
    $cache = $GLOBALS['lxl_badge_cache'] ?? [];
    $missing = array_values(array_filter($userIds, fn ($id) => !array_key_exists($id, $cache)));
    if ($missing === []) {
        return;
    }
    $placeholders = implode(',', array_fill(0, count($missing), '?'));
    $rows = db_all(
        "SELECT uc.user_id, c.* FROM user_certifications uc
         JOIN certifications c ON c.id = uc.cert_id
         WHERE uc.user_id IN ({$placeholders}) AND c.enabled = 1
         ORDER BY c.sort ASC, c.id ASC",
        $missing
    );
    foreach ($missing as $id) {
        $cache[$id] = [];
    }
    foreach ($rows as $row) {
        $userId = (int) $row['user_id'];
        unset($row['user_id']);
        $cache[$userId][] = $row;
    }
    $GLOBALS['lxl_badge_cache'] = $cache;
}

function user_badges(int $userId): array
{
    preload_badges([$userId]);
    return $GLOBALS['lxl_badge_cache'][$userId] ?? [];
}

function has_cert_type(int $userId, string $type): bool
{
    foreach (user_badges($userId) as $badge) {
        if ($badge['type'] === $type) {
            return true;
        }
    }
    return false;
}

function is_official_user(int $userId): bool
{
    return has_cert_type($userId, 'official');
}

function official_color(int $userId): string
{
    foreach (user_badges($userId) as $badge) {
        if ($badge['type'] === 'official') {
            return $badge['color'] ?: '#1A73E8';
        }
    }
    return '#1A73E8';
}

function badge_html(int $userId, ?array $user = null): string
{
    if (!setting_bool('official_badge_enabled', true)) {
        return '';
    }
    $user = $user ?? db_one('SELECT id, show_official_badge FROM users WHERE id = ?', [$userId]);
    if ($user && (int) ($user['show_official_badge'] ?? 1) !== 1) {
        return '';
    }
    $html = '';
    foreach (user_badges($userId) as $badge) {
        $color = preg_match('/^#[0-9a-f]{3,8}$/i', $badge['color']) ? $badge['color'] : '#1A73E8';
        $label = e($badge['name']);
        $html .= '<span class="verify-badge verify-badge--' . e($badge['type']) . '" style="--badge-color:' . e($color) . '" title="' . $label . '">' . icon('verified') . '<span>' . $label . '</span></span>';
    }
    return $html;
}

function is_official_card_enabled(int $userId, ?array $user = null): bool
{
    if (!setting_bool('official_card_enabled', true) || !setting_bool('official_badge_enabled', true)) {
        return false;
    }
    if ($user && (int) ($user['show_official_badge'] ?? 1) !== 1) {
        return false;
    }
    return is_official_user($userId);
}

function can_upload_posts(?array $user = null): bool
{
    $user = $user ?? current_user();
    if ($user === null || !setting_bool('upload_enabled', true)) {
        return false;
    }
    if (is_admin($user)) {
        return true;
    }
    $roles = array_filter(array_map('trim', explode(',', (string) setting('upload_roles', 'official,sponsor'))));
    foreach ($roles as $role) {
        if (has_cert_type((int) $user['id'], $role)) {
            return true;
        }
    }
    return false;
}

function avatar_url(?array $user): string
{
    $avatar = trim((string) ($user['avatar'] ?? ''));
    if ($avatar === '') {
        return asset('assets/img/default-avatar.svg');
    }
    return media_url($avatar);
}

function user_link(?array $user): string
{
    if (!$user) {
        return '#';
    }
    return url('user', ['id' => (int) $user['id']]);
}

/* ---------------------------------------------------------------------------
 * 时间、数字、文本
 * ------------------------------------------------------------------------- */

function format_date(?string $date, string $format = 'Y-m-d H:i'): string
{
    if (!$date) {
        return '';
    }
    $ts = strtotime($date);
    return $ts ? date($format, $ts) : '';
}

function time_ago(?string $date): string
{
    if (!$date) {
        return '';
    }
    $ts = strtotime($date);
    if (!$ts) {
        return '';
    }
    $diff = time() - $ts;
    if ($diff < 60) {
        return '刚刚';
    }
    if ($diff < 3600) {
        return intdiv($diff, 60) . ' 分钟前';
    }
    if ($diff < 86400) {
        return intdiv($diff, 3600) . ' 小时前';
    }
    if ($diff < 86400 * 7) {
        return intdiv($diff, 86400) . ' 天前';
    }
    if (date('Y', $ts) === date('Y')) {
        return date('m-d', $ts);
    }
    return date('Y-m-d', $ts);
}

function short_number(int|float $number): string
{
    $number = (int) $number;
    if ($number >= 100000000) {
        return rtrim(rtrim(number_format($number / 100000000, 1), '0'), '.') . '亿';
    }
    if ($number >= 10000) {
        return rtrim(rtrim(number_format($number / 10000, 1), '0'), '.') . '万';
    }
    return number_format($number);
}

function text_excerpt(?string $text, int $length = 140): string
{
    $text = trim(preg_replace('/\s+/u', ' ', strip_tags((string) $text)) ?? '');
    if (mb_strlen($text) <= $length) {
        return $text;
    }
    return mb_substr($text, 0, $length) . '…';
}

function post_excerpt(array $post, int $length = 150): string
{
    return text_excerpt($post['content_text'] ?? $post['content'] ?? '', $length);
}

function is_online(?array $user): bool
{
    if (!$user || empty($user['last_active_at'])) {
        return false;
    }
    return (time() - strtotime($user['last_active_at'])) < (setting_int('online_minutes', 15) * 60);
}

function username_is_valid(string $username): bool
{
    return (bool) preg_match('/^[\p{L}\p{N}_\-]{2,32}$/u', $username);
}

function normalize_username(string $username): string
{
    return trim(preg_replace('/\s+/u', '', $username) ?? '');
}

function valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false && mb_strlen($email) <= 190;
}

function current_page(): int
{
    return max(1, (int) ($_GET['page'] ?? 1));
}

function per_page(int $default = 12, int $max = 50): int
{
    $per = (int) ($_GET['per'] ?? $default);
    return max(1, min($max, $per));
}

function like_escape(string $value): string
{
    return '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $value) . '%';
}

function safe_next_url(?string $next): string
{
    $next = trim((string) $next);
    if ($next === '') {
        return url('home');
    }
    if (str_starts_with($next, '/') && !str_starts_with($next, '//')) {
        return $next;
    }
    if (preg_match('#^(index\.php|admin\.php)(\?|$)#', $next)) {
        return base_url() . '/' . $next;
    }
    if (preg_match('#^https?://#i', $next)) {
        $targetHost = parse_url($next, PHP_URL_HOST);
        $targetPort = parse_url($next, PHP_URL_PORT);
        $selfHost = parse_url(site_origin(), PHP_URL_HOST);
        $selfPort = parse_url(site_origin(), PHP_URL_PORT);
        if ($targetHost !== null && strcasecmp($targetHost, (string) $selfHost) === 0 && $targetPort === $selfPort) {
            return $next;
        }
    }
    return url('home');
}

function client_ip(): string
{
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function rate_limit(string $key, int $limit = 5, int $seconds = 300): bool
{
    $bucket = $_SESSION['rate_limits'][$key] ?? ['count' => 0, 'time' => time()];
    if ((time() - (int) $bucket['time']) > $seconds) {
        $bucket = ['count' => 0, 'time' => time()];
    }
    $bucket['count'] = (int) $bucket['count'] + 1;
    $_SESSION['rate_limits'][$key] = $bucket;
    return $bucket['count'] <= $limit;
}

function rate_limit_clear(string $key): void
{
    unset($_SESSION['rate_limits'][$key]);
}

/* ---------------------------------------------------------------------------
 * 分页
 * ------------------------------------------------------------------------- */

function pager(int $total, int $perPage, int $page, callable $urlFor): string
{
    $pages = max(1, (int) ceil($total / max(1, $perPage)));
    if ($pages <= 1) {
        return '';
    }
    $page = max(1, min($pages, $page));
    $start = max(1, $page - 2);
    $end = min($pages, $page + 2);
    $html = '<nav class="pager" aria-label="分页">';
    if ($page > 1) {
        $html .= '<a class="pager__btn" href="' . e($urlFor($page - 1)) . '" aria-label="上一页">' . icon('chevron_left') . '</a>';
    }
    if ($start > 1) {
        $html .= '<a class="pager__btn" href="' . e($urlFor(1)) . '">1</a>';
        if ($start > 2) {
            $html .= '<span class="pager__dots">…</span>';
        }
    }
    for ($i = $start; $i <= $end; $i++) {
        $html .= '<a class="pager__btn' . ($i === $page ? ' is-current' : '') . '" href="' . e($urlFor($i)) . '"' . ($i === $page ? ' aria-current="page"' : '') . '>' . $i . '</a>';
    }
    if ($end < $pages) {
        if ($end < $pages - 1) {
            $html .= '<span class="pager__dots">…</span>';
        }
        $html .= '<a class="pager__btn" href="' . e($urlFor($pages)) . '">' . $pages . '</a>';
    }
    if ($page < $pages) {
        $html .= '<a class="pager__btn" href="' . e($urlFor($page + 1)) . '" aria-label="下一页">' . icon('chevron_right') . '</a>';
    }
    $html .= '</nav>';
    return $html;
}

/* ---------------------------------------------------------------------------
 * 图片上传
 * ------------------------------------------------------------------------- */

function upload_error_message(int $code): string
{
    return match ($code) {
        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => '图片超过服务器允许的大小。',
        UPLOAD_ERR_PARTIAL => '图片上传不完整，请重试。',
        UPLOAD_ERR_NO_FILE => '请选择图片。',
        UPLOAD_ERR_NO_TMP_DIR => '服务器缺少临时目录。',
        UPLOAD_ERR_CANT_WRITE => '服务器无法写入文件。',
        default => '图片上传失败。',
    };
}

function upload_image(array $file, string $kind = 'post'): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException(upload_error_message((int) ($file['error'] ?? UPLOAD_ERR_NO_FILE)));
    }
    if (($file['size'] ?? 0) > 12 * 1024 * 1024) {
        throw new RuntimeException('原图不能超过 12MB。');
    }
    if (!is_uploaded_file($file['tmp_name'] ?? '')) {
        throw new RuntimeException('无效的上传文件。');
    }
    $info = @getimagesize($file['tmp_name']);
    if ($info === false) {
        throw new RuntimeException('只支持 JPG、PNG、WebP、GIF 图片。');
    }
    $mime = $info['mime'] ?? '';
    if (!in_array($mime, ['image/jpeg', 'image/png', 'image/webp', 'image/gif'], true)) {
        throw new RuntimeException('只支持 JPG、PNG、WebP、GIF 图片。');
    }
    if (($info[0] ?? 0) > 12000 || ($info[1] ?? 0) > 12000) {
        throw new RuntimeException('图片尺寸过大，请先缩小后再上传。');
    }
    if (!function_exists('imagecreatefromstring')) {
        throw new RuntimeException('服务器未启用 GD 扩展，无法处理图片。');
    }
    $source = @imagecreatefromstring(file_get_contents($file['tmp_name']));
    if (!$source) {
        throw new RuntimeException('图片读取失败。');
    }

    $maxWidth = $kind === 'avatar' ? setting_int('avatar_max_width', 512) : ($kind === 'carousel' ? 1920 : setting_int('upload_max_width', 1600));
    $maxKb = $kind === 'avatar' ? setting_int('avatar_max_kb', 300) : ($kind === 'carousel' ? setting_int('carousel_max_kb', 500) : setting_int('upload_max_kb', 100));
    $width = imagesx($source);
    $height = imagesy($source);
    if ($width > $maxWidth) {
        $newHeight = max(1, (int) round($height * ($maxWidth / $width)));
        $resized = imagecreatetruecolor($maxWidth, $newHeight);
        imagefill($resized, 0, 0, imagecolorallocate($resized, 255, 255, 255));
        imagecopyresampled($resized, $source, 0, 0, 0, 0, $maxWidth, $newHeight, $width, $height);
        imagedestroy($source);
        $source = $resized;
    }

    $quality = 88;
    do {
        ob_start();
        imagejpeg($source, null, $quality);
        $binary = ob_get_clean();
        if (strlen($binary) <= $maxKb * 1024) {
            break;
        }
        $quality -= 8;
        if ($quality < 40) {
            $currentWidth = imagesx($source);
            $currentHeight = imagesy($source);
            if ($currentWidth <= 320) {
                break;
            }
            $newWidth = max(320, (int) round($currentWidth * 0.8));
            $newHeight = max(1, (int) round($currentHeight * ($newWidth / $currentWidth)));
            $smaller = imagecreatetruecolor($newWidth, $newHeight);
            imagefill($smaller, 0, 0, imagecolorallocate($smaller, 255, 255, 255));
            imagecopyresampled($smaller, $source, 0, 0, 0, 0, $newWidth, $newHeight, $currentWidth, $currentHeight);
            imagedestroy($source);
            $source = $smaller;
            $quality = 78;
        }
    } while (true);

    if (strlen($binary) > $maxKb * 1024) {
        throw new RuntimeException('图片压缩后仍超过 ' . $maxKb . 'KB，请换一张更小的图片。');
    }

    $subDir = match ($kind) {
        'avatar' => 'avatars',
        'carousel' => 'carousels',
        default => 'posts/' . date('Ym'),
    };
    $targetDir = LXL_UPLOADS . '/' . $subDir;
    if (!is_dir($targetDir) && !mkdir($targetDir, 0755, true) && !is_dir($targetDir)) {
        throw new RuntimeException('无法创建上传目录。');
    }
    $filename = date('YmdHis') . '-' . bin2hex(random_bytes(8)) . '.jpg';
    $target = $targetDir . '/' . $filename;
    if (file_put_contents($target, $binary) === false) {
        imagedestroy($source);
        throw new RuntimeException('保存图片失败。');
    }
    imagedestroy($source);
    return 'uploads/' . $subDir . '/' . $filename;
}

/* ---------------------------------------------------------------------------
 * 图标
 * ------------------------------------------------------------------------- */

function icon_paths(): array
{
    return [
        'home' => 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
        'search' => 'M9.5 3a6.5 6.5 0 1 0 4.06 11.58L19 20l1.42-1.42-5.42-5.42A6.5 6.5 0 0 0 9.5 3zm0 2a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9z',
        'menu' => 'M3 6h18v2H3zm0 5h18v2H3zm0 5h18v2H3z',
        'close' => 'M6.4 5 5 6.4 10.6 12 5 17.6 6.4 19 12 13.4 17.6 19 19 17.6 13.4 12 19 6.4 17.6 5 12 10.6z',
        'light' => 'M12 7a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm0-5h1v3h-2V2zm0 17h1v3h-2v-3zM2 11h3v2H2zm17 0h3v2h-3zM4.22 5.64l1.42-1.42 2.12 2.12-1.42 1.42zm11.02 11.02 1.42-1.42 2.12 2.12-1.42 1.42zM5.64 19.78l-1.42-1.42 2.12-2.12 1.42 1.42zM16.66 8.66 15.24 7.24l2.12-2.12 1.42 1.42zM11 2h2v3h-2z',
        'dark' => 'M12 3a9 9 0 1 0 9 9c0-.46-.04-.92-.1-1.36a6.5 6.5 0 0 1-8.54-8.54C12.92 3.04 12.46 3 12 3z',
        'system' => 'M4 5h16v10H4V5zm0-2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h6v2H8v2h8v-2h-2v-2h6a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2H4z',
        'notifications' => 'M12 22a2 2 0 0 0 2-2h-4a2 2 0 0 0 2 2zm6-6v-5a6 6 0 0 0-5-5.91V4a1 1 0 1 0-2 0v1.09A6 6 0 0 0 6 11v5l-2 2v1h16v-1z',
        'message' => 'M4 3h16a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2z',
        'mail' => 'M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm9 7L4 6v1l8 6 8-6V6z',
        'person' => 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm0 2c-4.42 0-8 2.01-8 4.5V20h16v-1.5c0-2.49-3.58-4.5-8-4.5z',
        'users' => 'M16 11a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm-8 0a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7zm0 2c-3.31 0-6 1.57-6 3.5V19h12v-2.5C14 14.57 11.31 13 8 13zm8 0c-.55 0-1.07.05-1.56.14 1.23.96 1.56 2.02 1.56 3.36V19h6v-2.5c0-1.93-2.69-3.5-6-3.5z',
        'add' => 'M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6z',
        'edit' => 'M3 17.25V21h3.75L17.8 9.94l-3.75-3.75L3 17.25zM20.7 7.04a1 1 0 0 0 0-1.42l-2.32-2.32a1 1 0 0 0-1.42 0l-1.83 1.83 3.75 3.75z',
        'favorite' => 'M12 21.35 10.55 20C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54z',
        'favorite_border' => 'M16.5 3c-1.74 0-3.41.81-4.5 2.09C10.91 3.81 9.24 3 7.5 3 4.42 3 2 5.42 2 8.5c0 3.78 3.4 6.86 8.55 11.54L12 21.35l1.45-1.32C18.6 15.36 22 12.28 22 8.5 22 5.42 19.58 3 16.5 3zm-4.4 15.55-.1.1-.1-.1C7.14 14.24 4 11.39 4 8.5 4 6.5 5.5 5 7.5 5c1.54 0 3.04.99 3.57 2.36h1.87C13.46 5.99 14.96 5 16.5 5c2 0 3.5 1.5 3.5 3.5 0 2.89-3.14 5.74-7.9 10.05z',
        'bookmark' => 'M17 3H7a2 2 0 0 0-2 2v16l7-3 7 3V5a2 2 0 0 0-2-2z',
        'bookmark_border' => 'M17 3H7a2 2 0 0 0-2 2v16l7-3 7 3V5a2 2 0 0 0-2-2zm0 15-5-2.18L7 18V5h10v13z',
        'thumb_up' => 'M1 21h4V9H1v12zM23 10a2 2 0 0 0-2-2h-6.31l.95-4.57.03-.32a1.5 1.5 0 0 0-.44-1.06L14.17 1 7.59 7.59A2 2 0 0 0 7 9v10a2 2 0 0 0 2 2h9a2 2 0 0 0 1.84-1.21l3.02-7.05c.09-.23.14-.47.14-.74v-2z',
        'share' => 'M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11A2.99 2.99 0 1 0 15 5c0 .24.04.47.09.7L8.04 9.81A3 3 0 1 0 8.04 14.19l7.12 4.16c-.05.21-.08.43-.08.65a2.92 2.92 0 1 0 2.92-2.92z',
        'more' => 'M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm0 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm0 6a2 2 0 1 0 0 4 2 2 0 0 0 0-4z',
        'check' => 'M9 16.17 4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
        'verified' => 'M23 12l-2.44-2.79.34-3.69-3.61-.82-1.89-3.2L12 2.96 8.6 1.5 6.71 4.69 3.1 5.5l.34 3.7L1 12l2.44 2.79-.34 3.7 3.61.82L8.6 22.5l3.4-1.47 3.4 1.46 1.89-3.19 3.61-.82-.34-3.69zM10.09 16.72l-3.8-3.81 1.48-1.48 2.32 2.33 5.85-5.87 1.48 1.48z',
        'arrow_back' => 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20z',
        'send' => 'M2.01 21 23 12 2.01 3 2 10l15 2-15 2z',
        'settings' => 'M19.14 12.94a7.07 7.07 0 0 0 .06-.94 7.07 7.07 0 0 0-.06-.94l2.03-1.58a.5.5 0 0 0 .12-.64l-1.92-3.32a.5.5 0 0 0-.61-.22l-2.39.96a7.03 7.03 0 0 0-1.62-.94l-.36-2.54a.5.5 0 0 0-.5-.42h-3.84a.5.5 0 0 0-.5.42l-.36 2.54c-.59.24-1.13.56-1.62.94l-2.39-.96a.5.5 0 0 0-.61.22L2.74 8.84a.5.5 0 0 0 .12.64l2.03 1.58c-.04.31-.06.63-.06.94s.02.63.06.94l-2.03 1.58a.5.5 0 0 0-.12.64l1.92 3.32c.14.24.43.34.68.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.04.24.25.42.5.42h3.84c.25 0 .46-.18.5-.42l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.25.12.54.02.68-.22l1.92-3.32a.5.5 0 0 0-.12-.64zM12 15.6A3.6 3.6 0 1 1 12 8.4a3.6 3.6 0 0 1 0 7.2z',
        'logout' => 'M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.59L17 17l5-5zM4 5h8V3H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h8v-2H4z',
        'admin' => 'M3 13h8V3H3zm0 8h8v-6H3zm10 0h8V11h-8zm0-18v6h8V3z',
        'article' => 'M19 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V5a2 2 0 0 0-2-2zM9 17H7v-7h2zm4 0h-2V7h2zm4 0h-2v-4h2z',
        'board' => 'M4 4h7v7H4zm9 0h7v7h-7zM4 13h7v7H4zm9 0h7v7h-7z',
        'link' => 'M3.9 12a3.1 3.1 0 0 1 3.1-3.1h4V7H7a5 5 0 0 0 0 10h4v-1.9H7A3.1 3.1 0 0 1 3.9 12zM8 13h8v-2H8zm9-6h-4v1.9h4a3.1 3.1 0 0 1 0 6.2h-4V17h4a5 5 0 0 0 0-10z',
        'info' => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 15h-2v-6h2zm0-8h-2V7h2z',
        'chevron_right' => 'M9.29 6.71 14.58 12l-5.29 5.29 1.42 1.42L17.42 12l-6.71-6.71z',
        'chevron_left' => 'M14.71 6.71 9.42 12l5.29 5.29-1.42 1.42L6.58 12l6.71-6.71z',
        'coin' => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm0 3a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm0 2a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm-1 2h2v1.2c.9.2 1.5.8 1.5 1.8h-2c0-.3-.2-.5-.5-.5s-.5.2-.5.5.2.5.5.5h1c1.1 0 2 .9 2 2 0 1-.7 1.8-1.5 2V18h-2v-1.5c-1-.2-1.5-1-1.5-2h2c0 .3.2.5.5.5s.5-.2.5-.5-.2-.5-.5-.5h-1c-1.1 0-2-.9-2-2 0-1 .7-1.8 1.5-2z',
        'eye' => 'M12 4.5C7 4.5 2.73 7.61 1 12c1.73 4.39 6 7.5 11 7.5s9.27-3.11 11-7.5c-1.73-4.39-6-7.5-11-7.5zm0 12.5a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z',
        'comment' => 'M21 6h-2v9H6v2a2 2 0 0 0 2 2h9l4 4V8a2 2 0 0 0-2-2zm-2-2H5a2 2 0 0 0-2 2v10l4-4h10a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z',
        'image' => 'M21 19V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2zM8.5 13.5l2.5 3 3.5-4.5 4.5 6H5zM8 9a2 2 0 1 1 0-4 2 2 0 0 1 0 4z',
        'video' => 'M4 6h12a2 2 0 0 1 2 2v2l4-3v10l-4-3v2a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z',
        'upload' => 'M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z',
        'trash' => 'M6 19a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V7H6zM19 4h-3.5l-1-1h-5l-1 1H5v2h14z',
        'pin' => 'M16 12V4h1V2H7v2h1v8l-2 2v2h6v6h2v-6h6v-2z',
        'star' => 'M12 17.27 18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z',
        'bolt' => 'M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66L13 3h1l-1 7h3.5c.49 0 .56.33.38.66z',
        'lock' => 'M18 8h-1V6a5 5 0 0 0-10 0v2H6a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V10a2 2 0 0 0-2-2zM9 6a3 3 0 0 1 6 0v2H9zm3 12a2 2 0 1 1 0-4 2 2 0 0 1 0 4z',
        'camera' => 'M9 3 7.17 5H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.17L15 3zm3 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-2a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
        'copy' => 'M16 1H4a2 2 0 0 0-2 2v14h2V3h12zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11z',
        'grid' => 'M3 3h8v8H3zm10 0h8v8h-8zM3 13h8v8H3zm10 0h8v8h-8z',
        'shield' => 'M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5zm-2 15-4-4 1.41-1.41L10 13.17l5.59-5.59L17 9z',
        'mega' => 'M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm-2 4v1.5h-3V8zm0 3.5V13h-3v-1.5zm-12-3.5h6v5H6zm0 7h12V17H6z',
        'gift' => 'M20 6h-2.18A3 3 0 0 0 12 3.5 3 3 0 0 0 6.18 6H4a2 2 0 0 0-2 2v3h2v9h16v-9h2V8a2 2 0 0 0-2-2zm-8 12H6v-7h6zm0-9H6V8h6zm2-2V8h6v1zm0 2h6v7h-6z',
        'clock' => 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 11H7v-2h4V6h2z',
        'external' => 'M14 3h7v7h-2V6.41l-9.29 9.3-1.42-1.42 9.3-9.29H14zM5 5h6v2H7v10h10v-4h2v6H5z',
        'refresh' => 'M17.65 6.35A8 8 0 1 0 19.73 14h-2.09A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4z',
        'bolt_filled' => 'M11 21h-1l1-7H7.5c-.58 0-.57-.32-.38-.66L13 3h1l-1 7h3.5c.49 0 .56.33.38.66z',
        'arrow_up' => 'M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8z',
        'filter' => 'M3 5h18v2H3zm3 6h12v2H6zm3 6h6v2H9z',
        'phone' => 'M17 1H7a3 3 0 0 0-3 3v16a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3V4a3 3 0 0 0-3-3zm0 18H7V5h10v14zm-5 4a1 1 0 1 0 0-2 1 1 0 0 0 0 2z',
    ];
}

function icon(string $name, string $class = '', int $size = 20): string
{
    $paths = icon_paths();
    if (!isset($paths[$name])) {
        $name = 'info';
    }
    $classAttr = 'icon' . ($class !== '' ? ' ' . e($class) : '');
    return '<svg class="' . $classAttr . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="' . $paths[$name] . '"/></svg>';
}

function icon_sprite(): void
{
    echo '<svg class="svg-sprite" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"></svg>';
}

/* ---------------------------------------------------------------------------
 * 数据读取辅助
 * ------------------------------------------------------------------------- */

function board_list(bool $onlyActive = true): array
{
    $where = $onlyActive ? "WHERE status = 'active'" : '';
    return db_all("SELECT * FROM boards {$where} ORDER BY sort ASC, id ASC");
}

function board_by_id(int $id): ?array
{
    return db_one('SELECT * FROM boards WHERE id = ? LIMIT 1', [$id]);
}

function post_by_id(int $id, bool $withDeleted = false): ?array
{
    $where = $withDeleted ? '' : "AND p.status = 'published'";
    return db_one(
        "SELECT p.*, b.name AS board_name, b.slug AS board_slug, b.color AS board_color,
                u.username, u.avatar, u.bio, u.exp, u.level, u.show_official_badge, u.status AS user_status
         FROM posts p
         JOIN users u ON u.id = p.user_id
         LEFT JOIN boards b ON b.id = p.board_id
         WHERE p.id = ? {$where} LIMIT 1",
        [$id]
    );
}

function comment_by_id(int $id): ?array
{
    return db_one('SELECT * FROM comments WHERE id = ? LIMIT 1', [$id]);
}

function notification_count(?int $userId = null): int
{
    $userId = $userId ?? (int) (current_user()['id'] ?? 0);
    if ($userId <= 0) {
        return 0;
    }
    return (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0', [$userId], 0);
}

function unread_message_count(?int $userId = null): int
{
    $userId = $userId ?? (int) (current_user()['id'] ?? 0);
    if ($userId <= 0) {
        return 0;
    }
    return (int) db_value('SELECT COUNT(*) FROM messages WHERE receiver_id = ? AND is_read = 0', [$userId], 0);
}

function can_edit_post(array $post, ?array $user = null): bool
{
    $user = $user ?? current_user();
    if (!$user) {
        return false;
    }
    return is_admin($user) || (int) $post['user_id'] === (int) $user['id'];
}

function can_moderate_board(int $boardId, ?array $user = null): bool
{
    $user = $user ?? current_user();
    if (!$user) {
        return false;
    }
    if (is_admin($user)) {
        return true;
    }
    return (bool) db_value(
        'SELECT COUNT(*) FROM board_moderators WHERE board_id = ? AND user_id = ?',
        [$boardId, (int) $user['id']],
        0
    );
}

function pick_cover_from_html(string $html): string
{
    if (preg_match('/<img[^>]+src=["\']([^"\']+)["\']/i', $html, $m)) {
        $src = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
        if (preg_match('#^(https?://|/?uploads/|/?assets/)#i', $src)) {
            return $src;
        }
    }
    return '';
}

function email_configured(): bool
{
    return trim((string) setting('smtp_host', '')) !== ''
        && trim((string) setting('smtp_user', '')) !== ''
        && trim((string) setting('smtp_pass', '')) !== '';
}

function sync_post_counters(int $postId): void
{
    db_exec(
        "UPDATE posts p SET
            likes_count = (SELECT COUNT(*) FROM post_likes pl WHERE pl.post_id = p.id),
            favorites_count = (SELECT COUNT(*) FROM post_favorites pf WHERE pf.post_id = p.id),
            comments_count = (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id AND c.status = 'published'),
            rewards_coins = (SELECT COALESCE(SUM(pr.amount), 0) FROM post_rewards pr WHERE pr.post_id = p.id)
         WHERE p.id = ?",
        [$postId]
    );
}

