package com.bbs.lxlovo.top.data

import com.bbs.lxlovo.top.BuildConfig
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

class UpdateRepository {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun check(currentVersionCode: Int, currentVersionName: String): UpdateInfo =
        withContext(Dispatchers.IO) {
            val url = BuildConfig.API_URL.toHttpUrl().newBuilder()
                .addQueryParameter("action", "app.version")
                .addQueryParameter("version_code", currentVersionCode.toString())
                .addQueryParameter("version_name", currentVersionName)
                .addQueryParameter("package", BuildConfig.APPLICATION_ID)
                .build()
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "lxlovo-android/${BuildConfig.VERSION_NAME}")
                .header("Accept", "application/json")
                .build()
            client.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful || body.isBlank()) {
                    throw IOException("更新服务暂时不可用（${response.code}）")
                }
                parseUpdate(body)
            }
        }

    private fun parseUpdate(body: String): UpdateInfo {
        val root = JSONObject(body)
        if (!root.optBoolean("ok", false)) {
            throw IOException(root.optString("message", "更新服务返回异常"))
        }
        val latest = root.optJSONObject("latest")?.let(::parseRelease)
        val releases = mutableListOf<AppRelease>()
        val array = root.optJSONArray("releases") ?: JSONArray()
        for (index in 0 until array.length()) {
            array.optJSONObject(index)?.let { releases.add(parseRelease(it)) }
        }
        return UpdateInfo(
            latest = latest,
            releases = releases.sortedByDescending { it.versionCode },
            updateAvailable = root.optBoolean("update_available", false),
            forceUpdate = root.optBoolean("force_update", false),
            inAppBrowserDefault = root.optBoolean("in_app_browser_default", true),
        )
    }

    private fun parseRelease(json: JSONObject): AppRelease = AppRelease(
        id = json.optInt("id"),
        versionName = json.optString("version_name", "未知版本"),
        versionCode = json.optInt("version_code"),
        downloadUrl = json.optString("download_url"),
        downloadMode = json.optString("download_mode", "auto"),
        directDownload = json.optBoolean("direct_download", false),
        isForced = json.optBoolean("is_forced", false),
        changelog = json.optString("changelog"),
        publishedAt = json.optString("published_at"),
    )
}
