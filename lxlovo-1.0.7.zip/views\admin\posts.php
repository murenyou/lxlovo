<?php
$buildUrl = function (int $page) use ($q, $status, $boardId): string {
    $params = ['page' => $page];
    if ($q !== '') { $params['q'] = $q; }
    if ($status !== '') { $params['status'] = $status; }
    if ($boardId > 0) { $params['board'] = $boardId; }
    return admin_url('posts', $params);
};
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Content</span><h2>帖子管理</h2><p>共 <?= (int) $total ?> 条帖子记录。彻底删除后不可恢复。</p></div></div>

<form class="admin-filter" action="<?= e(admin_url('posts')) ?>" method="get">
    <input type="hidden" name="r" value="posts">
    <label class="admin-search"><?= icon('search', '', 18) ?><input type="search" name="q" value="<?= e($q) ?>" placeholder="搜索标题或正文"></label>
    <select name="status"><option value="">全部状态</option><?php foreach (['published' => '已发布', 'draft' => '草稿', 'deleted' => '回收站'] as $key => $label): ?><option value="<?= $key ?>" <?= $status === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select>
    <select name="board"><option value="">全部板块</option><?php foreach ($boards as $board): ?><option value="<?= (int) $board['id'] ?>" <?= $boardId === (int) $board['id'] ? 'selected' : '' ?>><?= e($board['name']) ?></option><?php endforeach; ?></select>
    <button class="btn btn--primary btn--sm" type="submit">筛选</button>
    <?php if ($q !== '' || $status !== '' || $boardId > 0): ?><a class="btn btn--text btn--sm" href="<?= e(admin_url('posts')) ?>">重置</a><?php endif; ?>
</form>

<section class="admin-panel">
    <div class="admin-batch-bar">
        <label class="check-line"><input type="checkbox" data-check-all="posts"><span>全选本页</span></label>
        <span class="admin-batch-bar__count">已选 <strong data-check-count="posts">0</strong> 篇</span>
        <form id="post-batch-form" action="<?= e(admin_url('post.batch')) ?>" method="post" class="admin-batch-form" data-batch-form>
            <?= csrf_field() ?>
            <select name="action" data-batch-action required>
                <option value="" selected disabled>选择批量操作</option>
                <option value="purge">彻底删除（不可恢复）</option>
                <option value="delete">移入回收站</option>
                <option value="restore">恢复</option>
            </select>
            <button class="btn btn--danger btn--sm" type="submit">执行批量操作</button>
        </form>
        <p class="admin-batch-bar__note">彻底删除会同时清理该帖的评论、点赞、收藏、打赏与通知，并删除仅被该帖使用的本地图片。</p>
    </div>

    <div class="table-wrap">
        <table class="data-table admin-table--posts">
            <thead>
                <tr><th class="check-col"><input type="checkbox" data-check-all="posts" aria-label="全选本页帖子"></th><th>帖子</th><th>作者</th><th>数据</th><th>状态</th><th>时间</th><th>操作</th></tr>
            </thead>
            <tbody>
            <?php foreach ($posts as $post): ?>
                <tr>
                    <td class="check-col"><input class="admin-row-check" type="checkbox" name="ids[]" value="<?= (int) $post['id'] ?>" form="post-batch-form" data-check-item="posts" aria-label="选择帖子 <?= e($post['title']) ?>"></td>
                    <td>
                        <a class="table-title" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>" target="_blank"><?= e($post['title']) ?></a>
                        <small class="table-sub"><?= e($post['board_name']) ?> · #<?= (int) $post['id'] ?></small>
                    </td>
                    <td><a class="table-action" href="<?= e(admin_url('user', ['id' => (int) $post['user_id']])) ?>"><?= e($post['username']) ?></a></td>
                    <td><?= (int) $post['views'] ?> 阅 · <?= (int) $post['likes_count'] ?> 赞 · <?= (int) $post['comments_count'] ?> 评</td>
                    <td>
                        <div class="chip-row">
                            <?php if ((int) $post['is_pinned'] === 1): ?><span class="chip chip--pin">置顶</span><?php endif; ?>
                            <?php if ((int) $post['is_featured'] === 1): ?><span class="chip chip--feature">精选</span><?php endif; ?>
                            <span class="status-chip status-chip--<?= $post['status'] === 'published' ? 'success' : ($post['status'] === 'deleted' ? 'danger' : 'neutral') ?>"><?= $post['status'] === 'published' ? '已发布' : ($post['status'] === 'deleted' ? '回收站' : '草稿') ?></span>
                        </div>
                    </td>
                    <td><?= e(time_ago($post['created_at'])) ?></td>
                    <td>
                        <div class="table-actions">
                            <?php if ($post['status'] !== 'deleted'): ?>
                                <a class="table-action" href="<?= e(url('publish', ['id' => (int) $post['id']])) ?>" target="_blank">编辑</a>
                                <form action="<?= e(admin_url('post.action')) ?>" method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><input type="hidden" name="action" value="pin"><button class="table-action" type="submit"><?= (int) $post['is_pinned'] === 1 ? '取消置顶' : '置顶' ?></button></form>
                                <form action="<?= e(admin_url('post.action')) ?>" method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><input type="hidden" name="action" value="feature"><button class="table-action" type="submit"><?= (int) $post['is_featured'] === 1 ? '取消精选' : '精选' ?></button></form>
                                <form action="<?= e(admin_url('post.action')) ?>" method="post" data-confirm="移入回收站后前台将不再展示，但可以恢复。确定继续吗？"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><input type="hidden" name="action" value="delete"><button class="table-action" type="submit">回收站</button></form>
                            <?php else: ?>
                                <form action="<?= e(admin_url('post.action')) ?>" method="post"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><input type="hidden" name="action" value="restore"><button class="table-action" type="submit">恢复</button></form>
                            <?php endif; ?>
                            <form action="<?= e(admin_url('post.action')) ?>" method="post" data-confirm="彻底删除后无法恢复，相关评论、点赞、收藏、打赏、通知和未被其他内容使用的本地图片都会一并删除。确定彻底删除吗？">
                                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><input type="hidden" name="action" value="purge">
                                <button class="table-action table-action--purge" type="submit">彻底删除</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (!$posts): ?><div class="admin-empty">没有找到帖子。</div><?php endif; ?>
    <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
</section>
