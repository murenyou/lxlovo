package com.bbs.lxlovo.top.data

import org.json.JSONArray
import org.json.JSONObject

data class Badge(
    val id: Int,
    val code: String,
    val name: String,
    val type: String,
    val color: String,
)

data class User(
    val id: Int = 0,
    val username: String = "",
    val avatarUrl: String = "",
    val bio: String = "",
    val level: Int = 0,
    val levelName: String = "",
    val levelColor: String = "#79747E",
    val levelProgress: Int = 0,
    val exp: Int = 0,
    val toNext: Int = 0,
    val badges: List<Badge> = emptyList(),
    val isAdmin: Boolean = false,
    val email: String = "",
    val emailVerified: Boolean = false,
    val coins: Int = 0,
    val checkinStreak: Int = 0,
    val lastCheckinDate: String? = null,
    val createdAt: String? = null,
    val online: Boolean = false,
    val showOfficialBadge: Boolean = true,
    val notifyComment: Boolean = true,
    val notifyMention: Boolean = true,
    val notifyMessage: Boolean = true,
    val notifySystem: Boolean = true,
    val notifyEmail: Boolean = true,
)

data class Post(
    val id: Int,
    val title: String,
    val excerpt: String = "",
    val coverUrl: String = "",
    val boardId: Int = 0,
    val boardName: String = "",
    val boardColor: String = "#4F5BD5",
    val author: User = User(),
    val isPinned: Boolean = false,
    val isFeatured: Boolean = false,
    val isOfficial: Boolean = false,
    val views: Int = 0,
    val likes: Int = 0,
    val favorites: Int = 0,
    val commentCount: Int = 0,
    val createdAt: String? = null,
    val updatedAt: String? = null,
    val contentHtml: String = "",
    val contentText: String = "",
    val liked: Boolean = false,
    val favorited: Boolean = false,
    val rewardTotal: Int = 0,
    val commentList: List<Comment> = emptyList(),
    val related: List<Post> = emptyList(),
    val canEdit: Boolean = false,
    val canPin: Boolean = false,
    val canFeature: Boolean = false,
    val canModerate: Boolean = false,
)

data class Comment(
    val id: Int,
    val postId: Int,
    val parentId: Int? = null,
    val content: String,
    val isPinned: Boolean = false,
    val likes: Int = 0,
    val liked: Boolean = false,
    val createdAt: String? = null,
    val replyToUserId: Int? = null,
    val replyToUsername: String? = null,
    val user: User = User(),
    val replies: List<Comment> = emptyList(),
)

data class Board(
    val id: Int,
    val name: String,
    val slug: String = "",
    val description: String = "",
    val icon: String = "",
    val color: String = "#4F5BD5",
    val postCount: Int = 0,
    val latestPost: BoardLatestPost? = null,
    val moderators: List<BoardModerator> = emptyList(),
)

data class BoardLatestPost(
    val id: Int,
    val title: String,
    val createdAt: String?,
)

data class BoardModerator(
    val id: Int,
    val username: String,
    val avatarUrl: String,
    val role: String,
)

data class Carousel(
    val id: Int,
    val title: String,
    val subtitle: String,
    val imageUrl: String,
    val link: String,
)

data class Announcement(
    val id: Int,
    val title: String,
    val content: String,
    val displayMode: String,
)

data class Stats(
    val users: Int = 0,
    val posts: Int = 0,
    val comments: Int = 0,
    val todayPosts: Int = 0,
    val todayCheckins: Int = 0,
    val online: Int = 0,
)

data class HomeData(
    val carousels: List<Carousel>,
    val boards: List<Board>,
    val pinned: List<Post>,
    val latest: List<Post>,
    val hot: List<Post>,
    val featured: List<Post>,
    val random: List<Post>,
    val online: List<User>,
    val announcements: List<Announcement>,
    val stats: Stats,
)

data class PostPage(
    val items: List<Post>,
    val total: Int,
    val page: Int,
    val per: Int,
    val pages: Int,
)

data class UserStats(
    val posts: Int = 0,
    val comments: Int = 0,
    val favorites: Int = 0,
    val likes: Int = 0,
)

data class MeData(
    val user: User,
    val stats: UserStats,
    val recentPosts: List<Post>,
    val checkedInToday: Boolean,
    val checkinRewards: List<CheckinReward>,
    val unreadNotifications: Int,
    val unreadMessages: Int,
    val checkinHistory: List<CheckinRecord> = emptyList(),
    val certifications: List<Badge> = emptyList(),
    val pendingApplications: Int = 0,
)

data class CheckinRecord(
    val date: String,
    val streak: Int,
    val exp: Int,
    val coins: Int,
)

data class VerifyApplication(
    val id: Int,
    val type: String,
    val status: String,
    val reason: String,
    val proof: String,
    val createdAt: String?,
    val reviewedAt: String?,
)

data class VerifyStatus(
    val certifications: List<Badge>,
    val applications: List<VerifyApplication>,
)

data class FriendLink(
    val id: Int,
    val name: String,
    val url: String,
    val description: String,
    val tag: String,
)

data class AboutData(
    val siteName: String,
    val aboutContent: String,
    val stats: Stats,
    val online: List<User>,
    val links: List<FriendLink>,
)

data class UserComment(
    val id: Int,
    val content: String,
    val createdAt: String?,
    val postId: Int,
    val postTitle: String,
)

data class CheckinReward(
    val streakDays: Int,
    val exp: Int,
    val coins: Int,
)

data class AuthResult(
    val token: String,
    val user: User,
    val message: String = "",
)

data class NotificationItem(
    val id: Int,
    val type: String,
    val message: String,
    val link: String,
    val isRead: Boolean,
    val createdAt: String?,
    val actorName: String?,
    val actorAvatarUrl: String,
)

data class NotificationPage(
    val items: List<NotificationItem>,
    val total: Int,
    val unread: Int,
    val page: Int,
)

data class MessageItem(
    val id: Int,
    val senderId: Int,
    val content: String,
    val isRead: Boolean,
    val createdAt: String?,
)

data class Conversation(
    val user: User,
    val lastMessage: String,
    val lastSenderId: Int,
    val lastTime: String?,
    val unread: Int,
)

data class ConversationPage(
    val items: List<Conversation>,
    val totalUnread: Int,
)

data class MessageThread(
    val user: User,
    val items: List<MessageItem>,
)

data class UserPage(
    val user: User,
    val stats: UserStats,
    val posts: List<Post>,
    val comments: List<UserComment> = emptyList(),
)

data class SearchResult(
    val posts: List<Post>,
    val users: List<User>,
    val boards: List<Board>,
)

data class LikeResult(val active: Boolean, val count: Int)

data class CommentCreated(val comment: Comment, val count: Int)

data class RewardResult(val coins: Int, val rewardTotal: Int)

data class CheckinResult(
    val message: String,
    val user: User,
    val reward: CheckinReward?,
)

class ApiException(message: String, val statusCode: Int = 0) : Exception(message)

internal fun JSONObject.string(key: String, fallback: String = ""): String =
    if (isNull(key)) fallback else optString(key, fallback)

internal fun JSONObject.stringOrNull(key: String): String? =
    if (isNull(key)) null else optString(key).takeIf { it.isNotBlank() }

internal fun JSONObject.array(key: String): JSONArray = optJSONArray(key) ?: JSONArray()

internal fun parseBadges(array: JSONArray): List<Badge> = buildList {
    for (i in 0 until array.length()) {
        val item = array.optJSONObject(i) ?: continue
        add(
            Badge(
                id = item.optInt("id"),
                code = item.string("code"),
                name = item.string("name"),
                type = item.string("type"),
                color = item.string("color", "#4F5BD5"),
            )
        )
    }
}

internal fun parseUser(json: JSONObject?): User {
    if (json == null) return User()
    return User(
        id = json.optInt("id"),
        username = json.string("username"),
        avatarUrl = json.string("avatar_url"),
        bio = json.string("bio"),
        level = json.optInt("level"),
        levelName = json.string("level_name"),
        levelColor = json.string("level_color", "#79747E"),
        levelProgress = json.optInt("level_progress"),
        exp = json.optInt("exp"),
        toNext = json.optInt("to_next"),
        badges = parseBadges(json.array("badges")),
        isAdmin = json.optBoolean("is_admin"),
        email = json.string("email"),
        emailVerified = json.optBoolean("email_verified"),
        coins = json.optInt("coins"),
        checkinStreak = json.optInt("checkin_streak"),
        lastCheckinDate = json.stringOrNull("last_checkin_date"),
        createdAt = json.stringOrNull("created_at"),
        online = json.optBoolean("online"),
        showOfficialBadge = json.optInt("show_official_badge", 1) == 1,
        notifyComment = json.optInt("notify_comment", 1) == 1,
        notifyMention = json.optInt("notify_mention", 1) == 1,
        notifyMessage = json.optInt("notify_message", 1) == 1,
        notifySystem = json.optInt("notify_system", 1) == 1,
        notifyEmail = json.optInt("notify_email", 1) == 1,
    )
}

internal fun parsePost(json: JSONObject): Post {
    val rawComments = json.opt("comments")
    val commentList = if (rawComments is JSONArray) {
        buildList {
            for (i in 0 until rawComments.length()) {
                rawComments.optJSONObject(i)?.let { add(parseComment(it)) }
            }
        }
    } else {
        emptyList()
    }
    val count = when (rawComments) {
        is JSONArray -> json.optInt("comments_count", commentList.size)
        is Number -> rawComments.toInt()
        else -> json.optInt("comments_count")
    }
    val related = buildList {
        val array = json.optJSONArray("related") ?: JSONArray()
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { add(parsePost(it)) }
        }
    }
    return Post(
        id = json.optInt("id"),
        title = json.string("title"),
        excerpt = json.string("excerpt"),
        coverUrl = json.string("cover_url"),
        boardId = json.optInt("board_id"),
        boardName = json.string("board_name"),
        boardColor = json.string("board_color", "#4F5BD5"),
        author = parseUser(json.optJSONObject("author")),
        isPinned = json.optBoolean("is_pinned"),
        isFeatured = json.optBoolean("is_featured"),
        isOfficial = json.optBoolean("is_official"),
        views = json.optInt("views"),
        likes = json.optInt("likes"),
        favorites = json.optInt("favorites"),
        commentCount = count,
        createdAt = json.stringOrNull("created_at"),
        updatedAt = json.stringOrNull("updated_at"),
        contentHtml = json.string("content_html"),
        contentText = json.string("content_text"),
        liked = json.optBoolean("liked"),
        favorited = json.optBoolean("favorited"),
        rewardTotal = json.optInt("reward_total"),
        commentList = commentList,
        related = related,
        canEdit = json.optBoolean("can_edit"),
        canPin = json.optBoolean("can_pin"),
        canFeature = json.optBoolean("can_feature"),
        canModerate = json.optBoolean("can_moderate") || json.optBoolean("can_pin"),
    )
}

internal fun parseComment(json: JSONObject): Comment {
    val replies = buildList {
        val array = json.optJSONArray("replies") ?: JSONArray()
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { add(parseComment(it)) }
        }
    }
    return Comment(
        id = json.optInt("id"),
        postId = json.optInt("post_id"),
        parentId = if (json.isNull("parent_id")) null else json.optInt("parent_id"),
        content = json.string("content"),
        isPinned = json.optBoolean("is_pinned"),
        likes = json.optInt("likes"),
        liked = json.optBoolean("liked"),
        createdAt = json.stringOrNull("created_at"),
        replyToUserId = if (json.isNull("reply_to_user_id")) null else json.optInt("reply_to_user_id"),
        replyToUsername = json.stringOrNull("reply_to_username"),
        user = parseUser(json.optJSONObject("user")),
        replies = replies,
    )
}

internal fun parsePostList(array: JSONArray): List<Post> = buildList {
    for (i in 0 until array.length()) {
        array.optJSONObject(i)?.let { add(parsePost(it)) }
    }
}

internal fun parseBoard(json: JSONObject): Board {
    val latest = json.optJSONObject("latest_post")?.let {
        BoardLatestPost(
            id = it.optInt("id"),
            title = it.string("title"),
            createdAt = it.stringOrNull("created_at"),
        )
    }
    val moderators = buildList {
        val array = json.optJSONArray("moderators") ?: JSONArray()
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                BoardModerator(
                    id = item.optInt("id"),
                    username = item.string("username"),
                    avatarUrl = item.string("avatar_url"),
                    role = item.string("role"),
                )
            )
        }
    }
    return Board(
        id = json.optInt("id"),
        name = json.string("name"),
        slug = json.string("slug"),
        description = json.string("description"),
        icon = json.string("icon"),
        color = json.string("color", "#4F5BD5"),
        postCount = json.optInt("post_count"),
        latestPost = latest,
        moderators = moderators,
    )
}

internal fun parseBoards(array: JSONArray): List<Board> = buildList {
    for (i in 0 until array.length()) {
        array.optJSONObject(i)?.let { add(parseBoard(it)) }
    }
}

internal fun parseStats(json: JSONObject?): Stats {
    if (json == null) return Stats()
    return Stats(
        users = json.optInt("users"),
        posts = json.optInt("posts"),
        comments = json.optInt("comments"),
        todayPosts = json.optInt("today_posts"),
        todayCheckins = json.optInt("today_checkins"),
        online = json.optInt("online"),
    )
}

internal fun parseUserStats(json: JSONObject?): UserStats {
    if (json == null) return UserStats()
    return UserStats(
        posts = json.optInt("posts"),
        comments = json.optInt("comments"),
        favorites = json.optInt("favorites"),
        likes = json.optInt("likes"),
    )
}

internal fun parseHome(json: JSONObject): HomeData {
    val carousels = buildList {
        val array = json.array("carousels")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                Carousel(
                    id = item.optInt("id"),
                    title = item.string("title"),
                    subtitle = item.string("subtitle"),
                    imageUrl = item.string("image_url"),
                    link = item.string("link"),
                )
            )
        }
    }
    val online = buildList {
        val array = json.array("online")
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { add(parseUser(it)) }
        }
    }
    val announcements = buildList {
        val array = json.array("announcements")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                Announcement(
                    id = item.optInt("id"),
                    title = item.string("title"),
                    content = item.string("content"),
                    displayMode = item.string("display_mode"),
                )
            )
        }
    }
    return HomeData(
        carousels = carousels,
        boards = parseBoards(json.array("boards")),
        pinned = parsePostList(json.array("pinned")),
        latest = parsePostList(json.array("latest")),
        hot = parsePostList(json.array("hot")),
        featured = parsePostList(json.array("featured")),
        random = parsePostList(json.array("random")),
        online = online,
        announcements = announcements,
        stats = parseStats(json.optJSONObject("stats")),
    )
}

internal fun parsePostPage(json: JSONObject): PostPage = PostPage(
    items = parsePostList(json.array("items")),
    total = json.optInt("total"),
    page = json.optInt("page", 1),
    per = json.optInt("per", 15),
    pages = json.optInt("pages", 1),
)

internal fun parseMe(json: JSONObject): MeData {
    val rewards = buildList {
        val array = json.array("checkin_rewards")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                CheckinReward(
                    streakDays = item.optInt("streak_days"),
                    exp = item.optInt("exp"),
                    coins = item.optInt("coins"),
                )
            )
        }
    }
    val checkinHistory = buildList {
        val array = json.array("checkin_history")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                CheckinRecord(
                    date = item.string("date"),
                    streak = item.optInt("streak"),
                    exp = item.optInt("exp"),
                    coins = item.optInt("coins"),
                )
            )
        }
    }
    return MeData(
        user = parseUser(json.optJSONObject("user")),
        stats = parseUserStats(json.optJSONObject("stats")),
        recentPosts = parsePostList(json.array("recent_posts")),
        checkedInToday = json.optBoolean("checked_in_today"),
        checkinRewards = rewards,
        unreadNotifications = json.optInt("unread_notifications"),
        unreadMessages = json.optInt("unread_messages"),
        checkinHistory = checkinHistory,
        certifications = parseBadges(json.array("certifications")),
        pendingApplications = json.optInt("pending_applications"),
    )
}

internal fun parseNotifications(json: JSONObject): NotificationPage {
    val items = buildList {
        val array = json.array("items")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                NotificationItem(
                    id = item.optInt("id"),
                    type = item.string("type"),
                    message = item.string("message"),
                    link = item.string("link"),
                    isRead = item.optBoolean("is_read"),
                    createdAt = item.stringOrNull("created_at"),
                    actorName = item.stringOrNull("actor_name"),
                    actorAvatarUrl = item.string("actor_avatar_url"),
                )
            )
        }
    }
    return NotificationPage(
        items = items,
        total = json.optInt("total"),
        unread = json.optInt("unread"),
        page = json.optInt("page", 1),
    )
}

internal fun parseConversations(json: JSONObject): ConversationPage {
    val items = buildList {
        val array = json.array("items")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                Conversation(
                    user = parseUser(item.optJSONObject("user")),
                    lastMessage = item.string("last_message"),
                    lastSenderId = item.optInt("last_sender_id"),
                    lastTime = item.stringOrNull("last_time"),
                    unread = item.optInt("unread"),
                )
            )
        }
    }
    return ConversationPage(items, json.optInt("total_unread"))
}

internal fun parseThread(json: JSONObject): MessageThread {
    val items = buildList {
        val array = json.array("items")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                MessageItem(
                    id = item.optInt("id"),
                    senderId = item.optInt("sender_id"),
                    content = item.string("content"),
                    isRead = item.optBoolean("is_read"),
                    createdAt = item.stringOrNull("created_at"),
                )
            )
        }
    }
    return MessageThread(parseUser(json.optJSONObject("user")), items)
}

internal fun parseMessage(json: JSONObject): MessageItem = MessageItem(
    id = json.optInt("id"),
    senderId = json.optInt("sender_id"),
    content = json.string("content"),
    isRead = json.optBoolean("is_read"),
    createdAt = json.stringOrNull("created_at"),
)

internal fun parseUserPage(json: JSONObject): UserPage {
    val comments = buildList {
        val array = json.array("comments")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                UserComment(
                    id = item.optInt("id"),
                    content = item.string("content"),
                    createdAt = item.stringOrNull("created_at"),
                    postId = item.optInt("post_id"),
                    postTitle = item.string("post_title"),
                )
            )
        }
    }
    return UserPage(
        user = parseUser(json.optJSONObject("user")),
        stats = parseUserStats(json.optJSONObject("stats")),
        posts = parsePostList(json.array("posts")),
        comments = comments,
    )
}

internal fun parseVerifyStatus(json: JSONObject): VerifyStatus {
    val applications = buildList {
        val array = json.array("applications")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                VerifyApplication(
                    id = item.optInt("id"),
                    type = item.string("type"),
                    status = item.string("status"),
                    reason = item.string("reason"),
                    proof = item.string("proof"),
                    createdAt = item.stringOrNull("created_at"),
                    reviewedAt = item.stringOrNull("reviewed_at"),
                )
            )
        }
    }
    return VerifyStatus(parseBadges(json.array("certifications")), applications)
}

internal fun parseAbout(json: JSONObject): AboutData {
    val online = buildList {
        val array = json.array("online")
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { add(parseUser(it)) }
        }
    }
    val links = buildList {
        val array = json.array("links")
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            add(
                FriendLink(
                    id = item.optInt("id"),
                    name = item.string("name"),
                    url = item.string("url"),
                    description = item.string("description"),
                    tag = item.string("tag"),
                )
            )
        }
    }
    return AboutData(
        siteName = json.string("site_name", "lxlovo"),
        aboutContent = json.string("about_content"),
        stats = parseStats(json.optJSONObject("stats")),
        online = online,
        links = links,
    )
}

internal fun parseSearch(json: JSONObject): SearchResult {
    val users = buildList {
        val array = json.array("users")
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { add(parseUser(it)) }
        }
    }
    return SearchResult(
        posts = parsePostList(json.array("posts")),
        users = users,
        boards = parseBoards(json.array("boards")),
    )
}
