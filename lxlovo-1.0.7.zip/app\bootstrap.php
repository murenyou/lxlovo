<?php

define('LXL_ROOT', dirname(__DIR__));
define('LXL_APP', __DIR__);
define('LXL_VIEWS', LXL_ROOT . '/views');
define('LXL_UPLOADS', LXL_ROOT . '/uploads');
define('LXL_VERSION', '1.0.7');

$GLOBALS['lxl_config'] = require dirname(__DIR__) . '/config.php';
$appConfig = $GLOBALS['lxl_config']['app'];

date_default_timezone_set($appConfig['timezone'] ?? 'Asia/Shanghai');
mb_internal_encoding('UTF-8');
mb_language('uni');

if (($appConfig['debug'] ?? false) === true) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
}

$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
    || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
    || (($_SERVER['SERVER_PORT'] ?? '') === '443');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name($appConfig['session_name'] ?? 'lxlovo_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require LXL_APP . '/db.php';
require LXL_APP . '/helpers.php';
require LXL_APP . '/content.php';
require LXL_APP . '/auth.php';
require LXL_APP . '/mailer.php';
require LXL_APP . '/notifications.php';
require LXL_APP . '/app_releases.php';

$basePath = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
if ($basePath === '.' || $basePath === '/') {
    $basePath = '';
}
define('LXL_BASE_PATH', $basePath);

try {
    db()->query('SELECT 1');
} catch (Throwable $e) {
    http_response_code(503);
    $message = $appConfig['debug'] ?? false ? htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') : '';
    echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>lxlovo 路 鏁版嵁搴撴湭杩炴帴</title><style>body{font-family:system-ui,-apple-system,"Segoe UI","Microsoft YaHei",sans-serif;background:#fbf8ff;color:#1b1b21;display:grid;place-items:center;min-height:100vh;margin:0}.box{max-width:520px;padding:36px;border-radius:28px;background:#fff;box-shadow:0 12px 40px rgba(0,0,0,.08)}h1{font-size:24px;margin:0 0 12px}p{line-height:1.8;color:#46464f}code{background:#f0edf7;border-radius:8px;padding:2px 6px}</style><div class="box"><h1>lxlovo 鏆傛椂鏃犳硶杩炴帴鏁版嵁搴?/h1><p>璇峰厛瀵煎叆 <code>install.sql</code>锛屽苟妫€鏌?<code>config.php</code> 涓殑鏁版嵁搴撹处鍙蜂笌瀵嗙爜銆?/p><p>' . $message . '</p></div></html>';
    exit;
}

if (PHP_SAPI !== 'cli') {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

set_exception_handler(function (Throwable $e): void {
    error_log('[lxlovo] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    $debug = (bool) ($GLOBALS['lxl_config']['app']['debug'] ?? false);
    if ($debug) {
        echo '<pre style="padding:24px;white-space:pre-wrap">' . htmlspecialchars((string) $e, ENT_QUOTES, 'UTF-8') . '</pre>';
        return;
    }
    echo '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>鏈嶅姟鍣ㄥ紑灏忓樊浜?/title><body style="font-family:system-ui,-apple-system,\'Microsoft YaHei\',sans-serif;background:#fbf8ff;color:#1b1b21;display:grid;place-items:center;min-height:100vh;margin:0"><div style="background:#fff;padding:36px;border-radius:28px;box-shadow:0 12px 40px rgba(0,0,0,.08);text-align:center"><div style="font-size:44px">鉁?/div><h1 style="font-size:22px">鏈嶅姟鍣ㄥ紑灏忓樊浜?/h1><p style="color:#46464f">璇风◢鍚庡埛鏂伴噸璇曘€?/p><a href="' . htmlspecialchars(base_url() . '/', ENT_QUOTES, 'UTF-8') . '" style="color:#4f5bd5">杩斿洖棣栭〉</a></div></body></html>';
});
