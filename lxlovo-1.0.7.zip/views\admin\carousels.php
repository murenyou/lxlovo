<?php ?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Appearance</span><h2>首页轮播</h2><p>支持图片地址或直接上传，建议尺寸 1920×800。</p></div></div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>新增轮播</h3><span>图片会自动压缩</span></div>
    <form action="<?= e(admin_url('carousel.save')) ?>" method="post" enctype="multipart/form-data" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">标题</span><span class="field__box"><input type="text" name="title" maxlength="100" required></span></label>
            <label class="field"><span class="field__label">副标题</span><span class="field__box"><input type="text" name="subtitle" maxlength="200"></span></label>
            <label class="field"><span class="field__label">图片地址</span><span class="field__box"><input type="text" name="image" placeholder="assets/img/banner-1.svg 或 https://…"></span></label>
            <label class="field"><span class="field__label">上传图片</span><span class="field__box"><input type="file" name="image_file" accept="image/jpeg,image/png,image/webp,image/gif"></span></label>
            <label class="field"><span class="field__label">跳转链接</span><span class="field__box"><input type="text" name="link" placeholder="index.php?r=about 或 https://…"></span></label>
            <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="10"></span></label>
            <label class="check-line"><input type="checkbox" name="enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">添加轮播</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <div class="admin-edit-row__preview"><img src="<?= e(media_url($item['image'])) ?>" alt=""></div>
                <div><h3><?= e($item['title']) ?></h3><p><?= $item['enabled'] ? '启用中' : '已停用' ?> · 排序 <?= (int) $item['sort'] ?></p></div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('carousel.save')) ?>" method="post" enctype="multipart/form-data" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">标题</span><span class="field__box"><input type="text" name="title" value="<?= e($item['title']) ?>" maxlength="100" required></span></label>
                                <label class="field"><span class="field__label">副标题</span><span class="field__box"><input type="text" name="subtitle" value="<?= e($item['subtitle']) ?>" maxlength="200"></span></label>
                                <label class="field"><span class="field__label">图片地址</span><span class="field__box"><input type="text" name="image" value="<?= e($item['image']) ?>"></span></label>
                                <label class="field"><span class="field__label">替换图片</span><span class="field__box"><input type="file" name="image_file" accept="image/jpeg,image/png,image/webp,image/gif"></span></label>
                                <label class="field"><span class="field__label">跳转链接</span><span class="field__box"><input type="text" name="link" value="<?= e($item['link']) ?>"></span></label>
                                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) $item['sort'] ?>"></span></label>
                                <label class="check-line"><input type="checkbox" name="enabled" value="1" <?= $item['enabled'] ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('carousel.delete')) ?>" method="post" data-confirm="确定删除这张轮播图吗？" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$items): ?><div class="admin-empty">还没有轮播图。</div><?php endif; ?>
