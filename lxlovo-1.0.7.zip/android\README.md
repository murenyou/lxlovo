# lxlovo Android

lxlovo 官方 Android 客户端，包名 `com.bbs.lxlovo.top`。

## 技术结构

- Kotlin 2.0.21
- Jetpack Compose + Material 3
- AGP 8.4.0 / Gradle 8.7 / JDK 17
- compileSdk 35，minSdk 24，targetSdk 35
- OkHttp 4.12.0 + Coil 2.7.0
- 纯原生页面，不使用 WebView 承载论坛
- JSON API + Bearer Token 登录，与网站共用 MySQL 数据

## 原生页面

- 首页：轮播、公告、板块、置顶、最新、热门、精华、随机推荐、社区数据
- 文章：板块筛选、排序、分页
- 文章详情：封面、正文、点赞、收藏、打赏、评论、回复、评论点赞、相关文章
- 发帖 / 编辑：板块、标题、正文、封面图
- 帖子管理：编辑、删除、精华
- 评论管理：置顶、删除
- 搜索：帖子、用户、板块
- 登录 / 注册
- 我的：等级、认证、经验、金币、签到、统计、最近文章、资料编辑
- 账号与安全：头像上传、修改密码、更换邮箱、邮箱验证、通知偏好
- 认证中心：用户认证、赞助认证、申请记录
- 我的收藏、我的文章
- 在线用户、论坛板块、关于页面、友情链接
- 通知、私信会话、私信聊天
- 设置、更新日志、应用内更新

正文使用原生 TextView 渲染安全 HTML，不启动 WebView。只有「内置浏览器」打开站外链接和更新页面时使用 WebView。

## 构建

```bash
cd android
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

需要：

- Android SDK Platform 35
- Build Tools 35.0.0
- JDK 17
- Gradle Wrapper 8.7（已附带）

首次构建前，将 `local.properties.example` 复制为 `local.properties`，并填写本机 Android SDK 路径。

## 签名

当前 release 构建使用 debug keystore 签名，便于直接安装测试。正式发布前请创建自己的 release keystore，并修改 `app/build.gradle` 的 signingConfig。

## 接口

```text
GET https://bbs.lxlovo.top/api.php?action=app.version&version_code=107&version_name=1.0.7
```

版本信息与更新内容在网站后台「App 管理」中维护。APK 默认放置于：

```text
https://bbs.lxlovo.top/download/lxlovo-1.0.7.apk
```

## 更新规则

- 强制更新：弹窗不可关闭，必须更新。
- 普通更新：可以点击「下次更新」。
- 直链 APK：应用内下载并显示进度，完成后调用系统安装器。
- 网页链接：打开内置浏览器；如果用户在设置中关闭内置浏览器，则使用系统浏览器。
- 更新日志：设置中展示后台全部启用版本的累计更新内容。
