<?php ?>
<div class="admin-empty admin-empty--page"><?= icon('info', '', 38) ?><h3>后台页面不存在</h3><p>请从左侧导航重新进入。</p><a class="btn btn--primary btn--sm" href="<?= e(admin_url()) ?>">回到控制台</a></div>
