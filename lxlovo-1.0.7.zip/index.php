<?php

require __DIR__ . '/app/bootstrap.php';
require LXL_APP . '/site_actions.php';
require LXL_APP . '/site_pages.php';

$route = (string) ($_GET['r'] ?? 'home');
if (!preg_match('/^[a-zA-Z0-9_.-]{1,60}$/', $route)) {
    $route = 'home';
}

if (is_post()) {
    verify_csrf();
    site_action($route);
    exit;
}

site_page($route);
