package com.bbs.lxlovo.top.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.CameraAlt
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.UserBadges
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    api: ApiClient,
    user: User,
    onBack: () -> Unit,
    onUserUpdated: (User) -> Unit,
    onOpenVerify: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var profile by remember { mutableStateOf(user) }
    var uploading by remember { mutableStateOf(false) }
    var passwordOpen by remember { mutableStateOf(false) }
    var emailOpen by remember { mutableStateOf(false) }
    var sendingVerify by remember { mutableStateOf(false) }
    var refreshingEmail by remember { mutableStateOf(false) }
    var notifyComment by remember { mutableStateOf(user.notifyComment) }
    var notifyMention by remember { mutableStateOf(user.notifyMention) }
    var notifyMessage by remember { mutableStateOf(user.notifyMessage) }
    var notifySystem by remember { mutableStateOf(user.notifySystem) }
    var notifyEmail by remember { mutableStateOf(user.notifyEmail) }
    var showBadge by remember { mutableStateOf(user.showOfficialBadge) }
    var savingPreferences by remember { mutableStateOf(false) }

    LaunchedEffect(user) {
        profile = user
        notifyComment = user.notifyComment
        notifyMention = user.notifyMention
        notifyMessage = user.notifyMessage
        notifySystem = user.notifySystem
        notifyEmail = user.notifyEmail
        showBadge = user.showOfficialBadge
    }

    fun applyUser(updated: User) {
        profile = updated
        onUserUpdated(updated)
    }

    val avatarPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null || uploading) return@rememberLauncherForActivityResult
        uploading = true
        scope.launch {
            try {
                val updated = api.uploadAvatar(uri)
                applyUser(updated)
                snackbar.showSnackbar("头像已更新")
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "头像上传失败")
            } finally {
                uploading = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("账号与安全") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(22.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        LxlovoAvatar(profile, 92)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            profile.username,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                        )
                        Text(
                            "ID ${profile.id} · Lv.${profile.level} ${profile.levelName}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f),
                        )
                        Spacer(Modifier.height(8.dp))
                        UserBadges(profile, 4)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { avatarPicker.launch("image/*") },
                            enabled = !uploading,
                        ) {
                            if (uploading) {
                                CircularProgressIndicator(
                                    Modifier.size(16.dp),
                                    strokeWidth = 2.dp,
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                                Spacer(Modifier.width(6.dp))
                            } else {
                                Icon(Icons.Outlined.CameraAlt, contentDescription = null, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(if (uploading) "上传中" else "更换头像")
                        }
                    }
                }
            }

            item { SectionHeader("账号") }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                ) {
                    Column {
                        ListItem(
                            headlineContent = { Text("邮箱") },
                            supportingContent = {
                                Text(profile.email.ifBlank { "未绑定邮箱" })
                            },
                            leadingContent = { Icon(Icons.Outlined.Email, contentDescription = null) },
                            trailingContent = {
                                if (profile.emailVerified) {
                                    Surface(
                                        shape = androidx.compose.foundation.shape.RoundedCornerShape(50),
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                    ) {
                                        Text(
                                            "已验证",
                                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        )
                                    }
                                } else {
                                    Text("未验证", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ListItem(
                            headlineContent = { Text("更换邮箱") },
                            supportingContent = { Text("需要输入当前密码确认") },
                            leadingContent = { Icon(Icons.Outlined.Email, contentDescription = null) },
                            trailingContent = { TextButton(onClick = { emailOpen = true }) { Text("更换") } },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                        if (!profile.emailVerified) {
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ListItem(
                                headlineContent = { Text("发送验证邮件") },
                                supportingContent = { Text("验证链接 24 小时内有效") },
                                leadingContent = { Icon(Icons.Outlined.Verified, contentDescription = null) },
                                trailingContent = {
                                    if (sendingVerify) {
                                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    } else {
                                        TextButton(onClick = {
                                            sendingVerify = true
                                            scope.launch {
                                                try {
                                                    snackbar.showSnackbar(api.resendVerification())
                                                } catch (exception: Exception) {
                                                    snackbar.showSnackbar(exception.message ?: "发送失败")
                                                } finally {
                                                    sendingVerify = false
                                                }
                                            }
                                        }) { Text("发送") }
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            )
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                            ListItem(
                                headlineContent = { Text("刷新邮箱状态") },
                                supportingContent = { Text("完成邮箱验证后点此刷新") },
                                leadingContent = { Icon(Icons.Outlined.Verified, contentDescription = null) },
                                trailingContent = {
                                    if (refreshingEmail) {
                                        CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    } else {
                                        TextButton(onClick = {
                                            refreshingEmail = true
                                            scope.launch {
                                                try {
                                                    val data = api.me()
                                                    applyUser(data.user)
                                                    snackbar.showSnackbar(
                                                        if (data.user.emailVerified) "邮箱已验证" else "邮箱还未验证"
                                                    )
                                                } catch (exception: Exception) {
                                                    snackbar.showSnackbar(exception.message ?: "刷新失败")
                                                } finally {
                                                    refreshingEmail = false
                                                }
                                            }
                                        }) { Text("刷新") }
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                            )
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ListItem(
                            headlineContent = { Text("修改密码") },
                            supportingContent = { Text("定期更换密码更安全") },
                            leadingContent = { Icon(Icons.Outlined.Lock, contentDescription = null) },
                            trailingContent = { TextButton(onClick = { passwordOpen = true }) { Text("修改") } },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                    }
                }
            }

            item { SectionHeader("通知偏好") }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                ) {
                    Column {
                        PreferenceSwitch("评论与回复", notifyComment) { notifyComment = it }
                        PreferenceSwitch("提到我", notifyMention) { notifyMention = it }
                        PreferenceSwitch("私信", notifyMessage) { notifyMessage = it }
                        PreferenceSwitch("系统消息", notifySystem) { notifySystem = it }
                        PreferenceSwitch("邮件提醒", notifyEmail) { notifyEmail = it }
                        PreferenceSwitch("展示认证标识", showBadge) { showBadge = it }
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.End,
                        ) {
                            Button(
                                onClick = {
                                    if (!savingPreferences) {
                                        savingPreferences = true
                                        scope.launch {
                                            try {
                                                val updated = api.updateProfile(
                                                    profile.bio,
                                                    showBadge,
                                                    notifyComment,
                                                    notifyMention,
                                                    notifyMessage,
                                                    notifySystem,
                                                    notifyEmail,
                                                )
                                                applyUser(updated)
                                                snackbar.showSnackbar("通知偏好已保存")
                                            } catch (exception: Exception) {
                                                snackbar.showSnackbar(exception.message ?: "保存失败")
                                            } finally {
                                                savingPreferences = false
                                            }
                                        }
                                    }
                                },
                                enabled = !savingPreferences,
                            ) {
                                if (savingPreferences) {
                                    CircularProgressIndicator(
                                        Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                } else {
                                    Text("保存通知偏好")
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                ) {
                    ListItem(
                        headlineContent = { Text("认证中心") },
                        supportingContent = {
                            Text(
                                if (profile.badges.isEmpty()) "申请用户认证 / 赞助认证"
                                else "已获得 ${profile.badges.size} 个认证"
                            )
                        },
                        leadingContent = { Icon(Icons.Outlined.Verified, contentDescription = null) },
                        trailingContent = { TextButton(onClick = onOpenVerify) { Text("进入") } },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                }
            }
        }
    }

    if (passwordOpen) {
        PasswordDialog(
            onDismiss = { passwordOpen = false },
            onSubmit = { old, new, confirm ->
                scope.launch {
                    try {
                        snackbar.showSnackbar(api.changePassword(old, new, confirm))
                        passwordOpen = false
                    } catch (exception: Exception) {
                        snackbar.showSnackbar(exception.message ?: "修改失败")
                    }
                }
            },
        )
    }

    if (emailOpen) {
        EmailDialog(
            onDismiss = { emailOpen = false },
            onSubmit = { email, password ->
                scope.launch {
                    try {
                        val (message, updated) = api.changeEmail(email, password)
                        applyUser(updated)
                        snackbar.showSnackbar(message)
                        emailOpen = false
                    } catch (exception: Exception) {
                        snackbar.showSnackbar(exception.message ?: "更换失败")
                    }
                }
            },
        )
    }
}

@Composable
private fun PreferenceSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChange) },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
    )
}

@Composable
private fun PasswordDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String, String) -> Unit,
) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("修改密码") },
        text = {
            Column {
                OutlinedTextField(
                    value = old,
                    onValueChange = { old = it },
                    label = { Text("当前密码") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = new,
                    onValueChange = { new = it },
                    label = { Text("新密码（至少 8 位）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it },
                    label = { Text("确认新密码") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                )
                TextButton(onClick = { show = !show }) {
                    Text(if (show) "隐藏密码" else "显示密码")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                busy = true
                onSubmit(old, new, confirm)
                busy = false
            }) { Text("保存") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("取消") } },
    )
}

@Composable
private fun EmailDialog(
    onDismiss: () -> Unit,
    onSubmit: (String, String) -> Unit,
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("更换邮箱") },
        text = {
            Column {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it.trim() },
                    label = { Text("新邮箱") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("当前密码") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    visualTransformation = PasswordVisualTransformation(),
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                busy = true
                onSubmit(email, password)
                busy = false
            }) { Text("确认更换") }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !busy) { Text("取消") } },
    )
}
