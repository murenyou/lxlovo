package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.MailOutline
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.UserPage
import com.bbs.lxlovo.top.ui.BoardPill
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.PostCard
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.UserBadges

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UserProfileScreen(
    api: ApiClient,
    userId: Int,
    currentUserId: Int?,
    onBack: () -> Unit,
    onPostClick: (Int) -> Unit,
    onMessage: (Int) -> Unit,
    onLogin: () -> Unit,
) {
    var data by remember { mutableStateOf<UserPage?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(userId) {
        loading = true
        error = null
        try {
            data = api.user(userId)
        } catch (exception: Exception) {
            error = exception.message ?: "用户资料加载失败。"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(data?.user?.username ?: "用户") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
    ) { padding ->
        when {
            loading && data == null -> LoadingBox(Modifier.padding(padding))
            error != null && data == null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                ErrorBox(error!!)
            }
            data == null -> EmptyBox("用户不存在", Modifier.padding(padding))
            else -> {
                val page = data!!
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(26.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    LxlovoAvatar(page.user, 76)
                                    Spacer(Modifier.width(16.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                page.user.username,
                                                style = MaterialTheme.typography.headlineSmall,
                                                fontWeight = FontWeight.ExtraBold,
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            BoardPill("Lv.${page.user.level}", page.user.levelColor)
                                        }
                                        Text(
                                            page.user.levelName,
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f),
                                        )
                                        Spacer(Modifier.height(6.dp))
                                        UserBadges(page.user, 3)
                                    }
                                }
                                if (page.user.bio.isNotBlank()) {
                                    Spacer(Modifier.height(14.dp))
                                    Text(page.user.bio, style = MaterialTheme.typography.bodyMedium)
                                }
                                Spacer(Modifier.height(14.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                                    MiniStat("发帖", page.stats.posts)
                                    MiniStat("评论", page.stats.comments)
                                    MiniStat("获赞", page.stats.likes)
                                }
                                Spacer(Modifier.height(14.dp))
                                if (currentUserId == null) {
                                    Button(onClick = onLogin) {
                                        Icon(Icons.Outlined.MailOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("登录后私信")
                                    }
                                } else if (currentUserId != page.user.id) {
                                    Button(onClick = { onMessage(page.user.id) }) {
                                        Icon(Icons.Outlined.MailOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("发私信")
                                    }
                                }
                            }
                        }
                    }
                    item { SectionHeader("发布的文章") }
                    if (page.posts.isEmpty()) {
                        item { EmptyBox("还没有发布文章") }
                    } else {
                        items(page.posts, key = { it.id }) { post ->
                            PostCard(post, { onPostClick(post.id) }, {})
                        }
                    }
                    if (page.comments.isNotEmpty()) {
                        item { SectionHeader("最近评论") }
                        items(page.comments, key = { "comment-${it.id}" }) { comment ->
                            Card(
                                modifier = Modifier.fillMaxWidth().clickable { onPostClick(comment.postId) },
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                                shape = RoundedCornerShape(18.dp),
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        "评论于《${comment.postTitle}》",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary,
                                        maxLines = 1,
                                    )
                                    Spacer(Modifier.height(4.dp))
                                    Text(comment.content, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MiniStat(label: String, value: Int) {
    Column {
        Text(
            value.toString(),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
        )
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
        )
    }
}
