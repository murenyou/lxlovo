package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Login
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.MeData
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.BoardPill
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.PostCard
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.UserBadges
import kotlinx.coroutines.launch

@Composable
fun ProfileScreen(
    api: ApiClient,
    user: User?,
    me: MeData?,
    loading: Boolean,
    loggedIn: Boolean,
    onLogin: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenMessages: () -> Unit,
    onOpenSettings: () -> Unit,
    onPostClick: (Int) -> Unit,
    onUserUpdated: (User) -> Unit,
    onRefreshMe: () -> Unit,
    modifier: Modifier = Modifier,
) {
    if (user == null) {
        if (loggedIn && loading) {
            Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return
        }
        Column(
            modifier = modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Icon(
                Icons.Outlined.Forum,
                contentDescription = null,
                modifier = Modifier.size(64.dp),
                tint = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.height(16.dp))
            Text("还没有登录", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(
                "登录后可以发帖、评论、签到和收发私信",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(18.dp))
            Button(onClick = onLogin) {
                Icon(Icons.Outlined.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("登录 / 注册")
            }
            Spacer(Modifier.height(10.dp))
            TextButton(onClick = onOpenSettings) { Text("设置") }
        }
        return
    }

    if (me == null || loading) {
        Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val profile = me.user
    val scope = rememberCoroutineScope()
    var checkingIn by remember { mutableStateOf(false) }
    var checkinMessage by remember { mutableStateOf<String?>(null) }
    var checkinError by remember { mutableStateOf<String?>(null) }
    var editOpen by remember { mutableStateOf(false) }
    var bioDraft by remember { mutableStateOf(profile.bio) }
    var bioSaving by remember { mutableStateOf(false) }
    var bioError by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 28.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        LxlovoAvatar(profile, 72)
                        Spacer(Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    profile.username,
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                )
                                Spacer(Modifier.width(8.dp))
                                BoardPill("Lv.${profile.level}", profile.levelColor)
                            }
                            Text(
                                profile.levelName,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f),
                            )
                            Spacer(Modifier.height(6.dp))
                            UserBadges(profile, 3)
                        }
                    }
                    if (profile.bio.isNotBlank()) {
                        Spacer(Modifier.height(14.dp))
                        Text(
                            profile.bio,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                    TextButton(onClick = {
                        bioDraft = profile.bio
                        bioError = null
                        editOpen = true
                    }) {
                        Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("编辑资料")
                    }
                    Spacer(Modifier.height(14.dp))
                    LinearProgressIndicator(
                        progress = { profile.levelProgress / 100f },
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.16f),
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        "经验 ${profile.exp} · 距离下一级还差 ${profile.toNext}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                    )
                }
            }
        }

        if (!profile.emailVerified) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Outlined.Email,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "邮箱尚未验证。部分发帖、评论功能可能受限，请前往网站完成验证。",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                }
            }
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                StatCard("发帖", me.stats.posts, Modifier.weight(1f))
                StatCard("评论", me.stats.comments, Modifier.weight(1f))
                StatCard("获赞", me.stats.likes, Modifier.weight(1f))
                StatCard("收藏", me.stats.favorites, Modifier.weight(1f))
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("每日签到", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                if (me.checkedInToday) {
                                    "今天已签到 · 连续 ${profile.checkinStreak} 天"
                                } else {
                                    "连续签到可获得经验与金币"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                        if (me.checkedInToday) {
                            Surface(
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer,
                            ) {
                                Text(
                                    "已签到",
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                        } else {
                            Button(
                                onClick = {
                                    if (checkingIn) return@Button
                                    checkingIn = true
                                    checkinError = null
                                    checkinMessage = null
                                    scope.launch {
                                        try {
                                            val result = api.checkin()
                                            checkinMessage = result.message
                                            onUserUpdated(result.user)
                                            onRefreshMe()
                                        } catch (exception: Exception) {
                                            checkinError = exception.message ?: "签到失败。"
                                        } finally {
                                            checkingIn = false
                                        }
                                    }
                                },
                                enabled = !checkingIn,
                            ) {
                                if (checkingIn) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                } else {
                                    Text("签到")
                                }
                            }
                        }
                    }
                    if (checkinMessage != null || checkinError != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            checkinError ?: checkinMessage!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (checkinError != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(
                        "金币 ${profile.coins} · 经验 ${profile.exp}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = androidx.compose.foundation.shape.RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            ) {
                Column {
                    QuickAction(
                        icon = Icons.Outlined.Notifications,
                        title = "通知",
                        subtitle = if (me.unreadNotifications > 0) "${me.unreadNotifications} 条未读" else "查看全部通知",
                        onClick = onOpenNotifications,
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    QuickAction(
                        icon = Icons.Outlined.Forum,
                        title = "私信",
                        subtitle = if (me.unreadMessages > 0) "${me.unreadMessages} 条未读" else "和社区成员聊天",
                        onClick = onOpenMessages,
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    QuickAction(
                        icon = Icons.Outlined.Settings,
                        title = "设置",
                        subtitle = "账号、浏览器、更新",
                        onClick = onOpenSettings,
                    )
                }
            }
        }

        item { SectionHeader("最近发布") }
        if (me.recentPosts.isEmpty()) {
            item { EmptyBox("还没有发布过文章") }
        } else {
            items(me.recentPosts, key = { it.id }) { post ->
                PostCard(post, { onPostClick(post.id) }, {})
            }
        }
    }

    if (editOpen) {
        AlertDialog(
            onDismissRequest = { if (!bioSaving) editOpen = false },
            title = { Text("编辑资料") },
            text = {
                Column {
                    OutlinedTextField(
                        value = bioDraft,
                        onValueChange = { bioDraft = it.take(500) },
                        label = { Text("个人简介") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 6,
                    )
                    if (bioError != null) {
                        Spacer(Modifier.height(8.dp))
                        Text(bioError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (!bioSaving) {
                            bioSaving = true
                            bioError = null
                            scope.launch {
                                try {
                                    val updated = api.updateProfile(
                                        bioDraft.trim(),
                                        profile.showOfficialBadge,
                                        profile.notifyComment,
                                        profile.notifyMention,
                                        profile.notifyMessage,
                                        profile.notifySystem,
                                        profile.notifyEmail,
                                    )
                                    onUserUpdated(updated)
                                    onRefreshMe()
                                    editOpen = false
                                } catch (exception: Exception) {
                                    bioError = exception.message ?: "保存失败。"
                                } finally {
                                    bioSaving = false
                                }
                            }
                        }
                    },
                    enabled = !bioSaving,
                ) {
                    if (bioSaving) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    } else {
                        Text("保存")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { editOpen = false }, enabled = !bioSaving) { Text("取消") }
            },
        )
    }
}

@Composable
private fun StatCard(label: String, value: Int, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(
                value.toString(),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
            )
            Text(
                label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun QuickAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
            Text(
                subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        Icon(
            Icons.Outlined.ChevronRight,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.outline,
        )
    }
}
