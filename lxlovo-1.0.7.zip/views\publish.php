<?php
$isEdit = $post !== null;
$titleValue = old('title', $post['title'] ?? '');
$boardValue = (int) old('board_id', (string) ($post['board_id'] ?? ($boards[0]['id'] ?? 0)));
$contentValue = sanitize_html((string) old('content', $post['content'] ?? ''));
?>
<div class="editor-head">
    <div>
        <a class="text-link" href="<?= e($isEdit ? url('post', ['id' => (int) $post['id']]) : url('posts')) ?>"><?= icon('arrow_back', '', 17) ?>返回</a>
        <h1><?= $isEdit ? '编辑文章' : '发布文章' ?></h1>
        <p><?= $isEdit ? '修改完成后记得保存。' : '认真写下标题和正文，让内容被更多人看见。' ?></p>
    </div>
    <span class="editor-head__badge"><?= icon('edit', '', 18) ?><?= $isEdit ? 'Editing' : 'New post' ?></span>
</div>

<div class="editor-layout">
    <form class="editor-card" action="<?= e(url('post.save')) ?>" method="post" id="post-form">
        <?= csrf_field() ?>
        <?php if ($isEdit): ?><input type="hidden" name="id" value="<?= (int) $post['id'] ?>"><?php endif; ?>
        <label class="field field--title">
            <span class="field__label">标题</span>
            <span class="field__box field__box--plain"><input type="text" name="title" value="<?= e($titleValue) ?>" placeholder="一个清晰、真诚的标题" maxlength="120" required autofocus></span>
        </label>

        <div class="editor-board">
            <span class="editor-board__label">发布到</span>
            <div class="board-options">
                <?php foreach ($boards as $boardItem): ?>
                    <label class="board-option">
                        <input type="radio" name="board_id" value="<?= (int) $boardItem['id'] ?>" <?= $boardValue === (int) $boardItem['id'] ? 'checked' : '' ?>>
                        <span style="--board-color:<?= e($boardItem['color']) ?>"><?= icon($boardItem['icon'] ?: 'board', '', 17) ?><?= e($boardItem['name']) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="rich-editor" id="rich-editor" data-max-kb="<?= setting_int('upload_max_kb', 100) ?>">
            <div class="rich-toolbar" role="toolbar" aria-label="编辑器工具栏">
                <button type="button" class="tool-btn" data-cmd="bold" title="加粗"><strong>B</strong></button>
                <button type="button" class="tool-btn" data-cmd="italic" title="斜体"><em>I</em></button>
                <button type="button" class="tool-btn" data-cmd="underline" title="下划线"><u>U</u></button>
                <button type="button" class="tool-btn" data-cmd="strikeThrough" title="删除线"><s>S</s></button>
                <span class="tool-divider"></span>
                <button type="button" class="tool-btn tool-btn--text" data-block="h2" title="大标题">H2</button>
                <button type="button" class="tool-btn tool-btn--text" data-block="h3" title="小标题">H3</button>
                <button type="button" class="tool-btn" data-block="blockquote" title="引用"><?= icon('comment', '', 18) ?></button>
                <button type="button" class="tool-btn" data-cmd="insertUnorderedList" title="无序列表"><?= icon('filter', '', 18) ?></button>
                <button type="button" class="tool-btn" data-cmd="insertOrderedList" title="有序列表">1.</button>
                <span class="tool-divider"></span>
                <label class="tool-color" title="字体颜色"><span>A</span><input type="color" value="#4F5BD5" data-fore-color></label>
                <select class="tool-select" data-font-size title="字体大小">
                    <option value="">字号</option>
                    <option value="2">小</option>
                    <option value="3">正常</option>
                    <option value="5">大</option>
                    <option value="6">特大</option>
                </select>
                <span class="tool-divider"></span>
                <button type="button" class="tool-btn" data-insert="link" title="插入链接"><?= icon('link', '', 18) ?></button>
                <button type="button" class="tool-btn" data-insert="image" title="插入图片链接"><?= icon('image', '', 18) ?></button>
                <button type="button" class="tool-btn" data-insert="video" title="插入视频链接"><?= icon('video', '', 18) ?></button>
                <?php if ($canUpload): ?>
                    <button type="button" class="tool-btn tool-btn--upload" data-upload-image title="上传图片（≤<?= setting_int('upload_max_kb', 100) ?>KB）"><?= icon('upload', '', 18) ?><span>上传</span></button>
                <?php endif; ?>
                <span class="tool-divider"></span>
                <button type="button" class="tool-btn" data-cmd="removeFormat" title="清除格式"><?= icon('refresh', '', 18) ?></button>
                <button type="button" class="tool-btn" data-cmd="undo" title="撤销">↶</button>
                <button type="button" class="tool-btn" data-cmd="redo" title="重做">↷</button>
            </div>
            <div class="rich-content" id="rich-content" contenteditable="true" role="textbox" aria-multiline="true" data-placeholder="写下你的内容…"></div>
            <textarea name="content" id="content-source" hidden><?= e($contentValue) ?></textarea>
            <input type="file" id="editor-image-input" accept="image/jpeg,image/png,image/webp,image/gif" hidden>
            <div class="editor-status">
                <span id="editor-word-count">0 字</span>
                <?php if ($canUpload): ?>
                    <span><?= icon('camera', '', 14) ?>可上传图片，自动压缩至 <?= setting_int('upload_max_kb', 100) ?>KB 内</span>
                <?php else: ?>
                    <span><?= icon('link', '', 14) ?>可插入外链图片，上传权限仅向官方 / 赞助认证开放</span>
                <?php endif; ?>
            </div>
        </div>

        <div class="editor-submit">
            <span class="muted-text">发布即表示你同意社区约定，并对内容负责。</span>
            <div>
                <?php if ($isEdit): ?><a class="btn btn--text" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>">取消</a><?php endif; ?>
                <button class="btn btn--primary" type="submit"><?= icon('send', '', 18) ?><?= $isEdit ? '保存修改' : '发布文章' ?></button>
            </div>
        </div>
    </form>

    <aside class="editor-side">
        <section class="side-card">
            <div class="side-card__head"><h2>发布须知</h2></div>
            <ul class="tips-list">
                <li>标题应准确概括内容，避免夸张诱导。</li>
                <li>尊重原创，转载或引用请注明来源。</li>
                <li>图片与视频请使用有效链接，不发布侵权内容。</li>
                <li>技术内容建议附上环境与复现步骤。</li>
            </ul>
        </section>
        <section class="side-card">
            <div class="side-card__head"><h2>权限说明</h2></div>
            <p class="muted-text">所有用户都可以发布文章和插入外链图片。官方认证与赞助认证账号可以上传本地图片，系统会自动压缩，单张不超过 <?= setting_int('upload_max_kb', 100) ?>KB。</p>
            <a class="text-link" href="<?= e(url('verify')) ?>">了解账号认证<?= icon('chevron_right', '', 16) ?></a>
        </section>
        <?php if ($isEdit): ?>
            <section class="side-card danger-zone">
                <div class="side-card__head"><h2>删除文章</h2></div>
                <p class="muted-text">删除后不会出现在前台，但数据仍会保留。</p>
                <form action="<?= e(url('post.delete')) ?>" method="post" data-confirm="确定删除这篇帖子吗？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int) $post['id'] ?>">
                    <button class="btn btn--danger btn--sm btn--full" type="submit"><?= icon('trash', '', 17) ?>删除帖子</button>
                </form>
            </section>
        <?php endif; ?>
    </aside>
</div>

<dialog class="dialog" id="insert-dialog">
    <div class="dialog__head">
        <div><span class="dialog__eyebrow" id="insert-dialog-eyebrow">插入内容</span><h2 id="insert-dialog-title">插入链接</h2></div>
        <button class="icon-btn" type="button" data-close-dialog aria-label="关闭"><?= icon('close') ?></button>
    </div>
    <form id="insert-form">
        <label class="field">
            <span class="field__label" id="insert-url-label">链接地址</span>
            <span class="field__box"><?= icon('link') ?><input type="url" id="insert-url" placeholder="https://" required></span>
        </label>
        <label class="field" id="insert-text-field">
            <span class="field__label">显示文字</span>
            <span class="field__box"><?= icon('edit') ?><input type="text" id="insert-text" placeholder="可选" maxlength="120"></span>
        </label>
        <p class="dialog__hint" id="insert-hint">支持插入站外链接。视频支持 Bilibili、YouTube、腾讯视频、优酷。</p>
        <div class="dialog__actions">
            <button class="btn btn--text" type="button" data-close-dialog>取消</button>
            <button class="btn btn--primary" type="submit">插入</button>
        </div>
    </form>
</dialog>
