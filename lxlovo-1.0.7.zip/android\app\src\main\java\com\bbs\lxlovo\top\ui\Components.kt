package com.bbs.lxlovo.top.ui

import android.graphics.Color as AndroidColor
import android.text.method.LinkMovementMethod
import android.view.ViewGroup
import android.widget.TextView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.text.HtmlCompat
import coil.compose.AsyncImage
import com.bbs.lxlovo.top.BuildConfig
import com.bbs.lxlovo.top.data.Post
import com.bbs.lxlovo.top.data.User
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun LxlovoAvatar(
    user: User,
    size: Int = 40,
    modifier: Modifier = Modifier,
) {
    val fallback = MaterialTheme.colorScheme.primaryContainer
    Box(
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(fallback),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            user.username.take(1).ifBlank { "l" },
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.Bold,
            fontSize = (size * 0.38f).sp,
        )
        if (user.avatarUrl.isNotBlank()) {
            AsyncImage(
                model = user.avatarUrl,
                contentDescription = user.username,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop,
                placeholder = ColorPainter(Color.Transparent),
                error = ColorPainter(Color.Transparent),
            )
        }
    }
}

@Composable
fun UserNameLine(
    user: User,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
) {
    Row(
        modifier = modifier.then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            user.username,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        if (user.levelName.isNotBlank()) {
            Spacer(Modifier.width(6.dp))
            LevelChip(user)
        }
    }
}

@Composable
fun LevelChip(user: User) {
    Surface(
        shape = RoundedCornerShape(50),
        color = parseColor(user.levelColor).copy(alpha = 0.14f),
    ) {
        Text(
            "Lv.${user.level}",
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
            style = MaterialTheme.typography.labelSmall,
            color = parseColor(user.levelColor),
        )
    }
}

@Composable
fun UserBadges(user: User, max: Int = 2) {
    if (user.badges.isEmpty()) return
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        user.badges.take(max).forEach { badge ->
            Surface(
                shape = RoundedCornerShape(50),
                color = parseColor(badge.color).copy(alpha = 0.14f),
            ) {
                Text(
                    badge.name,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = parseColor(badge.color),
                )
            }
        }
    }
}

@Composable
fun BoardPill(name: String, color: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = parseColor(color).copy(alpha = 0.12f),
    ) {
        Text(
            name,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
            style = MaterialTheme.typography.labelSmall,
            color = parseColor(color),
            maxLines = 1,
        )
    }
}

@Composable
fun PostCard(
    post: Post,
    onClick: () -> Unit,
    onUserClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Card(
        modifier = modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BoardPill(post.boardName, post.boardColor)
                    if (post.isPinned) {
                        Spacer(Modifier.width(5.dp))
                        Icon(
                            Icons.Outlined.PushPin,
                            contentDescription = "置顶",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                    }
                    if (post.isFeatured) {
                        Spacer(Modifier.width(4.dp))
                        Icon(
                            Icons.Outlined.StarOutline,
                            contentDescription = "精华",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.tertiary,
                        )
                    }
                    if (post.isOfficial) {
                        Spacer(Modifier.width(5.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MaterialTheme.colorScheme.primary,
                        ) {
                            Text(
                                "官方",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    post.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                if (post.excerpt.isNotBlank()) {
                    Spacer(Modifier.height(5.dp))
                    Text(
                        post.excerpt,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LxlovoAvatar(post.author, 22)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        post.author.username,
                        style = MaterialTheme.typography.labelMedium,
                        modifier = Modifier.clickable { onUserClick(post.author.id) },
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        formatTime(post.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
                Spacer(Modifier.height(7.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Metric(Icons.Outlined.Visibility, post.views)
                    Metric(Icons.Outlined.FavoriteBorder, post.likes)
                    Metric(Icons.Outlined.ChatBubbleOutline, post.commentCount)
                }
            }
            if (post.coverUrl.isNotBlank()) {
                AsyncImage(
                    model = post.coverUrl,
                    contentDescription = post.title,
                    modifier = Modifier
                        .size(width = 106.dp, height = 104.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                    error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                )
            }
        }
    }
}

@Composable
private fun Metric(icon: androidx.compose.ui.graphics.vector.ImageVector, value: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.width(3.dp))
        Text(
            formatCount(value),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.outline,
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    action: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.weight(1f))
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) { Text(action) }
        }
    }
}

@Composable
fun LoadingBox(modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator()
    }
}

@Composable
fun ShimmerBox(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(8.dp),
) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val alpha by transition.animateFloat(
        initialValue = 0.28f,
        targetValue = 0.62f,
        animationSpec = infiniteRepeatable(
            animation = tween(850, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse,
        ),
        label = "shimmerAlpha",
    )
    Box(modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = alpha), shape))
}

@Composable
fun PostSkeleton(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(modifier = Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                ShimmerBox(Modifier.width(66.dp).height(18.dp), RoundedCornerShape(50))
                Spacer(Modifier.height(10.dp))
                ShimmerBox(Modifier.fillMaxWidth().height(18.dp))
                Spacer(Modifier.height(7.dp))
                ShimmerBox(Modifier.fillMaxWidth(0.82f).height(18.dp))
                Spacer(Modifier.height(12.dp))
                ShimmerBox(Modifier.fillMaxWidth(0.55f).height(13.dp))
            }
            ShimmerBox(Modifier.size(96.dp), RoundedCornerShape(16.dp))
        }
    }
}

@Composable
fun SkeletonList(modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        repeat(4) { PostSkeleton() }
    }
}

@Composable
fun ErrorBox(
    message: String,
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null,
) {
    Column(
        modifier = modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            message,
            color = MaterialTheme.colorScheme.error,
            style = MaterialTheme.typography.bodyMedium,
        )
        if (onRetry != null) {
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onRetry) { Text("重试") }
        }
    }
}

@Composable
fun EmptyBox(text: String, modifier: Modifier = Modifier) {
    Box(modifier = modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun LoginPrompt(
    title: String,
    action: String,
    onLogin: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = MaterialTheme.colorScheme.primaryContainer,
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            TextButton(onClick = onLogin) { Text(action) }
        }
    }
}

@Composable
fun HtmlContent(html: String, modifier: Modifier = Modifier) {
    val textColor = MaterialTheme.colorScheme.onSurface
    val linkColor = MaterialTheme.colorScheme.primary
    val spanned = remember(html) { HtmlCompat.fromHtml(html, HtmlCompat.FROM_HTML_MODE_COMPACT) }
    val images = remember(html) { extractImageUrls(html) }
    val context = LocalContext.current
    Column(modifier = modifier) {
        AndroidView(
            factory = { ctx ->
                TextView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                    )
                    setTextColor(textColor.toArgb())
                    setLinkTextColor(linkColor.toArgb())
                    textSize = 16f
                    setLineSpacing(0f, 1.3f)
                    movementMethod = LinkMovementMethod.getInstance()
                    setTextIsSelectable(true)
                    setBackgroundColor(AndroidColor.TRANSPARENT)
                }
            },
            update = { view ->
                if (view.text !== spanned) view.text = spanned
                view.setTextColor(textColor.toArgb())
                view.setLinkTextColor(linkColor.toArgb())
            },
            modifier = Modifier.fillMaxWidth(),
        )
        images.forEach { url ->
            Spacer(Modifier.height(10.dp))
            AsyncImage(
                model = url,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 520.dp)
                    .clip(RoundedCornerShape(18.dp)),
                contentScale = ContentScale.FillWidth,
                placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
            )
        }
    }
}

private fun extractImageUrls(html: String): List<String> {
    val regex = Regex("""<img[^>]+src=["']([^"']+)["']""", RegexOption.IGNORE_CASE)
    return regex.findAll(html)
        .map { it.groupValues[1] }
        .map { url ->
            if (url.startsWith("http://") || url.startsWith("https://")) {
                url
            } else {
                BuildConfig.SITE_URL.trimEnd('/') + "/" + url.trimStart('/')
            }
        }
        .distinct()
        .toList()
}

fun parseColor(value: String): Color = runCatching {
    Color(AndroidColor.parseColor(value))
}.getOrDefault(Color(0xFF4F5BD5))

fun formatCount(value: Int): String = when {
    value >= 10000 -> String.format(Locale.CHINA, "%.1fw", value / 10000f)
    value >= 1000 -> String.format(Locale.CHINA, "%.1fk", value / 1000f)
    else -> value.toString()
}

fun formatTime(raw: String?): String {
    if (raw.isNullOrBlank()) return ""
    val input = runCatching { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).parse(raw) }.getOrNull()
        ?: return raw.take(10)
    val now = Date()
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(now)
    val day = SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(input)
    return when {
        day == today -> SimpleDateFormat("HH:mm", Locale.CHINA).format(input)
        day == SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date(now.time - 86400000L)) ->
            "昨天 " + SimpleDateFormat("HH:mm", Locale.CHINA).format(input)
        else -> SimpleDateFormat("MM-dd HH:mm", Locale.CHINA).format(input)
    }
}
