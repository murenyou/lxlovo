package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Board
import com.bbs.lxlovo.top.data.Post
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.PostCard
import com.bbs.lxlovo.top.ui.SkeletonList
import kotlinx.coroutines.launch

@Composable
fun PostsScreen(
    api: ApiClient,
    reloadKey: Int,
    initialBoardId: Int,
    onBoardChanged: (Int) -> Unit,
    onPostClick: (Int) -> Unit,
    onUserClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    var boards by remember { mutableStateOf<List<Board>>(emptyList()) }
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var boardId by remember { mutableIntStateOf(initialBoardId) }
    var sort by remember { mutableStateOf("latest") }
    var page by remember { mutableIntStateOf(1) }
    var pages by remember { mutableIntStateOf(1) }
    var total by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var retryKey by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        boards = runCatching { api.boards() }.getOrDefault(emptyList())
    }

    LaunchedEffect(initialBoardId) {
        if (initialBoardId != boardId) {
            boardId = initialBoardId
        }
    }

    LaunchedEffect(reloadKey, boardId, sort, retryKey) {
        loading = true
        error = null
        page = 1
        try {
            val result = api.posts(1, boardId.takeIf { it > 0 }, sort)
            posts = result.items
            pages = result.pages
            total = result.total
        } catch (exception: Exception) {
            error = exception.message ?: "文章加载失败。"
        } finally {
            loading = false
        }
    }

    fun loadMore() {
        if (loadingMore || page >= pages) return
        loadingMore = true
        scope.launch {
            try {
                val next = page + 1
                val result = api.posts(next, boardId.takeIf { it > 0 }, sort)
                posts = posts + result.items.filter { item -> posts.none { it.id == item.id } }
                page = next
                pages = result.pages
                total = result.total
            } catch (exception: Exception) {
                error = exception.message
            } finally {
                loadingMore = false
            }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                FilterChip(
                    selected = boardId == 0,
                    onClick = { boardId = 0; onBoardChanged(0) },
                    label = { Text("全部") },
                )
            }
            items(boards, key = { it.id }) { board ->
                FilterChip(
                    selected = boardId == board.id,
                    onClick = { boardId = board.id; onBoardChanged(board.id) },
                    label = { Text(board.name) },
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            listOf("latest" to "最新", "hot" to "热门", "featured" to "精华").forEach { (value, label) ->
                FilterChip(
                    selected = sort == value,
                    onClick = { sort = value },
                    label = { Text(label) },
                )
            }
            Spacer(Modifier.weight(1f))
            Text(
                "$total 篇",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline,
            )
        }

        when {
            loading && posts.isEmpty() -> SkeletonList(Modifier.fillMaxSize())
            error != null && posts.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                ErrorBox(error!!) { retryKey++ }
            }
            posts.isEmpty() -> EmptyBox("这个板块还没有文章。", Modifier.fillMaxSize())
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(posts, key = { it.id }) { post ->
                    PostCard(post, { onPostClick(post.id) }, onUserClick)
                }
                item {
                    if (page < pages) {
                        Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                            if (loadingMore) {
                                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                            } else {
                                TextButton(onClick = ::loadMore) { Text("加载更多") }
                            }
                        }
                    } else {
                        Text(
                            "已经到底了",
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}
