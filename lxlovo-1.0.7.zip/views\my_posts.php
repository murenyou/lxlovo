<?php
$buildUrl = fn (int $page): string => url('my_posts', ['page' => $page]);
$me = current_user();
?>
<section class="page-head page-head--compact">
    <div><span class="page-head__eyebrow">My posts</span><h1>我的文章</h1><p>共 <?= (int) $total ?> 篇内容，持续记录你的想法。</p></div>
    <a class="btn btn--primary" href="<?= e(url('publish')) ?>"><?= icon('add', '', 18) ?>写文章</a>
</section>
<?php if ($posts): ?>
    <div class="post-grid">
        <?php foreach ($posts as $post): ?>
            <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
<?php else: ?>
    <div class="empty-state"><?= icon('edit', '', 38) ?><h3>还没有文章</h3><p>写下第一篇，让你的想法被看见。</p><a class="btn btn--primary" href="<?= e(url('publish')) ?>">开始写作</a></div>
<?php endif; ?>
