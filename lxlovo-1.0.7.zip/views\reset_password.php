<?php ?>
<section class="auth-shell auth-shell--simple">
    <div class="auth-card">
        <span class="auth-icon"><?= icon('lock', '', 34) ?></span>
        <div class="auth-card__head">
            <span class="page-head__eyebrow">New password</span>
            <h2>设置新密码</h2>
            <p>请设置一个 8 位以上的新密码。</p>
        </div>
        <form action="<?= e(url('reset_password')) ?>" method="post" class="form-stack">
            <?= csrf_field() ?>
            <input type="hidden" name="token" value="<?= e($token) ?>">
            <label class="field"><span class="field__label">新密码</span><span class="field__box"><?= icon('lock') ?><input type="password" name="password" minlength="8" maxlength="72" autocomplete="new-password" required autofocus></span></label>
            <label class="field"><span class="field__label">确认新密码</span><span class="field__box"><?= icon('check') ?><input type="password" name="password_confirm" minlength="8" maxlength="72" autocomplete="new-password" required></span></label>
            <button class="btn btn--primary btn--full" type="submit">重置密码</button>
        </form>
        <a class="auth-back" href="<?= e(url('login')) ?>"><?= icon('arrow_back', '', 16) ?>返回登录</a>
    </div>
</section>
