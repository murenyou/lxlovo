<?php
$tabs = ['pending' => '待审核', 'approved' => '已通过', 'rejected' => '未通过', 'all' => '全部'];
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Review</span><h2>认证审核</h2><p>核对申请理由与凭证，通过后自动授予认证并通知用户。</p></div></div>

<div class="segmented admin-segmented">
    <?php foreach ($tabs as $key => $label): ?>
        <a class="segmented__item<?= $status === $key ? ' is-active' : '' ?>" href="<?= e(admin_url('applications', ['status' => $key])) ?>"><?= $label ?></a>
    <?php endforeach; ?>
</div>

<div class="admin-stack">
    <?php foreach ($applications as $application): ?>
        <section class="admin-panel application-card">
            <div class="application-card__head">
                <a class="table-user" href="<?= e(admin_url('user', ['id' => (int) $application['user_id']])) ?>">
                    <img class="avatar avatar--sm" src="<?= e(avatar_url($application)) ?>" alt="">
                    <span><strong><?= e($application['username']) ?></strong><small>#<?= (int) $application['user_id'] ?> · Lv.<?= (int) $application['level'] ?> · <?= e($application['email'] ?? '') ?></small></span>
                </a>
                <div class="application-card__status">
                    <span class="chip chip--soft"><?= $application['type'] === 'sponsor' ? '赞助认证' : '用户认证' ?></span>
                    <?php if ($application['status'] === 'pending'): ?><span class="status-chip status-chip--warning">待审核</span>
                    <?php elseif ($application['status'] === 'approved'): ?><span class="status-chip status-chip--success">已通过</span>
                    <?php else: ?><span class="status-chip status-chip--danger">未通过</span><?php endif; ?>
                    <time><?= e(format_date($application['created_at'], 'Y-m-d H:i')) ?></time>
                </div>
            </div>
            <div class="application-card__body">
                <div><span class="admin-label">申请理由</span><p><?= nl2br(e($application['reason'])) ?></p></div>
                <?php if ($application['proof'] !== ''): ?><div><span class="admin-label">补充凭证</span><p class="break-text"><?= e($application['proof']) ?></p></div><?php endif; ?>
                <?php if ($application['admin_note'] !== ''): ?><div><span class="admin-label">审核备注</span><p><?= nl2br(e($application['admin_note'])) ?></p></div><?php endif; ?>
            </div>
            <?php if ($application['status'] === 'pending'): ?>
                <form action="<?= e(admin_url('application.review')) ?>" method="post" class="application-review">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= (int) $application['id'] ?>">
                    <label class="field"><span class="field__label">授予认证</span><span class="field__box field__box--select"><select name="cert_id"><option value="">选择认证</option><?php foreach ($certs as $cert): ?><?php if ($cert['type'] === $application['type']): ?><option value="<?= (int) $cert['id'] ?>"><?= e($cert['name']) ?></option><?php endif; ?><?php endforeach; ?></select></span></label>
                    <label class="field field--grow"><span class="field__label">审核备注（可选）</span><span class="field__box"><input type="text" name="admin_note" maxlength="500" placeholder="会随审核结果通知用户"></span></label>
                    <div class="application-review__actions">
                        <button class="btn btn--danger btn--sm" type="submit" name="decision" value="reject">拒绝</button>
                        <button class="btn btn--primary btn--sm" type="submit" name="decision" value="approve">通过并授予</button>
                    </div>
                </form>
            <?php else: ?>
                <div class="application-card__resolved">审核于 <?= e(format_date($application['reviewed_at'], 'Y-m-d H:i')) ?></div>
            <?php endif; ?>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$applications): ?><div class="admin-empty">没有相关申请。</div><?php endif; ?>
