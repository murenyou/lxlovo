<?php ?>
<div class="admin-page-head">
    <div><span class="admin-eyebrow">Content</span><h2>板块管理</h2><p>板块只在后台创建，可设置 1 位板块主与最多 3 位副板块主。</p></div>
    <a class="btn btn--primary btn--sm" href="<?= e(admin_url('board')) ?>"><?= icon('add', '', 17) ?>新建板块</a>
</div>
<div class="admin-card-grid">
    <?php foreach ($boards as $board): ?>
        <article class="admin-board-card" style="--board-color:<?= e($board['color']) ?>">
            <div class="admin-board-card__top">
                <span class="admin-board-card__icon"><?= icon($board['icon'] ?: 'board', '', 24) ?></span>
                <span class="status-chip status-chip--<?= $board['status'] === 'active' ? 'success' : 'neutral' ?>"><?= $board['status'] === 'active' ? '显示中' : '已隐藏' ?></span>
            </div>
            <h3><?= e($board['name']) ?></h3>
            <p><?= e($board['description']) ?></p>
            <div class="admin-board-card__meta">
                <span><?= (int) $board['post_count'] ?> 篇帖子</span>
                <span>标识 <?= e($board['slug']) ?></span>
            </div>
            <div class="admin-board-card__mods">
                <?php if (!empty($mods[(int) $board['id']])): ?>
                    <?php foreach ($mods[(int) $board['id']] as $mod): ?>
                        <span class="mod-chip"><img class="avatar avatar--xxs" src="<?= e(avatar_url($mod)) ?>" alt=""><?= e($mod['username']) ?><small><?= $mod['role'] === 'owner' ? '主' : '副' ?></small></span>
                    <?php endforeach; ?>
                <?php else: ?><span class="muted-text">尚未设置维护者</span><?php endif; ?>
            </div>
            <div class="admin-board-card__actions">
                <a class="btn btn--tonal btn--sm" href="<?= e(admin_url('board', ['id' => (int) $board['id']])) ?>">编辑</a>
                <a class="btn btn--text btn--sm" href="<?= e(url('posts', ['board' => (int) $board['id']])) ?>" target="_blank">查看</a>
            </div>
        </article>
    <?php endforeach; ?>
</div>
<?php if (!$boards): ?><div class="admin-empty">还没有板块。</div><?php endif; ?>
