-- lxlovo 社区 · MySQL 安装文件
-- 适用：MySQL 5.7+ / MySQL 8.0 / MariaDB 10.4+
-- 数据库：bbs_lxlovo_top
-- 默认管理员：admin / lxlovo@2026（登录后请立即修改密码）

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

USE `bbs_lxlovo_top`;

DROP TABLE IF EXISTS `app_tokens`;
DROP TABLE IF EXISTS `app_releases`;
DROP TABLE IF EXISTS `settings`;
DROP TABLE IF EXISTS `levels`;
DROP TABLE IF EXISTS `checkin_rewards`;
DROP TABLE IF EXISTS `checkins`;
DROP TABLE IF EXISTS `user_certifications`;
DROP TABLE IF EXISTS `certifications`;
DROP TABLE IF EXISTS `verify_applications`;
DROP TABLE IF EXISTS `board_moderators`;
DROP TABLE IF EXISTS `boards`;
DROP TABLE IF EXISTS `comment_likes`;
DROP TABLE IF EXISTS `comments`;
DROP TABLE IF EXISTS `post_rewards`;
DROP TABLE IF EXISTS `post_favorites`;
DROP TABLE IF EXISTS `post_likes`;
DROP TABLE IF EXISTS `posts`;
DROP TABLE IF EXISTS `messages`;
DROP TABLE IF EXISTS `notifications`;
DROP TABLE IF EXISTS `announcement_views`;
DROP TABLE IF EXISTS `announcements`;
DROP TABLE IF EXISTS `carousels`;
DROP TABLE IF EXISTS `nav_links`;
DROP TABLE IF EXISTS `friend_links`;
DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(32) NOT NULL,
  `email` VARCHAR(190) DEFAULT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('user','admin') NOT NULL DEFAULT 'user',
  `status` ENUM('active','banned') NOT NULL DEFAULT 'active',
  `avatar` VARCHAR(255) NOT NULL DEFAULT '',
  `bio` VARCHAR(500) NOT NULL DEFAULT '',
  `exp` INT UNSIGNED NOT NULL DEFAULT 0,
  `coins` INT UNSIGNED NOT NULL DEFAULT 0,
  `level` TINYINT UNSIGNED NOT NULL DEFAULT 0,
  `checkin_streak` INT UNSIGNED NOT NULL DEFAULT 0,
  `last_checkin_date` DATE DEFAULT NULL,
  `email_verified_at` DATETIME DEFAULT NULL,
  `email_verify_token` CHAR(64) DEFAULT NULL,
  `email_verify_expires` DATETIME DEFAULT NULL,
  `reset_token` CHAR(64) DEFAULT NULL,
  `reset_expires` DATETIME DEFAULT NULL,
  `show_official_badge` TINYINT(1) NOT NULL DEFAULT 1,
  `notify_comment` TINYINT(1) NOT NULL DEFAULT 1,
  `notify_mention` TINYINT(1) NOT NULL DEFAULT 1,
  `notify_message` TINYINT(1) NOT NULL DEFAULT 1,
  `notify_system` TINYINT(1) NOT NULL DEFAULT 1,
  `notify_email` TINYINT(1) NOT NULL DEFAULT 1,
  `last_active_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`),
  KEY `idx_level` (`level`),
  KEY `idx_active` (`last_active_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `levels` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `level` TINYINT UNSIGNED NOT NULL,
  `name` VARCHAR(40) NOT NULL,
  `min_exp` INT UNSIGNED NOT NULL DEFAULT 0,
  `max_exp` INT UNSIGNED DEFAULT NULL,
  `color` VARCHAR(20) NOT NULL DEFAULT '#6750A4',
  `sort` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `checkin_rewards` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `streak_days` INT UNSIGNED NOT NULL,
  `exp` INT UNSIGNED NOT NULL DEFAULT 0,
  `coins` INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_streak` (`streak_days`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `checkins` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `checkin_date` DATE NOT NULL,
  `streak` INT UNSIGNED NOT NULL DEFAULT 1,
  `exp` INT UNSIGNED NOT NULL DEFAULT 0,
  `coins` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_date` (`user_id`,`checkin_date`),
  KEY `idx_date` (`checkin_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `certifications` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` VARCHAR(40) NOT NULL,
  `name` VARCHAR(40) NOT NULL,
  `type` ENUM('official','user','sponsor') NOT NULL DEFAULT 'official',
  `color` VARCHAR(20) NOT NULL DEFAULT '#1A73E8',
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `conditions` TEXT,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `sort` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_code` (`code`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `user_certifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `cert_id` INT UNSIGNED NOT NULL,
  `granted_by` INT UNSIGNED DEFAULT NULL,
  `granted_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_user_cert` (`user_id`,`cert_id`),
  KEY `idx_cert` (`cert_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `verify_applications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `type` ENUM('user','sponsor') NOT NULL,
  `reason` TEXT,
  `proof` VARCHAR(500) NOT NULL DEFAULT '',
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` VARCHAR(500) NOT NULL DEFAULT '',
  `reviewed_by` INT UNSIGNED DEFAULT NULL,
  `reviewed_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `boards` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(40) NOT NULL,
  `slug` VARCHAR(60) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `icon` VARCHAR(40) NOT NULL DEFAULT 'board',
  `color` VARCHAR(20) NOT NULL DEFAULT '#6750A4',
  `sort` INT NOT NULL DEFAULT 0,
  `status` ENUM('active','hidden') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_slug` (`slug`),
  KEY `idx_sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `board_moderators` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `board_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `role` ENUM('owner','coowner') NOT NULL DEFAULT 'owner',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_board_user` (`board_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `posts` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `board_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `content` LONGTEXT NOT NULL,
  `content_text` LONGTEXT NOT NULL,
  `cover` VARCHAR(500) NOT NULL DEFAULT '',
  `status` ENUM('published','draft','deleted') NOT NULL DEFAULT 'published',
  `is_pinned` TINYINT(1) NOT NULL DEFAULT 0,
  `is_featured` TINYINT(1) NOT NULL DEFAULT 0,
  `featured_by` INT UNSIGNED DEFAULT NULL,
  `views` INT UNSIGNED NOT NULL DEFAULT 0,
  `likes_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `favorites_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `comments_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `rewards_coins` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_board` (`board_id`,`status`),
  KEY `idx_user` (`user_id`),
  KEY `idx_created` (`created_at`),
  KEY `idx_pinned` (`is_pinned`,`created_at`),
  KEY `idx_featured` (`is_featured`,`created_at`),
  FULLTEXT KEY `ft_search` (`title`,`content_text`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `post_likes` (
  `post_id` BIGINT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `post_favorites` (
  `post_id` BIGINT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`post_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `post_rewards` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` BIGINT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `amount` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `comments` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `post_id` BIGINT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `parent_id` BIGINT UNSIGNED DEFAULT NULL,
  `reply_to_user_id` INT UNSIGNED DEFAULT NULL,
  `content` TEXT NOT NULL,
  `is_pinned` TINYINT(1) NOT NULL DEFAULT 0,
  `likes_count` INT UNSIGNED NOT NULL DEFAULT 0,
  `status` ENUM('published','deleted') NOT NULL DEFAULT 'published',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_post` (`post_id`,`status`,`created_at`),
  KEY `idx_parent` (`parent_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `comment_likes` (
  `comment_id` BIGINT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`comment_id`,`user_id`),
  KEY `idx_user` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notifications` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `actor_id` INT UNSIGNED DEFAULT NULL,
  `type` VARCHAR(32) NOT NULL DEFAULT 'system',
  `message` VARCHAR(500) NOT NULL,
  `link` VARCHAR(500) NOT NULL DEFAULT '',
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `email_sent` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_read` (`user_id`,`is_read`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `messages` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `sender_id` INT UNSIGNED NOT NULL,
  `receiver_id` INT UNSIGNED NOT NULL,
  `content` TEXT NOT NULL,
  `is_read` TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver_id`,`is_read`,`created_at`),
  KEY `idx_sender` (`sender_id`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `announcements` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(120) NOT NULL,
  `content` TEXT NOT NULL,
  `display_mode` ENUM('every','daily','once') NOT NULL DEFAULT 'daily',
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `sort` INT NOT NULL DEFAULT 0,
  `starts_at` DATETIME DEFAULT NULL,
  `ends_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_active` (`enabled`,`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `announcement_views` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `announcement_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `last_seen_date` DATE NOT NULL,
  `seen_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_ann_user` (`announcement_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `carousels` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(100) NOT NULL,
  `subtitle` VARCHAR(200) NOT NULL DEFAULT '',
  `image` VARCHAR(500) NOT NULL,
  `link` VARCHAR(500) NOT NULL DEFAULT '',
  `sort` INT NOT NULL DEFAULT 0,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sort` (`sort`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `nav_links` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `label` VARCHAR(30) NOT NULL,
  `url` VARCHAR(500) NOT NULL,
  `icon` VARCHAR(40) NOT NULL DEFAULT 'link',
  `sort` INT NOT NULL DEFAULT 0,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `friend_links` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(60) NOT NULL,
  `url` VARCHAR(500) NOT NULL,
  `description` VARCHAR(255) NOT NULL DEFAULT '',
  `logo` VARCHAR(500) NOT NULL DEFAULT '',
  `tag` VARCHAR(30) NOT NULL DEFAULT '',
  `sort` INT NOT NULL DEFAULT 0,
  `enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `settings` (
  `skey` VARCHAR(80) NOT NULL,
  `svalue` LONGTEXT,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`skey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `app_releases` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `version_name` VARCHAR(40) NOT NULL,
  `version_code` INT UNSIGNED NOT NULL,
  `download_url` VARCHAR(1000) NOT NULL DEFAULT '',
  `download_mode` ENUM('auto','direct','page') NOT NULL DEFAULT 'auto',
  `is_forced` TINYINT(1) NOT NULL DEFAULT 0,
  `changelog` TEXT,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_version_code` (`version_code`),
  KEY `idx_enabled_code` (`is_enabled`,`version_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `app_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_name` VARCHAR(120) NOT NULL DEFAULT '',
  `last_used_at` DATETIME DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token_hash` (`token_hash`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`,`username`,`email`,`password_hash`,`role`,`email_verified_at`,`bio`,`show_official_badge`) VALUES
(1,'admin','admin@lxlovo.top','$2y$10$43fkR34op1U8r0K7YqCYOeX2ESNa43x8lTQJFZgcLBfFfLCNsyAvS','admin',NOW(),'lxlovo 社区管理员。','1');

ALTER TABLE `users` AUTO_INCREMENT = 2;

INSERT INTO `levels` (`level`,`name`,`min_exp`,`max_exp`,`color`,`sort`) VALUES
(0,'初来乍到',0,0,'#79747E',0),
(1,'新星',1,10,'#4F5BD5',1),
(2,'探索者',11,30,'#386A20',2),
(3,'活跃分子',31,50,'#006A6A',3),
(4,'常驻居民',51,100,'#7D5260',4),
(5,'社区骨干',101,200,'#8A5100',5),
(6,'资深玩家',201,500,'#6750A4',6),
(7,'意见领袖',501,1000,'#0061A4',7),
(8,'荣誉会员',1001,2000,'#B3261E',8),
(9,'传奇先锋',2001,5000,'#7A5900',9),
(10,'社区之光',5001,10000,'#4A5BD8',10),
(11,'殿堂成员',10001,50000,'#8B3A62',11),
(12,'永恒传说',50000,NULL,'#3F2B96',12);

INSERT INTO `checkin_rewards` (`streak_days`,`exp`,`coins`) VALUES
(1,3,1),(2,5,1),(3,6,1),(4,7,1),(5,8,2),(6,9,3),(7,10,5),(15,50,10),(30,100,20);

INSERT INTO `certifications` (`id`,`code`,`name`,`type`,`color`,`description`,`conditions`,`enabled`,`sort`) VALUES
(1,'official','官方认证','official','#1A73E8','由 lxlovo 官方授予的认证身份','仅可由后台授予',1,10),
(2,'user','用户认证','user','#F9AB00','社区认可的优秀创作者','等级达到 Lv.2，并在社区保持良好表现',1,20),
(3,'sponsor','赞助认证','sponsor','#D93025','支持 lxlovo 持续运营的赞助者','完成赞助并联系管理员登记账号 ID',1,30);

INSERT INTO `user_certifications` (`user_id`,`cert_id`,`granted_by`) VALUES (1,1,1);

INSERT INTO `boards` (`id`,`name`,`slug`,`description`,`icon`,`color`,`sort`,`status`) VALUES
(1,'综合讨论','general','什么都可以聊，保持友善与好奇。','forum','#4F5BD5',10,'active'),
(2,'技术分享','tech','代码、产品、设计与一切硬核知识。','code','#006A6A',20,'active'),
(3,'生活日常','life','记录生活里细碎而明亮的部分。','coffee','#8A5100',30,'active'),
(4,'站务公告','notice','lxlovo 的公告、规则与更新日志。','campaign','#B3261E',40,'active');

INSERT INTO `board_moderators` (`board_id`,`user_id`,`role`) VALUES
(1,1,'owner'),(2,1,'owner'),(3,1,'owner'),(4,1,'owner');

INSERT INTO `posts` (`id`,`board_id`,`user_id`,`title`,`content`,`content_text`,`cover`,`status`,`is_pinned`,`is_featured`,`featured_by`) VALUES
(1,4,1,'欢迎来到 lxlovo','<h2>你好，欢迎来到 lxlovo。</h2><p>这里是一个开放、自由、属于每一个人的社区。我们相信，好的交流不需要复杂的规则，只需要真诚、尊重与一点点好奇。</p><p>你可以在这里分享技术、记录生活、提出疑问，也可以只是安静地看看。发帖前请先阅读社区规则，友善地对待每一位来到这里的伙伴。</p><blockquote>让每一次交流，都值得被看见。</blockquote><p>祝你在这里玩得开心。</p>','你好，欢迎来到 lxlovo。这里是一个开放、自由、属于每一个人的社区。我们相信，好的交流不需要复杂的规则，只需要真诚、尊重与一点点好奇。你可以在这里分享技术、记录生活、提出疑问，也可以只是安静地看看。发帖前请先阅读社区规则，友善地对待每一位来到这里的伙伴。让每一次交流，都值得被看见。祝你在这里玩得开心。','', 'published',1,1,1),
(2,2,1,'lxlovo 的技术栈与后续计划','<p>lxlovo 使用 PHP 8.2 + MySQL 构建，前端保持零第三方依赖，全部界面遵循 Material Design 3 的设计语言。</p><h3>已经完成</h3><ul><li>账号体系、邮箱验证与等级签到</li><li>帖子、评论、点赞、收藏、打赏与精选</li><li>私信、通知、认证与完整后台</li></ul><h3>接下来</h3><p>我们会持续迭代社区体验，并在基础功能稳定后启动 Android 客户端。移动端将直接复用现有的 JSON 接口，保持完全免费与开源。</p>','lxlovo 使用 PHP 8.2 + MySQL 构建，前端保持零第三方依赖，全部界面遵循 Material Design 3 的设计语言。已经完成账号体系、邮箱验证与等级签到，帖子、评论、点赞、收藏、打赏与精选，私信、通知、认证与完整后台。接下来我们会持续迭代社区体验，并在基础功能稳定后启动 Android 客户端。','', 'published',0,1,1),
(3,3,1,'今天也要好好生活','<p>这里是 lxlovo 的生活板块。可以分享一顿饭、一场散步、一首循环了很久的歌。</p><p>不需要宏大的叙事，日常本身就足够动人。</p>','这里是 lxlovo 的生活板块。可以分享一顿饭、一场散步、一首循环了很久的歌。不需要宏大的叙事，日常本身就足够动人。','', 'published',0,0,NULL);

ALTER TABLE `posts` AUTO_INCREMENT = 4;

INSERT INTO `carousels` (`title`,`subtitle`,`image`,`link`,`sort`,`enabled`) VALUES
('让每一次交流，都值得被看见','lxlovo · 一个开放、自由、原创的中文社区','assets/img/banner-1.svg','index.php?r=about',10,1),
('分享你的技术、生活与灵感','在感兴趣的板块，遇见同频的人','assets/img/banner-2.svg','index.php?r=posts',20,1);

INSERT INTO `announcements` (`title`,`content`,`display_mode`,`enabled`,`sort`) VALUES
('欢迎来到 lxlovo','lxlovo 社区正式启程。请友善交流、尊重原创，一起把这里变成值得停留的地方。','daily',1,10);

INSERT INTO `nav_links` (`label`,`url`,`icon`,`sort`,`enabled`) VALUES
('首页','index.php?r=home','home',10,1),
('文章','index.php?r=posts','article',20,1),
('板块','index.php?r=boards','board',30,1),
('友链','index.php?r=links','link',40,1),
('关于','index.php?r=about','info',50,1);

INSERT INTO `friend_links` (`name`,`url`,`description`,`logo`,`tag`,`sort`,`enabled`) VALUES
('lxlovo 官方','https://bbs.lxlovo.top','lxlovo 社区主站','','官方',10,1);

INSERT INTO `settings` (`skey`,`svalue`) VALUES
('site_name','lxlovo'),
('site_tagline','让每一次交流，都值得被看见'),
('site_description','lxlovo 是一个开放、自由、原创的中文社区。分享技术、记录生活、认识同频的人。'),
('site_keywords','lxlovo,论坛,社区,中文社区,开源论坛'),
('site_url',''),
('filing_info',''),
('footer_extra',''),
('theme_default','light'),
('register_enabled','1'),
('checkin_enabled','1'),
('official_badge_enabled','1'),
('official_card_enabled','1'),
('online_minutes','15'),
('show_online_users','1'),
('email_verify_required','0'),
('email_notify_enabled','1'),
('smtp_host','smtp.qq.com'),
('smtp_port','465'),
('smtp_secure','ssl'),
('smtp_user',''),
('smtp_pass',''),
('smtp_from',''),
('smtp_from_name','lxlovo'),
('upload_enabled','1'),
('upload_max_kb','100'),
('upload_roles','official,sponsor'),
('upload_max_width','1600'),
('avatar_max_kb','300'),
('avatar_max_width','512'),
('carousel_max_kb','500'),
('user_verify_min_level','2'),
('user_verify_note','申请用户认证需要达到 Lv.2，并在社区保持友善、原创与活跃。管理员会根据近期表现进行审核。'),
('sponsor_url','https://bbs.lxlovo.top'),
('sponsor_note','完成赞助后，请在本页提交申请并留下你的账号 ID。我们会核对赞助记录，并在 3 天内为你添加赞助认证。'),
('announcement_enabled','1'),
('app_inapp_browser_default','1'),
('about_content','<h2>关于 lxlovo</h2><p>lxlovo 是一个开放、自由、原创的中文社区。</p><p>我们希望这里能容纳技术、生活、灵感与认真而友善的交流。论坛程序本身完全开源免费，未来也会提供同样免费的 Android 客户端。</p><h3>我们的原则</h3><ul><li>尊重每一个人，也尊重不同的声音。</li><li>鼓励原创，注明引用。</li><li>保持好奇，允许犯错。</li></ul><p>感谢你来到这里。</p>'),
('about_updated_at',NOW());

INSERT INTO `app_releases` (`id`,`version_name`,`version_code`,`download_url`,`download_mode`,`is_forced`,`changelog`,`is_enabled`,`published_at`) VALUES
(1,'1.0.5',105,'https://bbs.lxlovo.top/download/lxlovo-1.0.5.apk','auto',0,'首个 Android 客户端版本。\n\n- 使用 Material Design 3 组件构建\n- 支持应用内更新检测、强制更新与下载进度\n- 支持内置浏览器与更新日志',1,NOW()),
(2,'1.0.6',106,'https://bbs.lxlovo.top/download/lxlovo-1.0.6.apk','auto',0,'原生 Android 重写版本。\n\n- 移除论坛网页套壳，全部页面改为原生 Jetpack Compose\n- 原生首页、文章列表、文章详情、评论、发帖与搜索\n- 原生登录注册、个人主页、签到、通知与私信\n- 原生设置、更新日志、内置浏览器与下载进度\n- 保留后台 App 版本管理',1,NOW()),
(3,'1.0.7',107,'https://bbs.lxlovo.top/download/lxlovo-1.0.7.apk','auto',0,'原生功能补齐与体验升级。\n\n- 新增账号与安全：头像上传、修改密码、更换邮箱、邮箱验证状态、通知偏好\n- 新增认证中心：用户认证、赞助认证申请与申请记录\n- 新增帖子编辑、删除、封面图、精华设置\n- 新增评论置顶与评论删除\n- 新增我的收藏、我的文章、板块列表、在线用户、关于页面\n- 新增随机推荐、轮播自动播放、骨架屏与页面转场动画\n- 优化点赞动效、评论回复动画与整体交互',1,NOW());

ALTER TABLE `app_releases` AUTO_INCREMENT = 4;

-- ---------------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 1;
