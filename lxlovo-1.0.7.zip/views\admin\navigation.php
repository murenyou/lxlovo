<?php
$iconChoices = ['home', 'article', 'board', 'link', 'info', 'message', 'users', 'star', 'bolt', 'shield', 'mega', 'image', 'video', 'gift', 'clock', 'grid'];
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Navigation</span><h2>快捷栏</h2><p>电脑端显示在顶部导航，手机端显示在侧边抽屉中，两端共用同一份配置。</p></div></div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>新增快捷方式</h3></div>
    <form action="<?= e(admin_url('nav.save')) ?>" method="post" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">名称</span><span class="field__box"><input type="text" name="label" maxlength="30" required></span></label>
            <label class="field"><span class="field__label">链接</span><span class="field__box"><input type="text" name="url" placeholder="index.php?r=posts" required></span></label>
            <label class="field"><span class="field__label">图标</span><span class="field__box field__box--select"><select name="icon"><?php foreach ($iconChoices as $iconName): ?><option value="<?= $iconName ?>"><?= $iconName ?></option><?php endforeach; ?></select></span></label>
            <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="10"></span></label>
            <label class="check-line"><input type="checkbox" name="enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">添加快捷方式</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <span class="admin-edit-row__icon"><?= icon($item['icon'] ?: 'link', '', 21) ?></span>
                <div><h3><?= e($item['label']) ?></h3><p><?= e($item['url']) ?><?= $item['enabled'] ? '' : ' · 已停用' ?></p></div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('nav.save')) ?>" method="post" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">名称</span><span class="field__box"><input type="text" name="label" value="<?= e($item['label']) ?>" required></span></label>
                                <label class="field"><span class="field__label">链接</span><span class="field__box"><input type="text" name="url" value="<?= e($item['url']) ?>" required></span></label>
                                <label class="field"><span class="field__label">图标</span><span class="field__box field__box--select"><select name="icon"><?php foreach (array_unique(array_merge($iconChoices, [$item['icon']])) as $iconName): ?><option value="<?= e($iconName) ?>" <?= $item['icon'] === $iconName ? 'selected' : '' ?>><?= e($iconName) ?></option><?php endforeach; ?></select></span></label>
                                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) $item['sort'] ?>"></span></label>
                                <label class="check-line"><input type="checkbox" name="enabled" value="1" <?= $item['enabled'] ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('nav.delete')) ?>" method="post" data-confirm="确定删除这个快捷方式吗？" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$items): ?><div class="admin-empty">还没有快捷方式。</div><?php endif; ?>
