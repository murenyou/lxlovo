<?php
$s = $settings;
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">System</span><h2>站点设置</h2><p>站点信息、认证规则、上传权限与邮件服务。</p></div><span class="status-chip status-chip--<?= email_configured() ? 'success' : 'warning' ?>">SMTP <?= email_configured() ? '已配置' : '未配置' ?></span></div>

<div class="settings-tabs" data-settings-tabs>
    <button class="settings-tab is-active" type="button" data-tab="basic"><?= icon('settings', '', 17) ?>基本</button>
    <button class="settings-tab" type="button" data-tab="community"><?= icon('users', '', 17) ?>社区</button>
    <button class="settings-tab" type="button" data-tab="upload"><?= icon('image', '', 17) ?>上传</button>
    <button class="settings-tab" type="button" data-tab="email"><?= icon('mail', '', 17) ?>邮件</button>
    <button class="settings-tab" type="button" data-tab="about"><?= icon('info', '', 17) ?>关于页</button>
</div>

<form action="<?= e(admin_url('settings.save')) ?>" method="post" class="admin-settings-form">
    <?= csrf_field() ?>
    <section class="settings-panel is-active" data-panel="basic">
        <div class="admin-panel">
            <div class="admin-panel__head"><h3>站点信息</h3></div>
            <div class="admin-form-grid">
                <label class="field"><span class="field__label">站点名称</span><span class="field__box"><input type="text" name="site_name" value="<?= e($s['site_name']) ?>" maxlength="50" required></span></label>
                <label class="field"><span class="field__label">站点标语</span><span class="field__box"><input type="text" name="site_tagline" value="<?= e($s['site_tagline']) ?>" maxlength="120"></span></label>
                <label class="field field--span-2"><span class="field__label">站点描述</span><span class="field__box field__box--textarea"><textarea name="site_description" rows="3" maxlength="500"><?= e($s['site_description']) ?></textarea></span></label>
                <label class="field field--span-2"><span class="field__label">关键词</span><span class="field__box"><input type="text" name="site_keywords" value="<?= e($s['site_keywords']) ?>" maxlength="255"></span></label>
                <label class="field field--span-2"><span class="field__label">站点地址（可选）</span><span class="field__box"><input type="url" name="site_url" value="<?= e($s['site_url']) ?>" placeholder="https://bbs.lxlovo.top"></span><span class="field__hint">留空自动识别；用于邮件中的绝对链接。</span></label>
                <label class="field"><span class="field__label">备案信息</span><span class="field__box"><input type="text" name="filing_info" value="<?= e($s['filing_info']) ?>" maxlength="120" placeholder="例如 京ICP备…"></span></label>
                <label class="field"><span class="field__label">页脚补充</span><span class="field__box"><input type="text" name="footer_extra" value="<?= e($s['footer_extra']) ?>" maxlength="120"></span></label>
                <label class="field"><span class="field__label">默认主题</span><span class="field__box field__box--select"><select name="theme_default"><?php foreach (['light' => '白天', 'dark' => '夜晚', 'system' => '跟随系统'] as $key => $label): ?><option value="<?= $key ?>" <?= $s['theme_default'] === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></span></label>
                <label class="field"><span class="field__label">每页文章数</span><span class="field__box"><input type="number" name="post_per_page" value="<?= (int) $s['post_per_page'] ?>" min="1" max="50"></span></label>
                <label class="check-line"><input type="checkbox" name="register_enabled" value="1" <?= $s['register_enabled'] === '1' ? 'checked' : '' ?>><span>开放注册</span></label>
                <label class="check-line"><input type="checkbox" name="checkin_enabled" value="1" <?= $s['checkin_enabled'] === '1' ? 'checked' : '' ?>><span>开启签到</span></label>
            </div>
        </div>
    </section>

    <section class="settings-panel" data-panel="community">
        <div class="admin-panel">
            <div class="admin-panel__head"><h3>认证与展示</h3></div>
            <div class="admin-form-grid">
                <label class="check-line"><input type="checkbox" name="official_badge_enabled" value="1" <?= $s['official_badge_enabled'] === '1' ? 'checked' : '' ?>><span>全局显示认证标识</span></label>
                <label class="check-line"><input type="checkbox" name="official_card_enabled" value="1" <?= $s['official_card_enabled'] === '1' ? 'checked' : '' ?>><span>官方认证卡片配色</span></label>
                <label class="check-line"><input type="checkbox" name="announcement_enabled" value="1" <?= $s['announcement_enabled'] === '1' ? 'checked' : '' ?>><span>启用公告弹窗</span></label>
                <label class="check-line"><input type="checkbox" name="show_online_users" value="1" <?= $s['show_online_users'] === '1' ? 'checked' : '' ?>><span>显示在线用户</span></label>
                <label class="field"><span class="field__label">在线判定分钟</span><span class="field__box"><input type="number" name="online_minutes" value="<?= (int) $s['online_minutes'] ?>" min="1" max="240"></span></label>
                <label class="field"><span class="field__label">用户认证最低等级</span><span class="field__box"><input type="number" name="user_verify_min_level" value="<?= (int) $s['user_verify_min_level'] ?>" min="0" max="99"></span></label>
                <label class="field field--span-2"><span class="field__label">用户认证说明</span><span class="field__box field__box--textarea"><textarea name="user_verify_note" rows="3"><?= e($s['user_verify_note']) ?></textarea></span></label>
                <label class="field field--span-2"><span class="field__label">赞助认证跳转地址</span><span class="field__box"><input type="url" name="sponsor_url" value="<?= e($s['sponsor_url']) ?>" placeholder="https://…"></span></label>
                <label class="field field--span-2"><span class="field__label">赞助认证说明</span><span class="field__box field__box--textarea"><textarea name="sponsor_note" rows="3"><?= e($s['sponsor_note']) ?></textarea></span></label>
            </div>
        </div>
    </section>

    <section class="settings-panel" data-panel="upload">
        <div class="admin-panel">
            <div class="admin-panel__head"><h3>图片上传</h3><span>帖子图片自动压缩为 JPG</span></div>
            <div class="admin-form-grid">
                <label class="check-line"><input type="checkbox" name="upload_enabled" value="1" <?= $s['upload_enabled'] === '1' ? 'checked' : '' ?>><span>启用帖子图片上传</span></label>
                <label class="field"><span class="field__label">允许上传的认证</span><span class="field__box"><input type="text" name="upload_roles" value="<?= e($s['upload_roles']) ?>" placeholder="official,sponsor"></span><span class="field__hint">逗号分隔：official、sponsor、user。管理员始终可以上传。</span></label>
                <label class="field"><span class="field__label">帖子图片上限（KB）</span><span class="field__box"><input type="number" name="upload_max_kb" value="<?= (int) $s['upload_max_kb'] ?>" min="1" max="2048"></span></label>
                <label class="field"><span class="field__label">帖子图片最大宽度</span><span class="field__box"><input type="number" name="upload_max_width" value="<?= (int) $s['upload_max_width'] ?>" min="100"></span></label>
                <label class="field"><span class="field__label">头像上限（KB）</span><span class="field__box"><input type="number" name="avatar_max_kb" value="<?= (int) $s['avatar_max_kb'] ?>" min="1" max="2048"></span></label>
                <label class="field"><span class="field__label">头像最大宽度</span><span class="field__box"><input type="number" name="avatar_max_width" value="<?= (int) $s['avatar_max_width'] ?>" min="64"></span></label>
                <label class="field"><span class="field__label">轮播图上限（KB）</span><span class="field__box"><input type="number" name="carousel_max_kb" value="<?= (int) $s['carousel_max_kb'] ?>" min="1" max="4096"></span></label>
            </div>
        </div>
    </section>

    <section class="settings-panel" data-panel="email" id="email">
        <div class="admin-panel">
            <div class="admin-panel__head"><h3>邮件服务</h3><span>默认 QQ 邮箱：smtp.qq.com / 465 / SSL</span></div>
            <div class="admin-form-grid">
                <label class="check-line"><input type="checkbox" name="email_verify_required" value="1" <?= $s['email_verify_required'] === '1' ? 'checked' : '' ?>><span>注册后必须验证邮箱才能发帖 / 评论</span></label>
                <label class="check-line"><input type="checkbox" name="email_notify_enabled" value="1" <?= $s['email_notify_enabled'] === '1' ? 'checked' : '' ?>><span>启用邮件提醒</span></label>
                <label class="field"><span class="field__label">SMTP 主机</span><span class="field__box"><input type="text" name="smtp_host" value="<?= e($s['smtp_host']) ?>" placeholder="smtp.qq.com"></span></label>
                <label class="field"><span class="field__label">端口</span><span class="field__box"><input type="number" name="smtp_port" value="<?= (int) $s['smtp_port'] ?>" min="1" max="65535"></span></label>
                <label class="field"><span class="field__label">加密方式</span><span class="field__box field__box--select"><select name="smtp_secure"><?php foreach (['ssl' => 'SSL（465）', 'tls' => 'STARTTLS（587）', 'none' => '不加密'] as $key => $label): ?><option value="<?= $key ?>" <?= $s['smtp_secure'] === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></span></label>
                <label class="field"><span class="field__label">SMTP 账号</span><span class="field__box"><input type="text" name="smtp_user" value="<?= e($s['smtp_user']) ?>" placeholder="your@qq.com"></span></label>
                <label class="field"><span class="field__label">SMTP 授权码 / 密码</span><span class="field__box"><input type="password" name="smtp_pass" value="" placeholder="<?= $s['smtp_pass'] !== '' ? '已保存，留空不修改' : 'QQ 邮箱请填写授权码' ?>" autocomplete="new-password"></span></label>
                <label class="field"><span class="field__label">发件邮箱</span><span class="field__box"><input type="email" name="smtp_from" value="<?= e($s['smtp_from']) ?>" placeholder="留空则使用 SMTP 账号"></span></label>
                <label class="field"><span class="field__label">发件人名称</span><span class="field__box"><input type="text" name="smtp_from_name" value="<?= e($s['smtp_from_name']) ?>" maxlength="60"></span></label>
                <label class="check-line"><input type="checkbox" name="clear_smtp_pass" value="1"><span>清除已保存的 SMTP 密码</span></label>
            </div>
            <p class="admin-note admin-note--small">QQ 邮箱需要在「设置 → 账户 → POP3/IMAP/SMTP 服务」中开启 SMTP 并生成授权码，不能直接使用 QQ 密码。</p>
        </div>
    </section>

    <section class="settings-panel" data-panel="about">
        <div class="admin-panel">
            <div class="admin-panel__head"><h3>关于页面</h3><span>支持 HTML</span></div>
            <label class="field"><span class="field__label">关于内容</span><span class="field__box field__box--textarea"><textarea name="about_content" rows="18" class="code-textarea"><?= e($s['about_content']) ?></textarea></span></label>
        </div>
    </section>

    <div class="admin-savebar">
        <span>所有修改保存后立即生效。</span>
        <button class="btn btn--primary" type="submit"><?= icon('check', '', 18) ?>保存全部设置</button>
    </div>
</form>

<section class="admin-panel" id="email-test">
    <div class="admin-panel__head"><h3>发送测试邮件</h3><span>先保存 SMTP 设置</span></div>
    <form action="<?= e(admin_url('email.test')) ?>" method="post" class="admin-inline-form">
        <?= csrf_field() ?>
        <label class="admin-search admin-search--wide"><?= icon('mail', '', 18) ?><input type="email" name="email" placeholder="收件邮箱" required></label>
        <button class="btn btn--tonal" type="submit">发送测试邮件</button>
    </form>
    <p class="admin-note admin-note--small">如果发送失败，请检查授权码、端口、SSL 设置以及服务器是否允许对外连接。</p>
</section>
