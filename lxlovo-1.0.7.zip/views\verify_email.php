<?php
$logged = $profile !== null;
$verified = $logged && !empty($profile['email_verified_at']);
$mailReady = email_configured();
?>
<section class="auth-shell auth-shell--simple">
    <div class="auth-card auth-card--wide">
        <span class="auth-icon"><?= icon('mail', '', 34) ?></span>
        <div class="auth-card__head">
            <span class="page-head__eyebrow">Email verification</span>
            <h2><?= $verified ? '邮箱已验证' : '验证你的邮箱' ?></h2>
            <?php if ($logged): ?>
                <p><?= e($profile['email'] ?: '尚未绑定邮箱') ?></p>
            <?php else: ?>
                <p>请打开验证邮件中的链接完成验证。</p>
            <?php endif; ?>
        </div>
        <?php if ($verified): ?>
            <div class="notice notice--success"><?= icon('check', '', 20) ?>你的邮箱已经验证成功，可以正常使用社区功能。</div>
            <a class="btn btn--primary btn--full" href="<?= e(url('me')) ?>">回到我的</a>
        <?php elseif ($logged): ?>
            <?php if (!$mailReady): ?>
                <div class="notice notice--warning"><?= icon('info', '', 20) ?>站点尚未配置 SMTP，暂时无法发送验证邮件。请联系管理员完成配置。</div>
            <?php else: ?>
                <p class="auth-text">验证邮件已发送至你的邮箱。链接 24 小时内有效，如果没有收到，请检查垃圾邮件。</p>
            <?php endif; ?>
            <form action="<?= e(url('resend_verification')) ?>" method="post">
                <?= csrf_field() ?>
                <button class="btn btn--primary btn--full" type="submit" <?= $mailReady ? '' : 'disabled' ?>>重新发送验证邮件</button>
            </form>
            <a class="auth-back" href="<?= e(url('me')) ?>"><?= icon('arrow_back', '', 16) ?>先回我的主页</a>
        <?php else: ?>
            <p class="auth-text">如果你已经登录，可以回到账号设置重新发送验证邮件。</p>
            <a class="btn btn--primary btn--full" href="<?= e(url('login', ['next' => url('verify_email')])) ?>">登录账号</a>
            <a class="auth-back" href="<?= e(url('home')) ?>"><?= icon('arrow_back', '', 16) ?>返回首页</a>
        <?php endif; ?>
    </div>
</section>
