<?php
$me = current_user();
?>
<section class="page-head page-head--compact">
    <div>
        <span class="page-head__eyebrow">Messages</span>
        <h1>私信</h1>
        <p>和社区里的伙伴安静地聊一聊。</p>
    </div>
    <span class="status-chip status-chip--neutral"><?= icon('lock', '', 14) ?>仅双方可见</span>
</section>

<div class="chat-layout">
    <aside class="chat-sidebar">
        <div class="chat-sidebar__head"><h2>会话</h2><span><?= count($conversations) ?></span></div>
        <?php if ($conversations): ?>
            <div class="conversation-list">
                <?php foreach ($conversations as $otherId => $conversation): ?>
                    <a class="conversation<?= $chatUser && (int) $chatUser['id'] === (int) $otherId ? ' is-active' : '' ?>" href="<?= e(url('messages', ['with' => (int) $otherId])) ?>">
                        <span class="conversation__avatar">
                            <img class="avatar avatar--sm" src="<?= e(avatar_url($conversation)) ?>" alt="">
                            <?php if (is_online($conversation)): ?><i class="online-dot"></i><?php endif; ?>
                        </span>
                        <span class="conversation__body">
                            <span class="conversation__top"><strong><?= e($conversation['username']) ?></strong><time><?= e(time_ago($conversation['created_at'])) ?></time></span>
                            <span class="conversation__preview"><?= (int) $conversation['sender_id'] === (int) $me['id'] ? '我：' : '' ?><?= e(text_excerpt($conversation['content'], 40)) ?></span>
                        </span>
                        <?php if (!empty($unread[(int) $otherId])): ?><span class="count-dot count-dot--static"><?= (int) $unread[(int) $otherId] ?></span><?php endif; ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="chat-empty chat-empty--side">
                <?= icon('mail', '', 30) ?>
                <p>还没有私信</p>
                <span>从用户主页发起一段对话。</span>
            </div>
        <?php endif; ?>
    </aside>

    <section class="chat-panel">
        <?php if ($chatUser): ?>
            <header class="chat-panel__head">
                <a class="chat-user" href="<?= e(url('user', ['id' => (int) $chatUser['id']])) ?>">
                    <span class="conversation__avatar">
                        <img class="avatar avatar--sm" src="<?= e(avatar_url($chatUser)) ?>" alt="">
                        <?php if (is_online($chatUser)): ?><i class="online-dot"></i><?php endif; ?>
                    </span>
                    <span><strong><?= e($chatUser['username']) ?></strong><small><?= is_online($chatUser) ? '在线' : '离线' ?> · ID <?= (int) $chatUser['id'] ?></small></span>
                </a>
                <a class="icon-btn" href="<?= e(url('user', ['id' => (int) $chatUser['id']])) ?>" aria-label="查看主页"><?= icon('person') ?></a>
            </header>
            <div class="chat-messages" id="chat-messages">
                <?php if ($messages): ?>
                    <?php $lastDate = ''; ?>
                    <?php foreach ($messages as $message): ?>
                        <?php $date = date('Y-m-d', strtotime($message['created_at'])); ?>
                        <?php if ($date !== $lastDate): ?>
                            <div class="chat-date"><?= e(format_date($message['created_at'], 'm 月 d 日')) ?></div>
                            <?php $lastDate = $date; ?>
                        <?php endif; ?>
                        <div class="chat-bubble-row<?= (int) $message['sender_id'] === (int) $me['id'] ? ' is-mine' : '' ?>">
                            <?php if ((int) $message['sender_id'] !== (int) $me['id']): ?><img class="avatar avatar--xs" src="<?= e(avatar_url($chatUser)) ?>" alt=""><?php endif; ?>
                            <div class="chat-bubble">
                                <p><?= nl2br(e($message['content'])) ?></p>
                                <time><?= e(format_date($message['created_at'], 'H:i')) ?></time>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="chat-empty">
                        <?= icon('message', '', 34) ?>
                        <p>和 <?= e($chatUser['username']) ?> 打个招呼吧</p>
                        <span>私信内容只有你们两个人可以看到。</span>
                    </div>
                <?php endif; ?>
            </div>
            <form class="chat-form" action="<?= e(url('message.send')) ?>" method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="receiver_id" value="<?= (int) $chatUser['id'] ?>">
                <textarea name="content" rows="2" maxlength="1000" placeholder="输入私信内容…" required></textarea>
                <button class="btn btn--primary icon-btn--send" type="submit" aria-label="发送"><?= icon('send', '', 20) ?></button>
            </form>
        <?php else: ?>
            <div class="chat-empty chat-empty--large">
                <span class="chat-empty__mark">l</span>
                <h2>选择一段会话</h2>
                <p>或者从用户主页点击「发私信」，开始新的对话。</p>
                <a class="btn btn--tonal" href="<?= e(url('online')) ?>">看看谁在线</a>
            </div>
        <?php endif; ?>
    </section>
</div>
