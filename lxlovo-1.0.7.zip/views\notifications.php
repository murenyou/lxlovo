<?php
$buildUrl = fn (int $page): string => url('notifications', ['page' => $page]);
?>
<section class="page-head page-head--compact">
    <div>
        <span class="page-head__eyebrow">Inbox</span>
        <h1>通知</h1>
        <p>共 <?= (int) $total ?> 条通知，<?= notification_count((int) current_user()['id']) ?> 条未读。</p>
    </div>
    <form action="<?= e(url('notifications.read')) ?>" method="post">
        <?= csrf_field() ?>
        <button class="btn btn--tonal" type="submit"><?= icon('check', '', 18) ?>全部已读</button>
    </form>
</section>

<section class="panel notification-panel">
    <?php if ($notifications): ?>
        <div class="notification-list">
            <?php foreach ($notifications as $notification): ?>
                <a class="notification-item<?= (int) $notification['is_read'] === 0 ? ' is-unread' : '' ?>" href="<?= e(url('notification.go', ['id' => (int) $notification['id']])) ?>">
                    <span class="notification-item__icon notification-item__icon--<?= e($notification['type']) ?>"><?= icon(notification_icon($notification['type']), '', 20) ?></span>
                    <span class="notification-item__body">
                        <span class="notification-item__message"><?= e($notification['message']) ?></span>
                        <span class="notification-item__meta">
                            <?php if ($notification['actor_name']): ?>@<?= e($notification['actor_name']) ?> · <?php endif; ?>
                            <?= e(time_ago($notification['created_at'])) ?>
                            <?php if ((int) $notification['email_sent'] === 1): ?> · 已发邮件<?php endif; ?>
                        </span>
                    </span>
                    <?php if ((int) $notification['is_read'] === 0): ?><span class="unread-dot" aria-label="未读"></span><?php endif; ?>
                    <?= icon('chevron_right', 'notification-item__arrow', 18) ?>
                </a>
            <?php endforeach; ?>
        </div>
        <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
    <?php else: ?>
        <div class="empty-state">
            <?= icon('notifications', '', 38) ?>
            <h3>暂无通知</h3>
            <p>有人评论、回复或提到你时，会出现在这里。</p>
            <a class="btn btn--tonal" href="<?= e(url('posts')) ?>">去逛逛</a>
        </div>
    <?php endif; ?>
</section>
