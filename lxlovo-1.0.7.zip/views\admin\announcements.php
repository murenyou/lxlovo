<?php
$modeLabels = ['every' => '每次访问', 'daily' => '每天一次', 'once' => '仅一次'];
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Communication</span><h2>公告管理</h2><p>支持多个公告同时存在，每个公告可独立设置弹出频率。</p></div></div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>发布公告</h3></div>
    <form action="<?= e(admin_url('announcement.save')) ?>" method="post" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">标题</span><span class="field__box"><input type="text" name="title" maxlength="120" required></span></label>
            <label class="field"><span class="field__label">弹出方式</span><span class="field__box field__box--select"><select name="display_mode"><option value="daily">每天一次</option><option value="once">仅弹出一次</option><option value="every">每次访问都弹出</option></select></span></label>
            <label class="field field--span-2"><span class="field__label">内容（支持 HTML）</span><span class="field__box field__box--textarea"><textarea name="content" rows="5" required placeholder="写下公告内容…"></textarea></span></label>
            <label class="field"><span class="field__label">开始时间（可选）</span><span class="field__box"><input type="datetime-local" name="starts_at"></span></label>
            <label class="field"><span class="field__label">结束时间（可选）</span><span class="field__box"><input type="datetime-local" name="ends_at"></span></label>
            <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="10"></span></label>
            <label class="check-line"><input type="checkbox" name="enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">发布公告</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <span class="admin-edit-row__icon"><?= icon('mega', '', 22) ?></span>
                <div><h3><?= e($item['title']) ?></h3><p><span class="status-chip status-chip--<?= $item['enabled'] ? 'success' : 'neutral' ?>"><?= $item['enabled'] ? '启用中' : '已停用' ?></span> <span class="chip chip--soft"><?= e($modeLabels[$item['display_mode']] ?? $item['display_mode']) ?></span></p></div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('announcement.save')) ?>" method="post" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">标题</span><span class="field__box"><input type="text" name="title" value="<?= e($item['title']) ?>" required></span></label>
                                <label class="field"><span class="field__label">弹出方式</span><span class="field__box field__box--select"><select name="display_mode"><?php foreach ($modeLabels as $key => $label): ?><option value="<?= $key ?>" <?= $item['display_mode'] === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></span></label>
                                <label class="field field--span-2"><span class="field__label">内容（HTML）</span><span class="field__box field__box--textarea"><textarea name="content" rows="5" required><?= e($item['content']) ?></textarea></span></label>
                                <label class="field"><span class="field__label">开始时间</span><span class="field__box"><input type="datetime-local" name="starts_at" value="<?= e($item['starts_at'] ? date('Y-m-d\TH:i', strtotime($item['starts_at'])) : '') ?>"></span></label>
                                <label class="field"><span class="field__label">结束时间</span><span class="field__box"><input type="datetime-local" name="ends_at" value="<?= e($item['ends_at'] ? date('Y-m-d\TH:i', strtotime($item['ends_at'])) : '') ?>"></span></label>
                                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) $item['sort'] ?>"></span></label>
                                <label class="check-line"><input type="checkbox" name="enabled" value="1" <?= $item['enabled'] ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('announcement.delete')) ?>" method="post" data-confirm="确定删除这个公告吗？" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$items): ?><div class="admin-empty">还没有公告。</div><?php endif; ?>
