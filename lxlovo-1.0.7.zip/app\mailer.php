<?php

/* ---------------------------------------------------------------------------
 * SMTP 邮件（零依赖）
 * ------------------------------------------------------------------------- */

function smtp_read_response($socket): array
{
    $response = '';
    while (($line = fgets($socket, 1024)) !== false) {
        $response .= $line;
        if (strlen($line) < 4 || $line[3] === ' ') {
            break;
        }
    }
    return [(int) substr($response, 0, 3), trim($response)];
}

function smtp_command($socket, string $command, array $expected = []): array
{
    fwrite($socket, $command . "\r\n");
    [$code, $text] = smtp_read_response($socket);
    if ($expected !== [] && !in_array($code, $expected, true)) {
        throw new RuntimeException('SMTP 命令失败：' . $text);
    }
    return [$code, $text];
}

function send_mail(string $to, string $subject, string $htmlBody): array
{
    if (!email_configured()) {
        return ['ok' => false, 'error' => 'SMTP 尚未配置。'];
    }
    if (!valid_email($to)) {
        return ['ok' => false, 'error' => '收件邮箱无效。'];
    }
    $host = trim((string) setting('smtp_host'));
    $port = setting_int('smtp_port', 465);
    $secure = strtolower((string) setting('smtp_secure', 'ssl'));
    $user = trim((string) setting('smtp_user'));
    $pass = (string) setting('smtp_pass');
    $from = trim((string) setting('smtp_from')) ?: $user;
    $fromName = trim((string) setting('smtp_from_name', 'lxlovo'));

    if (!in_array($secure, ['ssl', 'tls', 'none'], true)) {
        $secure = 'ssl';
    }
    $target = $secure === 'ssl' ? 'ssl://' . $host . ':' . $port : 'tcp://' . $host . ':' . $port;
    $context = stream_context_create([
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
            'allow_self_signed' => false,
        ],
    ]);
    $errno = 0;
    $errstr = '';
    $socket = @stream_socket_client($target, $errno, $errstr, 20, STREAM_CLIENT_CONNECT, $context);
    if (!$socket) {
        return ['ok' => false, 'error' => '连接 SMTP 失败：' . $errstr];
    }
    stream_set_timeout($socket, 20);

    try {
        [$code] = smtp_read_response($socket);
        if ($code !== 220) {
            throw new RuntimeException('SMTP 服务未就绪。');
        }
        $hostname = gethostname() ?: 'localhost';
        smtp_command($socket, 'EHLO ' . $hostname, [250]);
        if ($secure === 'tls') {
            smtp_command($socket, 'STARTTLS', [220]);
            $crypto = stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            if ($crypto !== true) {
                throw new RuntimeException('无法建立 TLS 加密连接。');
            }
            smtp_command($socket, 'EHLO ' . $hostname, [250]);
        }
        if ($user !== '') {
            smtp_command($socket, 'AUTH LOGIN', [334]);
            smtp_command($socket, base64_encode($user), [334]);
            smtp_command($socket, base64_encode($pass), [235]);
        }
        smtp_command($socket, 'MAIL FROM:<' . $from . '>', [250]);
        smtp_command($socket, 'RCPT TO:<' . $to . '>', [250, 251]);
        smtp_command($socket, 'DATA', [354]);

        $subjectEncoded = '=?UTF-8?B?' . base64_encode($subject) . '?=';
        $fromEncoded = '=?UTF-8?B?' . base64_encode($fromName) . '?=';
        $boundary = 'lxlovo_' . bin2hex(random_bytes(12));
        $headers = [
            'Date: ' . date('r'),
            'From: ' . $fromEncoded . ' <' . $from . '>',
            'To: <' . $to . '>',
            'Subject: ' . $subjectEncoded,
            'MIME-Version: 1.0',
            'Content-Type: text/html; charset=UTF-8',
            'Content-Transfer-Encoding: base64',
            'Message-ID: <' . bin2hex(random_bytes(12)) . '@' . ($_SERVER['HTTP_HOST'] ?? 'lxlovo.local') . '>',
            'X-Mailer: lxlovo',
        ];
        $body = chunk_split(base64_encode($htmlBody), 76, "\r\n");
        $data = implode("\r\n", $headers) . "\r\n\r\n" . $body;
        $data = preg_replace('/^\./m', '..', $data) ?? $data;
        fwrite($socket, $data . "\r\n.\r\n");
        [$dataCode, $dataText] = smtp_read_response($socket);
        if ($dataCode !== 250) {
            throw new RuntimeException('SMTP 投递失败：' . $dataText);
        }
        @fwrite($socket, "QUIT\r\n");
        @fclose($socket);
        return ['ok' => true, 'error' => ''];
    } catch (Throwable $e) {
        @fclose($socket);
        error_log('[lxlovo mail] ' . $e->getMessage());
        return ['ok' => false, 'error' => $e->getMessage()];
    }
}

function email_template(string $title, string $bodyHtml, string $buttonText = '', string $buttonUrl = ''): string
{
    $site = e(setting('site_name', 'lxlovo'));
    $button = '';
    if ($buttonText !== '' && $buttonUrl !== '') {
        $button = '<p style="margin:28px 0"><a href="' . e($buttonUrl) . '" style="display:inline-block;background:#4f5bd5;color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:999px;font-weight:600">' . e($buttonText) . '</a></p>';
    }
    return '<div style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',\'Microsoft YaHei\',sans-serif;max-width:560px;margin:0 auto;padding:32px;background:#fbf8ff;border-radius:24px;color:#1b1b21">'
        . '<div style="font-size:20px;font-weight:800;color:#4f5bd5;margin-bottom:18px">' . $site . '</div>'
        . '<h2 style="margin:0 0 12px;font-size:22px">' . e($title) . '</h2>'
        . '<div style="line-height:1.8;color:#46464f">' . $bodyHtml . '</div>'
        . $button
        . '<p style="margin-top:28px;padding-top:18px;border-top:1px solid #e6e0e9;font-size:12px;color:#79747e">这封邮件由 ' . $site . ' 自动发送，请勿直接回复。</p>'
        . '</div>';
}

function send_notification_email(array $user, string $title, string $message, string $link = ''): bool
{
    if (!setting_bool('email_notify_enabled', true) || !email_configured() || empty($user['email']) || (int) ($user['notify_email'] ?? 1) !== 1) {
        return false;
    }
    $body = '<p>' . nl2br(e($message)) . '</p>';
    $html = email_template($title, $body, $link !== '' ? '查看详情' : '', $link);
    $result = send_mail((string) $user['email'], setting('site_name', 'lxlovo') . ' · ' . $title, $html);
    return (bool) $result['ok'];
}

function send_test_email(string $to): array
{
    return send_mail(
        $to,
        setting('site_name', 'lxlovo') . ' · SMTP 测试邮件',
        email_template('SMTP 配置成功', '<p>这是一封来自 lxlovo 后台的测试邮件。如果你看到了它，说明邮件服务已经可以正常工作。</p>')
    );
}
