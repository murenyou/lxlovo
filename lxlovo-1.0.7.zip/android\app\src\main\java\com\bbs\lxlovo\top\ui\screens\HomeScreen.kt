package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.bbs.lxlovo.top.data.Announcement
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Board
import com.bbs.lxlovo.top.data.HomeData
import com.bbs.lxlovo.top.data.Post
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.PostCard
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.SkeletonList
import com.bbs.lxlovo.top.ui.formatCount
import com.bbs.lxlovo.top.ui.parseColor

@Composable
fun HomeScreen(
    api: ApiClient,
    reloadKey: Int,
    onPostClick: (Int) -> Unit,
    onUserClick: (Int) -> Unit,
    onBoardClick: (Board) -> Unit,
    onAllBoards: () -> Unit,
    onViewAllPosts: () -> Unit,
    onOpenLink: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    var data by remember { mutableStateOf<HomeData?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var announcement by remember { mutableStateOf<Announcement?>(null) }
    var retryKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey, retryKey) {
        loading = data == null
        error = null
        try {
            data = api.home()
        } catch (exception: Exception) {
            error = exception.message ?: "首页加载失败。"
        } finally {
            loading = false
        }
    }

    when {
        loading && data == null -> SkeletonList(modifier)
        error != null && data == null -> Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            ErrorBox(error!!) { retryKey++ }
        }
        data == null -> EmptyBox("暂无内容", modifier)
        else -> {
            val home = data!!
            LazyColumn(
                modifier = modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                if (home.carousels.isNotEmpty()) {
                    item { HeroCarousel(home, onOpenLink) }
                }
                if (home.announcements.isNotEmpty()) {
                    item { SectionHeader("公告") }
                    items(home.announcements, key = { "announcement-${it.id}" }) { announcementItem ->
                        AnnouncementBar(announcementItem) { announcement = announcementItem }
                    }
                }
                if (home.boards.isNotEmpty()) {
                    item {
                        Column {
                            SectionHeader("板块", "全部", onAllBoards)
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(home.boards, key = { it.id }) { board ->
                                    BoardChip(board) { onBoardClick(board) }
                                }
                            }
                        }
                    }
                }
                if (home.pinned.isNotEmpty()) {
                    item { SectionHeader("置顶", "全部", onViewAllPosts) }
                    items(home.pinned, key = { "pinned-${it.id}" }) { post ->
                        PostCard(post, { onPostClick(post.id) }, onUserClick)
                    }
                }
                if (home.latest.isNotEmpty()) {
                    item { SectionHeader("最新", "全部", onViewAllPosts) }
                    items(home.latest, key = { "latest-${it.id}" }) { post ->
                        PostCard(post, { onPostClick(post.id) }, onUserClick)
                    }
                }
                if (home.hot.isNotEmpty()) {
                    item { SectionHeader("热门", "全部", onViewAllPosts) }
                    items(home.hot, key = { "hot-${it.id}" }) { post ->
                        HotPostRow(post, { onPostClick(post.id) }, onUserClick)
                    }
                }
                if (home.featured.isNotEmpty()) {
                    item { SectionHeader("精华") }
                    items(home.featured.take(3), key = { "featured-${it.id}" }) { post ->
                        PostCard(post, { onPostClick(post.id) }, onUserClick)
                    }
                }
                if (home.random.isNotEmpty()) {
                    item { SectionHeader("随机推荐") }
                    items(home.random, key = { "random-${it.id}" }) { post ->
                        HotPostRow(post, { onPostClick(post.id) }, onUserClick)
                    }
                }
                item { StatsCard(home) }
            }
        }
    }

    announcement?.let {
        AlertDialog(
            onDismissRequest = { announcement = null },
            icon = { Icon(Icons.Outlined.Campaign, contentDescription = null) },
            title = { Text(it.title) },
            text = {
                Column {
                    com.bbs.lxlovo.top.ui.HtmlContent(it.content)
                }
            },
            confirmButton = {
                TextButton(onClick = { announcement = null }) { Text("知道了") }
            },
        )
    }
}

@Composable
private fun HeroCarousel(home: HomeData, onOpenLink: (String) -> Unit) {
    val pagerState = rememberPagerState(pageCount = { home.carousels.size })
    LaunchedEffect(pagerState, home.carousels.size) {
        if (home.carousels.size <= 1) return@LaunchedEffect
        while (true) {
            kotlinx.coroutines.delay(5000)
            pagerState.animateScrollToPage((pagerState.currentPage + 1) % home.carousels.size)
        }
    }
    Column {
        HorizontalPager(
            state = pagerState,
            pageSpacing = 10.dp,
            modifier = Modifier.fillMaxWidth(),
        ) { page ->
            val item = home.carousels[page]
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer)
                    .clickable(enabled = item.link.isNotBlank()) { onOpenLink(item.link) },
            ) {
                AsyncImage(
                    model = item.imageUrl,
                    contentDescription = item.title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    error = ColorPainter(MaterialTheme.colorScheme.primaryContainer),
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(18.dp),
                ) {
                    Text(
                        item.title,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (item.subtitle.isNotBlank()) {
                        Text(
                            item.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.82f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
        if (home.carousels.size > 1) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                horizontalArrangement = Arrangement.Center,
            ) {
                repeat(home.carousels.size) { index ->
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(if (pagerState.currentPage == index) 7.dp else 5.dp)
                            .clip(androidx.compose.foundation.shape.CircleShape)
                            .background(
                                if (pagerState.currentPage == index) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.outlineVariant
                            )
                    )
                }
            }
        }
    }
}

@Composable
private fun AnnouncementBar(announcement: Announcement, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.tertiaryContainer,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.Outlined.Campaign,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.size(18.dp),
            )
            Spacer(Modifier.size(9.dp))
            Text(
                announcement.title,
                modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onTertiaryContainer,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Icon(
                Icons.Outlined.ChevronRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onTertiaryContainer,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}

@Composable
private fun BoardChip(board: Board, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = {
            Column {
                Text(board.name, fontWeight = FontWeight.SemiBold)
                Text(
                    "${formatCount(board.postCount)} 帖",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                )
            }
        },
        shape = RoundedCornerShape(50),
    )
}

@Composable
private fun HotPostRow(post: Post, onClick: () -> Unit, onUserClick: (Int) -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
            ) {
                Text(
                    "热",
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                )
            }
            Spacer(Modifier.size(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    post.title,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${post.boardName} · ${post.author.username}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline,
                    maxLines = 1,
                )
            }
            Text(
                formatCount(post.views + post.likes * 8),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.primary,
            )
        }
    }
}

@Composable
private fun StatsCard(home: HomeData) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                "社区数据",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                StatItem("成员", home.stats.users)
                StatItem("帖子", home.stats.posts)
                StatItem("评论", home.stats.comments)
                StatItem("今日发帖", home.stats.todayPosts)
                StatItem("在线", home.stats.online)
            }
        }
    }
}

@Composable
private fun StatItem(label: String, value: Int) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            formatCount(value),
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
        )
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.72f),
        )
    }
}
