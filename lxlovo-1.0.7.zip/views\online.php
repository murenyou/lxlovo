<?php ?>
<section class="page-head page-head--compact">
    <div><span class="page-head__eyebrow">Online</span><h1>在线用户</h1><p>最近 <?= setting_int('online_minutes', 15) ?> 分钟内活跃的社区成员。</p></div>
    <span class="online-pill"><i></i><?= count($users) ?> 人在线</span>
</section>

<?php if ($users): ?>
    <div class="user-grid">
        <?php foreach ($users as $onlineUser): ?>
            <?php $level = level_for_exp((int) $onlineUser['exp']); ?>
            <a class="user-card" href="<?= e(url('user', ['id' => (int) $onlineUser['id']])) ?>">
                <span class="conversation__avatar">
                    <img class="avatar avatar--md" src="<?= e(avatar_url($onlineUser)) ?>" alt="">
                    <i class="online-dot"></i>
                </span>
                <span class="user-card__body">
                    <span class="user-card__name"><?= e($onlineUser['username']) ?> <?= badge_html((int) $onlineUser['id'], $onlineUser) ?></span>
                    <span class="user-card__bio"><?= e($onlineUser['bio'] ?: '这个人还没有写下简介。') ?></span>
                    <span class="user-card__meta">Lv.<?= (int) $level['level'] ?> <?= e($level['name']) ?> · <?= e(time_ago($onlineUser['last_active_at'])) ?>活跃</span>
                </span>
                <?= icon('chevron_right', '', 18) ?>
            </a>
        <?php endforeach; ?>
    </div>
<?php else: ?>
    <div class="empty-state"><?= icon('users', '', 38) ?><h3>此刻没有人在线</h3><p>你可以去读一篇文章，或者留下第一条新内容。</p><a class="btn btn--primary" href="<?= e(url('posts')) ?>">去阅读</a></div>
<?php endif; ?>
