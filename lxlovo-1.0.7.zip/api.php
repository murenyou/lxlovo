<?php

require __DIR__ . '/app/bootstrap.php';
require LXL_APP . '/site_pages.php';
require LXL_APP . '/api.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Max-Age: 86400');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}
if (!in_array(($_SERVER['REQUEST_METHOD'] ?? 'GET'), ['GET', 'POST'], true)) {
    http_response_code(405);
    echo json_encode(['ok' => false, 'message' => '只支持 GET 或 POST 请求。'], JSON_UNESCAPED_UNICODE);
    exit;
}

$action = (string) ($_GET['action'] ?? $_POST['action'] ?? 'app.version');

try {
    api_handle($action);
} catch (Throwable $e) {
    error_log('[lxlovo api] ' . $e->getMessage() . ' in ' . $e->getFile() . ':' . $e->getLine());
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'message' => '服务器暂时无法处理请求。',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
