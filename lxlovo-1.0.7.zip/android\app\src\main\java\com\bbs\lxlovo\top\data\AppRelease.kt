package com.bbs.lxlovo.top.data

data class AppRelease(
    val id: Int,
    val versionName: String,
    val versionCode: Int,
    val downloadUrl: String,
    val downloadMode: String,
    val directDownload: Boolean,
    val isForced: Boolean,
    val changelog: String,
    val publishedAt: String,
) {
    fun changelogLines(): List<String> = changelog
        .lineSequence()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .map { it.removePrefix("- ").removePrefix("• ").trim() }
        .filter { it.isNotEmpty() }
        .toList()
}

data class UpdateInfo(
    val latest: AppRelease?,
    val releases: List<AppRelease>,
    val updateAvailable: Boolean,
    val forceUpdate: Boolean,
    val inAppBrowserDefault: Boolean,
) {
    fun newerReleases(currentCode: Int): List<AppRelease> =
        releases.filter { it.versionCode > currentCode }.sortedByDescending { it.versionCode }
}
