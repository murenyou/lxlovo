<?php
$cardUser = [
    'id' => (int) $post['user_id'],
    'username' => $post['username'] ?? '',
    'avatar' => $post['avatar'] ?? '',
    'show_official_badge' => $post['show_official_badge'] ?? 1,
    'exp' => $post['exp'] ?? 0,
];
$cardLevel = level_for_exp((int) ($post['exp'] ?? 0));
$isOfficial = is_official_card_enabled((int) $post['user_id'], $cardUser);
$showBoard = $showBoard ?? true;
$compact = $compact ?? false;
$hasCover = !$compact && !empty($post['cover']);
$cardClasses = 'post-card';
if ($isOfficial) { $cardClasses .= ' post-card--official'; }
if ($compact) { $cardClasses .= ' post-card--compact'; }
if (!$compact && !$hasCover) { $cardClasses .= ' post-card--no-cover'; }
?>
<article class="<?= e($cardClasses) ?>"<?= $isOfficial ? ' style="--card-accent:' . e(official_color((int) $post['user_id'])) . '"' : '' ?>>
    <?php if ($hasCover): ?>
        <a class="post-card__cover" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>" tabindex="-1" aria-hidden="true">
            <img src="<?= e(media_url($post['cover'])) ?>" alt="" loading="lazy">
        </a>
    <?php endif; ?>
    <div class="post-card__body">
        <div class="post-card__meta">
            <?php if ($showBoard && !empty($post['board_name'])): ?>
                <a class="chip chip--board" href="<?= e(url('posts', ['board' => (int) $post['board_id']])) ?>" style="--chip-color:<?= e($post['board_color'] ?: '#4F5BD5') ?>">
                    <?= e($post['board_name']) ?>
                </a>
            <?php endif; ?>
            <?php if ((int) ($post['is_pinned'] ?? 0) === 1): ?><span class="chip chip--pin"><?= icon('pin', '', 13) ?>置顶</span><?php endif; ?>
            <?php if ((int) ($post['is_featured'] ?? 0) === 1): ?><span class="chip chip--feature"><?= icon('star', '', 13) ?>精选</span><?php endif; ?>
            <?php if (($post['status'] ?? 'published') !== 'published'): ?><span class="chip chip--draft"><?= ($post['status'] ?? '') === 'draft' ? '草稿' : '已删除' ?></span><?php endif; ?>
            <time datetime="<?= e($post['created_at']) ?>"><?= e(time_ago($post['created_at'])) ?></time>
        </div>
        <h3 class="post-card__title">
            <a href="<?= e(url('post', ['id' => (int) $post['id']])) ?>"><?= e($post['title']) ?></a>
        </h3>
        <?php if (!$compact): ?>
            <p class="post-card__excerpt"><?= e(post_excerpt($post, 110)) ?></p>
        <?php endif; ?>
        <div class="post-card__foot">
            <a class="author-mini" href="<?= e(url('user', ['id' => (int) $post['user_id']])) ?>">
                <img class="avatar avatar--xxs" src="<?= e(avatar_url($cardUser)) ?>" alt="">
                <span class="author-mini__name"><?= e($post['username'] ?? '') ?></span>
                <?= badge_html((int) $post['user_id'], $cardUser) ?>
                <span class="level-dot" style="--level-color:<?= e($cardLevel['color']) ?>" title="<?= e($cardLevel['name']) ?>">Lv.<?= (int) $cardLevel['level'] ?></span>
            </a>
            <div class="post-card__stats">
                <span title="浏览"><?= icon('eye', '', 16) ?><?= short_number((int) ($post['views'] ?? 0)) ?></span>
                <span title="点赞"><?= icon('thumb_up', '', 16) ?><?= short_number((int) ($post['likes_count'] ?? 0)) ?></span>
                <span title="评论"><?= icon('comment', '', 16) ?><?= short_number((int) ($post['comments_count'] ?? 0)) ?></span>
            </div>
        </div>
    </div>
</article>
