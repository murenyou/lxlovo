<?php ?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Community</span><h2>友情链接</h2><p>友链会展示在友链页面与页脚，可按标签分组。</p></div></div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>新增友链</h3></div>
    <form action="<?= e(admin_url('link.save')) ?>" method="post" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">站点名称</span><span class="field__box"><input type="text" name="name" maxlength="60" required></span></label>
            <label class="field"><span class="field__label">站点地址</span><span class="field__box"><input type="url" name="url" placeholder="https://" required></span></label>
            <label class="field"><span class="field__label">标签</span><span class="field__box"><input type="text" name="tag" maxlength="30" placeholder="例如 伙伴"></span></label>
            <label class="field"><span class="field__label">Logo 地址</span><span class="field__box"><input type="text" name="logo" placeholder="https://… 或 assets/…"></span></label>
            <label class="field field--span-2"><span class="field__label">简介</span><span class="field__box"><input type="text" name="description" maxlength="255"></span></label>
            <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="10"></span></label>
            <label class="check-line"><input type="checkbox" name="enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">添加友链</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <span class="admin-link-logo"><?php if ($item['logo']): ?><img src="<?= e(media_url($item['logo'])) ?>" alt=""><?php else: ?><?= e(mb_substr($item['name'], 0, 1)) ?><?php endif; ?></span>
                <div><h3><?= e($item['name']) ?> <?= $item['enabled'] ? '' : '<span class="status-chip status-chip--neutral">停用</span>' ?></h3><p><?= e($item['url']) ?> · <?= e($item['tag'] ?: '未分组') ?></p></div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('link.save')) ?>" method="post" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">名称</span><span class="field__box"><input type="text" name="name" value="<?= e($item['name']) ?>" required></span></label>
                                <label class="field"><span class="field__label">地址</span><span class="field__box"><input type="url" name="url" value="<?= e($item['url']) ?>" required></span></label>
                                <label class="field"><span class="field__label">标签</span><span class="field__box"><input type="text" name="tag" value="<?= e($item['tag']) ?>"></span></label>
                                <label class="field"><span class="field__label">Logo</span><span class="field__box"><input type="text" name="logo" value="<?= e($item['logo']) ?>"></span></label>
                                <label class="field field--span-2"><span class="field__label">简介</span><span class="field__box"><input type="text" name="description" value="<?= e($item['description']) ?>"></span></label>
                                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) $item['sort'] ?>"></span></label>
                                <label class="check-line"><input type="checkbox" name="enabled" value="1" <?= $item['enabled'] ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('link.delete')) ?>" method="post" data-confirm="确定删除这个友链吗？" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$items): ?><div class="admin-empty">还没有友链。</div><?php endif; ?>
