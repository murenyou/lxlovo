package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import coil.compose.AsyncImage
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Board
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComposePostScreen(
    api: ApiClient,
    editingId: Int? = null,
    onBack: () -> Unit,
    onCreated: (Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var boards by remember { mutableStateOf<List<Board>>(emptyList()) }
    var boardId by remember { mutableStateOf(0) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var coverUrl by remember { mutableStateOf("") }
    var uploadingCover by remember { mutableStateOf(false) }
    var loadingBoards by remember { mutableStateOf(true) }
    var posting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null && !uploadingCover) {
            uploadingCover = true
            scope.launch {
                try {
                    coverUrl = api.uploadPostImage(uri)
                } catch (exception: Exception) {
                    error = exception.message ?: "封面上传失败。"
                } finally {
                    uploadingCover = false
                }
            }
        }
    }

    LaunchedEffect(editingId) {
        try {
            boards = api.boards()
            boardId = boards.firstOrNull()?.id ?: 0
            if (editingId != null) {
                val post = api.post(editingId)
                title = post.title
                content = post.contentText.ifBlank { post.excerpt }
                boardId = post.boardId
                coverUrl = post.coverUrl
            }
        } catch (exception: Exception) {
            error = exception.message ?: "内容加载失败。"
        } finally {
            loadingBoards = false
        }
    }

    fun publish() {
        if (posting) return
        error = null
        if (boardId <= 0) {
            error = "请选择板块。"
            return
        }
        if (title.trim().length < 2) {
            error = "标题至少需要 2 个字符。"
            return
        }
        if (content.trim().isEmpty()) {
            error = "正文不能为空。"
            return
        }
        posting = true
        scope.launch {
            try {
                val id = if (editingId != null) {
                    api.updatePost(editingId, title.trim(), boardId, content.trim(), coverUrl)
                    editingId
                } else {
                    api.createPost(title.trim(), boardId, content.trim(), coverUrl)
                }
                onCreated(id)
            } catch (exception: Exception) {
                error = exception.message ?: if (editingId != null) "保存失败。" else "发布失败。"
            } finally {
                posting = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (editingId != null) "编辑文章" else "发布文章") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    Button(
                        onClick = ::publish,
                        enabled = !posting && !loadingBoards,
                        modifier = Modifier.padding(end = 10.dp),
                    ) {
                        if (posting) {
                            CircularProgressIndicator(
                                Modifier.size(16.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary,
                            )
                            Spacer(Modifier.size(6.dp))
                        }
                        Text(if (editingId != null) "保存" else "发布")
                    }
                },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .imePadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            Text("选择板块", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            if (loadingBoards) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp),
                ) {
                    items(boards, key = { it.id }) { board ->
                        FilterChip(
                            selected = boardId == board.id,
                            onClick = { boardId = board.id },
                            label = { Text(board.name) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                TextButton(
                    onClick = { coverPicker.launch("image/*") },
                    enabled = !uploadingCover,
                ) {
                    if (uploadingCover) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Icon(Icons.Outlined.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.size(5.dp))
                    Text(if (coverUrl.isBlank()) "添加封面图" else "更换封面图")
                }
                if (coverUrl.isNotBlank()) {
                    TextButton(onClick = { coverUrl = "" }) { Text("移除") }
                }
            }
            if (coverUrl.isNotBlank()) {
                AsyncImage(
                    model = coverUrl,
                    contentDescription = "封面",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .padding(bottom = 8.dp),
                    contentScale = ContentScale.Crop,
                    placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                    error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                )
            }
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(120) },
                label = { Text("标题") },
                placeholder = { Text("一个清晰、具体的标题") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                label = { Text("正文") },
                placeholder = { Text("用文字记录你的想法…\n\n当前原生编辑器支持纯文本，发布后会自动排版。") },
                modifier = Modifier.fillMaxWidth().weight(1f),
                minLines = 8,
            )
            if (error != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        error!!,
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "${content.length} 字符 · 发布后不可在 App 内编辑",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline,
            )
        }
    }
}
