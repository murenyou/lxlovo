<?php ?>
<section class="page-head">
    <div>
        <span class="page-head__eyebrow">Boards</span>
        <h1>板块</h1>
        <p>选择你感兴趣的角落，开始阅读与分享。</p>
    </div>
    <a class="btn btn--tonal" href="<?= e(url('search')) ?>"><?= icon('search', '', 18) ?>全局搜索</a>
</section>

<div class="board-catalog">
    <?php foreach ($boards as $board): ?>
        <article class="board-card" style="--board-color:<?= e($board['color']) ?>">
            <div class="board-card__top">
                <span class="board-card__icon"><?= icon($board['icon'] ?: 'board', '', 26) ?></span>
                <span class="board-card__count"><?= short_number((int) $board['post_count']) ?> 篇文章</span>
            </div>
            <h2><a href="<?= e(url('posts', ['board' => (int) $board['id']])) ?>"><?= e($board['name']) ?></a></h2>
            <p><?= e($board['description']) ?></p>
            <?php if (!empty($mods[(int) $board['id']])): ?>
                <div class="board-card__mods">
                    <span>维护者</span>
                    <div class="avatar-stack">
                        <?php foreach ($mods[(int) $board['id']] as $mod): ?>
                            <a href="<?= e(url('user', ['id' => (int) $mod['id']])) ?>" title="<?= e($mod['username']) ?><?= $mod['role'] === 'owner' ? ' · 板块主' : ' · 副板块主' ?>">
                                <img class="avatar avatar--xxs" src="<?= e(avatar_url($mod)) ?>" alt="<?= e($mod['username']) ?>">
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
            <div class="board-card__foot">
                <?php if (!empty($latest[(int) $board['id']])): ?>
                    <a class="board-card__latest" href="<?= e(url('post', ['id' => (int) $latest[(int) $board['id']]['id']])) ?>">
                        <?= icon('article', '', 15) ?><span><?= e($latest[(int) $board['id']]['title']) ?></span>
                    </a>
                <?php else: ?>
                    <span class="muted-text">还没有文章</span>
                <?php endif; ?>
                <a class="board-card__enter" href="<?= e(url('posts', ['board' => (int) $board['id']])) ?>">进入<?= icon('chevron_right', '', 17) ?></a>
            </div>
        </article>
    <?php endforeach; ?>
</div>

<section class="callout">
    <div>
        <span class="callout__icon"><?= icon('shield', '', 24) ?></span>
        <div><h2>板块由官方统一创建</h2><p>板块主与副板块主负责日常维护。需要新的板块？请联系管理员。</p></div>
    </div>
    <a class="btn btn--outlined" href="<?= e(url('about')) ?>">了解社区</a>
</section>
