package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Board
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.BoardPill
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.formatCount
import com.bbs.lxlovo.top.ui.formatTime
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoardsScreen(
    api: ApiClient,
    currentUser: User?,
    onBack: () -> Unit,
    onBoardClick: (Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    var boards by remember { mutableStateOf<List<Board>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var key by remember { mutableIntStateOf(0) }
    var createOpen by remember { mutableStateOf(false) }
    var creating by remember { mutableStateOf(false) }
    var createError by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(key) {
        loading = true
        error = null
        try {
            boards = api.boards()
        } catch (exception: Exception) {
            error = exception.message ?: "板块加载失败。"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("论坛板块") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    if (currentUser?.isAdmin == true) {
                        IconButton(onClick = { createOpen = true }) {
                            Icon(Icons.Outlined.Add, contentDescription = "创建板块")
                        }
                    }
                },
            )
        },
    ) { padding ->
        when {
            loading -> LoadingBox(Modifier.padding(padding))
            error != null -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                ErrorBox(error!!) { key++ }
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(boards, key = { it.id }) { board ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { onBoardClick(board.id) },
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BoardPill(board.name, board.color)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "${formatCount(board.postCount)} 篇",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline,
                                )
                            }
                            if (board.description.isNotBlank()) {
                                Spacer(Modifier.height(8.dp))
                                Text(board.description, style = MaterialTheme.typography.bodyMedium)
                            }
                            board.latestPost?.let {
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    "最新：${it.title}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                )
                            }
                            if (board.moderators.isNotEmpty()) {
                                Spacer(Modifier.height(10.dp))
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(board.moderators, key = { "${board.id}-${it.id}" }) { mod ->
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            LxlovoAvatar(
                                                User(username = mod.username, avatarUrl = mod.avatarUrl),
                                                20,
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                mod.username,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (createOpen) {
        CreateBoardDialog(
            busy = creating,
            error = createError,
            onDismiss = { if (!creating) createOpen = false },
            onCreate = { name, slug, description, color ->
                if (!creating) {
                    creating = true
                    createError = null
                    scope.launch {
                        try {
                            api.createBoard(name, slug, description, color)
                            createOpen = false
                            key++
                        } catch (exception: Exception) {
                            createError = exception.message ?: "创建失败"
                        } finally {
                            creating = false
                        }
                    }
                }
            },
        )
    }
}

@Composable
private fun CreateBoardDialog(
    busy: Boolean,
    error: String?,
    onDismiss: () -> Unit,
    onCreate: (String, String, String, String) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var slug by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var color by remember { mutableStateOf("#4F5BD5") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("创建板块") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it.take(40) },
                    label = { Text("板块名称") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = slug,
                    onValueChange = { slug = it.lowercase().replace(" ", "-").take(60) },
                    label = { Text("板块标识（英文 / 数字）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it.take(255) },
                    label = { Text("简介") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 2,
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = color,
                    onValueChange = { color = it.take(7) },
                    label = { Text("颜色（#RRGGBB）") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (error != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onCreate(name, slug, description, color) },
                enabled = !busy && name.length >= 2 && slug.length >= 2,
            ) { Text("创建") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("取消") }
        },
    )
}
