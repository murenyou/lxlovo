<?php

/* ---------------------------------------------------------------------------
 * 账号：注册、登录、邮箱验证、密码
 * ------------------------------------------------------------------------- */

function find_user_by_login(string $login): ?array
{
    return db_one('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1', [$login, $login]);
}

function register_user(string $username, string $email, string $password, string $passwordConfirm): array
{
    if (!setting_bool('register_enabled', true)) {
        return [false, '当前站点暂时关闭了注册。'];
    }
    $username = normalize_username($username);
    $email = mb_strtolower(trim($email));
    if (!username_is_valid($username)) {
        return [false, '用户名需为 2-32 位中文、字母、数字、下划线或短横线。'];
    }
    if (!valid_email($email)) {
        return [false, '请输入有效的邮箱地址。'];
    }
    if (mb_strlen($password) < 8 || mb_strlen($password) > 72) {
        return [false, '密码长度需为 8-72 位。'];
    }
    if ($password !== $passwordConfirm) {
        return [false, '两次输入的密码不一致。'];
    }
    if (db_value('SELECT COUNT(*) FROM users WHERE username = ?', [$username], 0) > 0) {
        return [false, '这个用户名已经被使用。'];
    }
    if (db_value('SELECT COUNT(*) FROM users WHERE email = ?', [$email], 0) > 0) {
        return [false, '这个邮箱已经绑定过账号。'];
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $id = db_insert(
        'INSERT INTO users (username, email, password_hash, role, status, exp, coins, level, last_active_at)
         VALUES (?, ?, ?, "user", "active", 0, 0, 0, NOW())',
        [$username, $email, $hash]
    );
    $user = db_one('SELECT * FROM users WHERE id = ?', [$id]);

    $mailNote = '';
    if (email_configured()) {
        [$sent] = send_email_verification($id);
        if (!$sent) {
            $mailNote = '验证邮件发送失败，请登录后重新发送或联系管理员。';
        }
    } elseif (setting_bool('email_verify_required')) {
        $mailNote = '站点尚未配置 SMTP，暂时无法发送验证邮件，请联系管理员。';
    }

    return [true, $mailNote, $user];
}

function login_user_by_credentials(string $login, string $password): array
{
    if (!rate_limit('login', 10, 600)) {
        return [false, '尝试次数过多，请稍后再试。'];
    }
    $login = trim($login);
    if ($login === '' || $password === '') {
        return [false, '请输入账号和密码。'];
    }
    $user = find_user_by_login($login);
    if (!$user || !password_verify($password, $user['password_hash'])) {
        return [false, '账号或密码不正确。'];
    }
    if ($user['status'] === 'banned') {
        return [false, '该账号已被封禁，如有疑问请联系管理员。'];
    }
    rate_limit_clear('login');
    db_exec('UPDATE users SET last_active_at = NOW() WHERE id = ?', [(int) $user['id']]);
    login_user($user);
    return [true, '', db_one('SELECT * FROM users WHERE id = ?', [(int) $user['id']])];
}

function make_email_token(int $userId): string
{
    $raw = bin2hex(random_bytes(32));
    db_exec(
        'UPDATE users SET email_verify_token = ?, email_verify_expires = DATE_ADD(NOW(), INTERVAL 24 HOUR) WHERE id = ?',
        [hash('sha256', $raw), $userId]
    );
    return $raw;
}

function send_email_verification(int $userId): array
{
    $user = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    if (!$user) {
        return [false, '账号不存在。'];
    }
    if (!email_configured()) {
        return [false, 'SMTP 尚未配置，无法发送邮件。'];
    }
    if (!empty($user['email_verified_at'])) {
        return [false, '这个邮箱已经验证过了。'];
    }
    $raw = make_email_token($userId);
    $link = absolute_url(url('verify_email', ['token' => $raw]));
    $site = e(setting('site_name', 'lxlovo'));
    $name = e($user['username']);
    $html = '<div style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',\'Microsoft YaHei\',sans-serif;max-width:560px;margin:0 auto;padding:32px;background:#fbf8ff;border-radius:24px;color:#1b1b21">'
        . '<h2 style="margin:0 0 8px">欢迎来到 ' . $site . '</h2>'
        . '<p style="line-height:1.8;color:#46464f">' . $name . '，你好。请点击下面的按钮完成邮箱验证，链接 24 小时内有效。</p>'
        . '<p style="margin:28px 0"><a href="' . e($link) . '" style="display:inline-block;background:#4f5bd5;color:#fff;text-decoration:none;padding:12px 24px;border-radius:999px">验证邮箱</a></p>'
        . '<p style="font-size:13px;color:#79747e;line-height:1.7">如果按钮无法打开，请复制以下链接：<br><a href="' . e($link) . '" style="color:#4f5bd5;word-break:break-all">' . e($link) . '</a></p>'
        . '<p style="font-size:13px;color:#79747e">如果你没有注册 ' . $site . '，请忽略这封邮件。</p></div>';
    $result = send_mail((string) $user['email'], $site . ' · 验证你的邮箱', $html);
    return [$result['ok'], $result['error'] ?? ''];
}

function verify_email_token(string $rawToken): array
{
    $rawToken = trim($rawToken);
    if ($rawToken === '' || !preg_match('/^[a-f0-9]{64}$/i', $rawToken)) {
        return [false, '验证链接无效。'];
    }
    $user = db_one(
        'SELECT * FROM users WHERE email_verify_token = ? AND email_verify_expires > NOW() LIMIT 1',
        [hash('sha256', $rawToken)]
    );
    if (!$user) {
        return [false, '验证链接无效或已过期，请重新发送。'];
    }
    db_exec(
        'UPDATE users SET email_verified_at = NOW(), email_verify_token = NULL, email_verify_expires = NULL WHERE id = ?',
        [(int) $user['id']]
    );
    if ((int) (current_user()['id'] ?? 0) === (int) $user['id']) {
        refresh_current_user();
    }
    return [true, '邮箱验证成功。'];
}

function request_password_reset(string $email): array
{
    $email = mb_strtolower(trim($email));
    if (!valid_email($email)) {
        return [false, '请输入有效的邮箱。'];
    }
    if (!email_configured()) {
        return [false, 'SMTP 尚未配置，暂时无法发送重置邮件。'];
    }
    $user = db_one('SELECT * FROM users WHERE email = ? LIMIT 1', [$email]);
    if (!$user) {
        return [true, '如果该邮箱已注册，我们会发送一封重置邮件。'];
    }
    $raw = bin2hex(random_bytes(32));
    db_exec(
        'UPDATE users SET reset_token = ?, reset_expires = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE id = ?',
        [hash('sha256', $raw), (int) $user['id']]
    );
    $link = absolute_url(url('reset_password', ['token' => $raw]));
    $site = e(setting('site_name', 'lxlovo'));
    $html = '<div style="font-family:-apple-system,BlinkMacSystemFont,\'Segoe UI\',\'Microsoft YaHei\',sans-serif;max-width:560px;margin:0 auto;padding:32px;background:#fbf8ff;border-radius:24px;color:#1b1b21">'
        . '<h2 style="margin:0 0 8px">重置 ' . $site . ' 密码</h2>'
        . '<p style="line-height:1.8;color:#46464f">我们收到了你的密码重置请求。链接 1 小时内有效，只能使用一次。</p>'
        . '<p style="margin:28px 0"><a href="' . e($link) . '" style="display:inline-block;background:#4f5bd5;color:#fff;text-decoration:none;padding:12px 24px;border-radius:999px">设置新密码</a></p>'
        . '<p style="font-size:13px;color:#79747e;word-break:break-all">' . e($link) . '</p>'
        . '<p style="font-size:13px;color:#79747e">如果不是你本人操作，请忽略这封邮件，你的密码不会改变。</p></div>';
    $result = send_mail((string) $user['email'], $site . ' · 重置密码', $html);
    if (!$result['ok']) {
        return [false, '邮件发送失败，请稍后再试。'];
    }
    return [true, '如果该邮箱已注册，我们会发送一封重置邮件。'];
}

function reset_password_with_token(string $rawToken, string $password, string $confirm): array
{
    if (mb_strlen($password) < 8 || mb_strlen($password) > 72) {
        return [false, '密码长度需为 8-72 位。'];
    }
    if ($password !== $confirm) {
        return [false, '两次输入的密码不一致。'];
    }
    if (!preg_match('/^[a-f0-9]{64}$/i', $rawToken)) {
        return [false, '重置链接无效。'];
    }
    $user = db_one(
        'SELECT * FROM users WHERE reset_token = ? AND reset_expires > NOW() LIMIT 1',
        [hash('sha256', $rawToken)]
    );
    if (!$user) {
        return [false, '重置链接无效或已过期。'];
    }
    db_exec(
        'UPDATE users SET password_hash = ?, reset_token = NULL, reset_expires = NULL WHERE id = ?',
        [password_hash($password, PASSWORD_BCRYPT), (int) $user['id']]
    );
    return [true, '密码已重置，请使用新密码登录。'];
}

function change_password(array $user, string $oldPassword, string $newPassword, string $confirm): array
{
    if (!password_verify($oldPassword, $user['password_hash'])) {
        return [false, '当前密码不正确。'];
    }
    if (mb_strlen($newPassword) < 8 || mb_strlen($newPassword) > 72) {
        return [false, '新密码长度需为 8-72 位。'];
    }
    if ($newPassword !== $confirm) {
        return [false, '两次输入的新密码不一致。'];
    }
    db_exec(
        'UPDATE users SET password_hash = ? WHERE id = ?',
        [password_hash($newPassword, PASSWORD_BCRYPT), (int) $user['id']]
    );
    refresh_current_user();
    return [true, '密码已更新。'];
}

function change_email(array $user, string $newEmail, string $password): array
{
    $newEmail = mb_strtolower(trim($newEmail));
    if (!valid_email($newEmail)) {
        return [false, '请输入有效的邮箱地址。'];
    }
    if (!password_verify($password, $user['password_hash'])) {
        return [false, '请输入当前密码以确认修改。'];
    }
    if (db_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$newEmail, (int) $user['id']], 0) > 0) {
        return [false, '这个邮箱已经绑定过其他账号。'];
    }
    db_exec('UPDATE users SET email = ?, email_verified_at = NULL, email_verify_token = NULL WHERE id = ?', [$newEmail, (int) $user['id']]);
    refresh_current_user();
    if (email_configured()) {
        send_email_verification((int) $user['id']);
        return [true, '邮箱已更新，验证邮件已发送。'];
    }
    return [true, '邮箱已更新。站点尚未配置 SMTP，请稍后验证。'];
}

function award_exp(int $userId, int $exp): void
{
    if ($exp <= 0) {
        return;
    }
    db_exec('UPDATE users SET exp = exp + ? WHERE id = ?', [$exp, $userId]);
    recalculate_level($userId);
}

function recalculate_level(int $userId): void
{
    $exp = (int) db_value('SELECT exp FROM users WHERE id = ?', [$userId], 0);
    $level = level_for_exp($exp);
    db_exec('UPDATE users SET level = ? WHERE id = ?', [(int) $level['level'], $userId]);
}

function apply_checkin(array $user): array
{
    if (!setting_bool('checkin_enabled', true)) {
        return [false, '签到功能暂时关闭。'];
    }
    $today = date('Y-m-d');
    $yesterday = date('Y-m-d', strtotime('-1 day'));

    return db_transaction(function (PDO $pdo) use ($user, $today, $yesterday) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? FOR UPDATE');
        $stmt->execute([(int) $user['id']]);
        $fresh = $stmt->fetch();
        if (!$fresh) {
            return [false, '账号不存在。'];
        }
        if ($fresh['last_checkin_date'] === $today) {
            return [false, '今天已经签到过了，明天再来吧。'];
        }
        $streak = $fresh['last_checkin_date'] === $yesterday ? ((int) $fresh['checkin_streak'] + 1) : 1;
        $reward = null;
        $rewards = db_all('SELECT * FROM checkin_rewards ORDER BY streak_days ASC');
        foreach ($rewards as $item) {
            if ($streak >= (int) $item['streak_days']) {
                $reward = $item;
            }
        }
        if ($reward === null) {
            $reward = ['streak_days' => 1, 'exp' => 3, 'coins' => 1];
        }
        $newExp = (int) $fresh['exp'] + (int) $reward['exp'];
        $newCoins = (int) $fresh['coins'] + (int) $reward['coins'];
        $level = level_for_exp($newExp);
        $pdo->prepare('UPDATE users SET exp = ?, coins = ?, level = ?, checkin_streak = ?, last_checkin_date = ? WHERE id = ?')
            ->execute([$newExp, $newCoins, (int) $level['level'], $streak, $today, (int) $fresh['id']]);
        $pdo->prepare('INSERT INTO checkins (user_id, checkin_date, streak, exp, coins) VALUES (?, ?, ?, ?, ?)')
            ->execute([(int) $fresh['id'], $today, $streak, (int) $reward['exp'], (int) $reward['coins']]);
        refresh_current_user();
        return [true, '签到成功，经验 +' . (int) $reward['exp'] . '，金币 +' . (int) $reward['coins'] . '。', [
            'streak' => $streak,
            'exp' => (int) $reward['exp'],
            'coins' => (int) $reward['coins'],
            'level' => $level,
        ]];
    });
}
