package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.SearchResult
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.PostCard
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.formatCount
import com.bbs.lxlovo.top.ui.parseColor
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    api: ApiClient,
    initialQuery: String,
    onBack: () -> Unit,
    onPostClick: (Int) -> Unit,
    onUserClick: (Int) -> Unit,
    onBoardClick: (Int) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val focusRequester = remember { FocusRequester() }
    var query by remember { mutableStateOf(initialQuery) }
    var result by remember { mutableStateOf<SearchResult?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun search() {
        val text = query.trim()
        if (text.isBlank() || loading) return
        loading = true
        error = null
        scope.launch {
            try {
                result = api.search(text)
            } catch (exception: Exception) {
                error = exception.message ?: "搜索失败。"
            } finally {
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) {
        delay(150)
        focusRequester.requestFocus()
        if (initialQuery.isNotBlank()) search()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("搜索") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it.take(80) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).focusRequester(focusRequester),
                placeholder = { Text("搜索帖子、用户或板块") },
                singleLine = true,
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                trailingIcon = {
                    if (loading) {
                        CircularProgressIndicator(Modifier.padding(10.dp), strokeWidth = 2.dp)
                    } else {
                        IconButton(onClick = ::search) {
                            Icon(Icons.Outlined.Search, contentDescription = "搜索")
                        }
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { search() }),
            )

            when {
                error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    ErrorBox(error!!) { search() }
                }
                result == null -> EmptyBox("输入关键词开始搜索", Modifier.fillMaxSize())
                result!!.posts.isEmpty() && result!!.users.isEmpty() && result!!.boards.isEmpty() ->
                    EmptyBox("没有找到相关内容", Modifier.fillMaxSize())
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    val data = result!!
                    if (data.users.isNotEmpty()) {
                        item { SectionHeader("用户") }
                        items(data.users, key = { "user-${it.id}" }) { user ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                LxlovoAvatar(user, 42)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(user.username, style = MaterialTheme.typography.bodyLarge)
                                    Text(
                                        user.bio.ifBlank { "Lv.${user.level} ${user.levelName}" },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1,
                                    )
                                }
                                androidx.compose.material3.TextButton(onClick = { onUserClick(user.id) }) {
                                    Text("查看")
                                }
                            }
                        }
                    }
                    if (data.boards.isNotEmpty()) {
                        item { SectionHeader("板块") }
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(data.boards, key = { it.id }) { board ->
                                    FilterChip(
                                        selected = false,
                                        onClick = { onBoardClick(board.id) },
                                        label = { Text("${board.name} ${formatCount(board.postCount)}") },
                                    )
                                }
                            }
                        }
                    }
                    if (data.posts.isNotEmpty()) {
                        item { SectionHeader("帖子") }
                        items(data.posts, key = { "post-${it.id}" }) { post ->
                            PostCard(post, { onPostClick(post.id) }, onUserClick)
                        }
                    }
                }
            }
        }
    }
}
