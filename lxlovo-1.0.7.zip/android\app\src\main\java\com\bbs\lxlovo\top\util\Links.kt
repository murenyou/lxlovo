package com.bbs.lxlovo.top.util

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.bbs.lxlovo.top.UpdateBrowserActivity
import java.io.File

fun openUrl(context: Context, url: String, inAppBrowser: Boolean) {
    if (url.isBlank()) {
        Toast.makeText(context, "链接为空", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        if (inAppBrowser) {
            context.startActivity(
                Intent(context, UpdateBrowserActivity::class.java)
                    .putExtra(UpdateBrowserActivity.EXTRA_URL, url)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } else {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    } catch (error: ActivityNotFoundException) {
        Toast.makeText(context, "没有可用的浏览器", Toast.LENGTH_SHORT).show()
    }
}

fun installApk(context: Context, file: File): Boolean {
    if (!file.exists()) {
        Toast.makeText(context, "安装包不存在", Toast.LENGTH_SHORT).show()
        return false
    }
    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O &&
        !context.packageManager.canRequestPackageInstalls()
    ) {
        Toast.makeText(context, "请先允许 lxlovo 安装未知应用，然后再次点击安装", Toast.LENGTH_LONG).show()
        try {
            context.startActivity(
                Intent(
                    android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:${context.packageName}")
                ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (ignored: Exception) {
        }
        return false
    }
    return try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        context.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        true
    } catch (error: Exception) {
        Toast.makeText(context, "无法启动安装程序：${error.message}", Toast.LENGTH_LONG).show()
        false
    }
}
