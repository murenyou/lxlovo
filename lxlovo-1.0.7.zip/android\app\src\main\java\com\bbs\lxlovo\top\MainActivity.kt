package com.bbs.lxlovo.top

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.AppPrefs
import com.bbs.lxlovo.top.data.MeData
import com.bbs.lxlovo.top.data.UpdateInfo
import com.bbs.lxlovo.top.data.UpdateRepository
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.LxlovoTheme
import com.bbs.lxlovo.top.ui.UpdateFlowDialog
import com.bbs.lxlovo.top.ui.screens.AuthScreen
import com.bbs.lxlovo.top.ui.screens.AboutScreen
import com.bbs.lxlovo.top.ui.screens.AccountScreen
import com.bbs.lxlovo.top.ui.screens.BoardsScreen
import com.bbs.lxlovo.top.ui.screens.ComposePostScreen
import com.bbs.lxlovo.top.ui.screens.HomeScreen
import com.bbs.lxlovo.top.ui.screens.MessageThreadScreen
import com.bbs.lxlovo.top.ui.screens.MessagesScreen
import com.bbs.lxlovo.top.ui.screens.NotificationsScreen
import com.bbs.lxlovo.top.ui.screens.OnlineScreen
import com.bbs.lxlovo.top.ui.screens.PostCollectionScreen
import com.bbs.lxlovo.top.ui.screens.PostDetailScreen
import com.bbs.lxlovo.top.ui.screens.PostsScreen
import com.bbs.lxlovo.top.ui.screens.ProfileScreen
import com.bbs.lxlovo.top.ui.screens.SearchScreen
import com.bbs.lxlovo.top.ui.screens.SettingsScreen
import com.bbs.lxlovo.top.ui.screens.UpdateLogScreen
import com.bbs.lxlovo.top.ui.screens.UserProfileScreen
import com.bbs.lxlovo.top.ui.screens.VerifyScreen
import com.bbs.lxlovo.top.util.openUrl
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            LxlovoTheme {
                LxlovoApp()
            }
        }
    }
}

private enum class MainTab(
    val label: String,
    val icon: ImageVector,
) {
    Home("首页", Icons.Outlined.Home),
    Articles("文章", Icons.Outlined.Article),
    Profile("我的", Icons.Outlined.Person),
}

private sealed interface Route {
    data object Main : Route
    data object Auth : Route
    data object Notifications : Route
    data object Messages : Route
    data object Search : Route
    data object ComposePost : Route
    data object Settings : Route
    data object UpdateLog : Route
    data object Account : Route
    data object Verify : Route
    data object Online : Route
    data object About : Route
    data object Boards : Route
    data object Favorites : Route
    data object MyPosts : Route
    data class PostDetail(val id: Int) : Route
    data class EditPost(val id: Int) : Route
    data class UserProfile(val id: Int) : Route
    data class Thread(val userId: Int) : Route
    data class SearchQuery(val query: String) : Route
}

@Composable
private fun LxlovoApp() {
    val context = LocalContext.current
    val prefs = remember { AppPrefs(context) }
    val api = remember { ApiClient(context) }
    val updateRepository = remember { UpdateRepository() }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    var route by remember { mutableStateOf<Route>(Route.Main) }
    val backStack = remember { mutableStateListOf<Route>() }
    var tab by rememberSaveable { mutableStateOf(MainTab.Home.name) }
    var boardFilter by remember { mutableIntStateOf(0) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var currentUser by remember { mutableStateOf<User?>(null) }
    var me by remember { mutableStateOf<MeData?>(null) }
    var meLoading by remember { mutableStateOf(false) }
    var pendingRoute by remember { mutableStateOf<Route?>(null) }
    var pendingTab by remember { mutableStateOf<MainTab?>(null) }
    var checkingUpdate by remember { mutableStateOf(false) }
    var updateInfo by remember { mutableStateOf<UpdateInfo?>(null) }
    var showUpdate by remember { mutableStateOf(false) }

    fun navigate(target: Route) {
        if (target == route) return
        backStack.add(route)
        route = target
    }

    fun goBack() {
        route = if (backStack.isNotEmpty()) backStack.removeLast() else Route.Main
    }

    fun loadMe() {
        if (!prefs.isLoggedIn) {
            currentUser = null
            me = null
            return
        }
        meLoading = true
        scope.launch {
            try {
                val data = api.me()
                me = data
                currentUser = data.user
            } catch (exception: Exception) {
                if (exception is com.bbs.lxlovo.top.data.ApiException && exception.statusCode == 401) {
                    prefs.clearAuth()
                    currentUser = null
                    me = null
                }
            } finally {
                meLoading = false
            }
        }
    }

    fun requireLogin(target: Route? = null, targetTab: MainTab? = null) {
        if (currentUser != null) {
            if (target != null) navigate(target)
            if (targetTab != null) tab = targetTab.name
            return
        }
        pendingRoute = target ?: Route.Main
        pendingTab = targetTab
        navigate(Route.Auth)
    }

    fun checkForUpdate(manual: Boolean) {
        if (checkingUpdate) return
        scope.launch {
            checkingUpdate = true
            try {
                val info = updateRepository.check(BuildConfig.VERSION_CODE, BuildConfig.VERSION_NAME)
                prefs.applyBrowserDefault(info.inAppBrowserDefault)
                val latest = info.latest
                if (info.updateAvailable && latest != null) {
                    if (manual || info.forceUpdate || prefs.skippedVersionCode < latest.versionCode) {
                        updateInfo = info
                        showUpdate = true
                    } else if (manual) {
                        snackbar.showSnackbar("当前已是最新版本。")
                    }
                } else if (manual) {
                    snackbar.showSnackbar("当前已是最新版本。")
                }
            } catch (exception: Exception) {
                if (manual) snackbar.showSnackbar(exception.message ?: "检查更新失败。")
            } finally {
                checkingUpdate = false
            }
        }
    }

    fun completeAuth(user: User, message: String) {
        currentUser = user
        me = null
        val target = pendingRoute ?: Route.Main
        val targetTab = pendingTab
        backStack.clear()
        if (target != Route.Main) backStack.add(Route.Main)
        route = target
        targetTab?.let { tab = it.name }
        pendingRoute = null
        pendingTab = null
        loadMe()
        if (message.isNotBlank()) {
            scope.launch { snackbar.showSnackbar(message) }
        }
    }

    fun logout() {
        scope.launch {
            try {
                api.logout()
            } catch (_: Exception) {
            }
            currentUser = null
            me = null
            backStack.clear()
            route = Route.Main
            tab = MainTab.Home.name
            snackbar.showSnackbar("已退出登录")
        }
    }

    LaunchedEffect(Unit) {
        loadMe()
        delay(900)
        checkForUpdate(false)
    }

    BackHandler(enabled = route != Route.Main) {
        goBack()
    }

    Crossfade(
        targetState = route,
        animationSpec = tween(180),
        label = "route",
    ) { currentRoute ->
        when (currentRoute) {
        Route.Main -> MainShell(
            api = api,
            prefs = prefs,
            tab = MainTab.valueOf(tab),
            currentUser = currentUser,
            me = me,
            meLoading = meLoading,
            unread = me?.unreadNotifications ?: 0,
            reloadKey = reloadKey,
            boardFilter = boardFilter,
            snackbar = snackbar,
            onTab = {
                tab = it.name
                if (it == MainTab.Profile && currentUser == null && prefs.isLoggedIn) loadMe()
            },
            onRefresh = {
                reloadKey++
                if (tab == MainTab.Profile.name) loadMe()
            },
            onSearch = { navigate(Route.Search) },
            onNotifications = {
                if (currentUser == null) requireLogin(Route.Notifications) else navigate(Route.Notifications)
            },
            onSettings = { navigate(Route.Settings) },
            onCompose = { requireLogin(Route.ComposePost) },
            onPostClick = { navigate(Route.PostDetail(it)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
            onBoardClick = {
                boardFilter = it
                tab = MainTab.Articles.name
            },
            onAllBoards = { navigate(Route.Boards) },
            onViewAllPosts = { tab = MainTab.Articles.name },
            onLogin = { requireLogin(Route.Main, MainTab.Profile) },
            onOpenMessages = {
                if (currentUser == null) requireLogin(Route.Messages) else navigate(Route.Messages)
            },
            onRefreshMe = ::loadMe,
            onUserUpdated = { currentUser = it },
        )

        Route.Auth -> AuthScreen(
            api = api,
            onAuthenticated = ::completeAuth,
            onClose = { goBack() },
        )

        is Route.PostDetail -> PostDetailScreen(
            api = api,
            postId = currentRoute.id,
            currentUser = currentUser,
            onBack = ::goBack,
            onRequireLogin = { requireLogin(Route.PostDetail(currentRoute.id)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
            onPostClick = { navigate(Route.PostDetail(it)) },
            onEdit = { requireLogin(Route.EditPost(it)) },
            onDeleted = {
                backStack.clear()
                route = Route.Main
                reloadKey++
                loadMe()
            },
        )

        is Route.UserProfile -> UserProfileScreen(
            api = api,
            userId = currentRoute.id,
            currentUserId = currentUser?.id,
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onMessage = { userId ->
                if (currentUser == null) requireLogin(Route.Thread(userId)) else navigate(Route.Thread(userId))
            },
            onLogin = { requireLogin(Route.UserProfile(currentRoute.id)) },
        )

        Route.Notifications -> NotificationsScreen(
            api = api,
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onMessageClick = { userId ->
                if (currentUser == null) requireLogin(Route.Thread(userId)) else navigate(Route.Thread(userId))
            },
            onRead = ::loadMe,
        )

        Route.Messages -> MessagesScreen(
            api = api,
            onBack = ::goBack,
            onOpenThread = { navigate(Route.Thread(it)) },
        )

        is Route.Thread -> if (currentUser == null) {
            AuthScreen(
                api = api,
                onAuthenticated = ::completeAuth,
                onClose = { route = Route.Main },
            )
        } else {
            MessageThreadScreen(
                api = api,
                userId = currentRoute.userId,
                currentUserId = currentUser!!.id,
                onBack = ::goBack,
            )
        }

        Route.Search -> SearchScreen(
            api = api,
            initialQuery = "",
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
            onBoardClick = {
                boardFilter = it
                tab = MainTab.Articles.name
                route = Route.Main
            },
        )

        is Route.SearchQuery -> SearchScreen(
            api = api,
            initialQuery = currentRoute.query,
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
            onBoardClick = {
                boardFilter = it
                tab = MainTab.Articles.name
                route = Route.Main
            },
        )

        Route.ComposePost -> ComposePostScreen(
            api = api,
            onBack = ::goBack,
            onCreated = { id ->
                backStack.clear()
                backStack.add(Route.Main)
                route = Route.PostDetail(id)
                reloadKey++
                loadMe()
            },
        )

        Route.Settings -> SettingsScreen(
            prefs = prefs,
            user = currentUser,
            checking = checkingUpdate,
            snackbarHostState = snackbar,
            onBack = ::goBack,
            onLogin = { requireLogin(Route.Settings) },
            onLogout = ::logout,
            onAccount = { requireLogin(Route.Account) },
            onFavorites = { requireLogin(Route.Favorites) },
            onMyPosts = { requireLogin(Route.MyPosts) },
            onBoards = { navigate(Route.Boards) },
            onOnline = { navigate(Route.Online) },
            onAbout = { navigate(Route.About) },
            onCheckUpdate = { checkForUpdate(true) },
            onOpenLog = { navigate(Route.UpdateLog) },
        )

        Route.Account -> if (currentUser == null) {
            AuthScreen(
                api = api,
                onAuthenticated = ::completeAuth,
                onClose = { goBack() },
            )
        } else {
            AccountScreen(
                api = api,
                user = currentUser!!,
                onBack = ::goBack,
                onUserUpdated = { updated ->
                    currentUser = updated
                    loadMe()
                },
                onOpenVerify = { navigate(Route.Verify) },
            )
        }

        Route.Verify -> VerifyScreen(api = api, onBack = ::goBack)

        Route.Online -> OnlineScreen(
            api = api,
            onBack = ::goBack,
            onUserClick = { navigate(Route.UserProfile(it)) },
        )

        Route.About -> AboutScreen(
            api = api,
            onBack = ::goBack,
            onUserClick = { navigate(Route.UserProfile(it)) },
            onOpenUrl = { url -> openUrl(context, url, prefs.useInAppBrowser) },
        )

        Route.Boards -> BoardsScreen(
            api = api,
            currentUser = currentUser,
            onBack = ::goBack,
            onBoardClick = {
                boardFilter = it
                tab = MainTab.Articles.name
                route = Route.Main
            },
        )

        Route.Favorites -> PostCollectionScreen(
            api = api,
            title = "我的收藏",
            loader = { page -> api.favorites(page) },
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
        )

        Route.MyPosts -> PostCollectionScreen(
            api = api,
            title = "我的文章",
            loader = { page -> api.myPosts(page) },
            onBack = ::goBack,
            onPostClick = { navigate(Route.PostDetail(it)) },
            onUserClick = { navigate(Route.UserProfile(it)) },
        )

        is Route.EditPost -> ComposePostScreen(
            api = api,
            editingId = currentRoute.id,
            onBack = ::goBack,
            onCreated = { id ->
                backStack.clear()
                backStack.add(Route.Main)
                route = Route.PostDetail(id)
                reloadKey++
                loadMe()
            },
        )

        Route.UpdateLog -> UpdateLogScreen(
            repository = updateRepository,
            onBack = ::goBack,
        )
        }
    }

    if (showUpdate && updateInfo != null) {
        UpdateFlowDialog(
            info = updateInfo!!,
            onDismiss = { skip ->
                if (skip) updateInfo?.latest?.let { prefs.skippedVersionCode = it.versionCode }
                showUpdate = false
            },
            onOpenPage = { url -> openUrl(context, url, prefs.useInAppBrowser) },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainShell(
    api: ApiClient,
    prefs: AppPrefs,
    tab: MainTab,
    currentUser: User?,
    me: MeData?,
    meLoading: Boolean,
    unread: Int,
    reloadKey: Int,
    boardFilter: Int,
    snackbar: SnackbarHostState,
    onTab: (MainTab) -> Unit,
    onRefresh: () -> Unit,
    onSearch: () -> Unit,
    onNotifications: () -> Unit,
    onSettings: () -> Unit,
    onCompose: () -> Unit,
    onPostClick: (Int) -> Unit,
    onUserClick: (Int) -> Unit,
    onBoardClick: (Int) -> Unit,
    onAllBoards: () -> Unit,
    onViewAllPosts: () -> Unit,
    onLogin: () -> Unit,
    onOpenMessages: () -> Unit,
    onRefreshMe: () -> Unit,
    onUserUpdated: (User) -> Unit,
) {
    val context = LocalContext.current
    BackHandler {
        if (tab != MainTab.Home) onTab(MainTab.Home) else (context as? Activity)?.finish()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("lxlovo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Text(
                            tab.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onSearch) {
                        Icon(Icons.Outlined.Search, contentDescription = "搜索")
                    }
                    IconButton(onClick = onNotifications) {
                        BadgedBox(
                            badge = {
                                if (unread > 0) {
                                    Badge { Text(if (unread > 99) "99+" else unread.toString()) }
                                }
                            }
                        ) {
                            Icon(Icons.Outlined.Notifications, contentDescription = "通知")
                        }
                    }
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Outlined.Refresh, contentDescription = "刷新")
                    }
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Outlined.Settings, contentDescription = "设置")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
                MainTab.entries.forEach { item ->
                    NavigationBarItem(
                        selected = item == tab,
                        onClick = { onTab(item) },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.onSurface,
                        ),
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab != MainTab.Profile) {
                ExtendedFloatingActionButton(
                    onClick = onCompose,
                    icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                    text = { Text("发帖") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            Crossfade(
                targetState = tab,
                animationSpec = tween(160),
                label = "tab",
            ) { currentTab ->
                when (currentTab) {
                MainTab.Home -> HomeScreen(
                    api = api,
                    reloadKey = reloadKey,
                    onPostClick = onPostClick,
                    onUserClick = onUserClick,
                    onBoardClick = { onBoardClick(it.id) },
                    onAllBoards = onAllBoards,
                    onViewAllPosts = onViewAllPosts,
                    onOpenLink = { url ->
                        val resolved = if (url.startsWith("http://") || url.startsWith("https://")) {
                            url
                        } else {
                            BuildConfig.SITE_URL + url.trimStart('/')
                        }
                        openUrl(context, resolved, prefs.useInAppBrowser)
                    },
                )
                MainTab.Articles -> PostsScreen(
                    api = api,
                    reloadKey = reloadKey,
                    initialBoardId = boardFilter,
                    onBoardChanged = onBoardClick,
                    onPostClick = onPostClick,
                    onUserClick = onUserClick,
                )
                MainTab.Profile -> ProfileScreen(
                    api = api,
                    user = currentUser,
                    me = me,
                    loading = meLoading,
                    loggedIn = prefs.isLoggedIn,
                    onLogin = onLogin,
                    onOpenNotifications = onNotifications,
                    onOpenMessages = onOpenMessages,
                    onOpenSettings = onSettings,
                    onPostClick = onPostClick,
                    onUserUpdated = onUserUpdated,
                    onRefreshMe = onRefreshMe,
                )
                }
            }
        }
    }
}
