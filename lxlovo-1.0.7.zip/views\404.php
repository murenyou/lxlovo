<?php ?>
<section class="error-page">
    <span class="error-page__code">404</span>
    <h1>这里什么也没有</h1>
    <p>页面可能已被移动、删除，或者从未存在过。</p>
    <div class="error-page__actions">
        <a class="btn btn--primary" href="<?= e(url('home')) ?>">返回首页</a>
        <a class="btn btn--outlined" href="<?= e(url('posts')) ?>">浏览文章</a>
    </div>
</section>
