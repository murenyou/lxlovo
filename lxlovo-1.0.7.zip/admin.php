<?php

require __DIR__ . '/app/bootstrap.php';
require LXL_APP . '/site_pages.php';
require LXL_APP . '/admin_actions.php';
require LXL_APP . '/admin_pages.php';

$route = (string) ($_GET['r'] ?? 'dashboard');
if (!preg_match('/^[a-zA-Z0-9_.-]{1,60}$/', $route)) {
    $route = 'dashboard';
}

$adminUser = current_user();
if (!$adminUser) {
    flash('warning', '请先登录管理员账号。');
    redirect(url('login', ['next' => absolute_url(admin_url('dashboard'))]));
}
if (!is_admin($adminUser)) {
    http_response_code(403);
    flash('error', '你没有访问管理后台的权限。');
    redirect(url('home'));
}

if (is_post()) {
    verify_csrf();
    admin_action($route);
    exit;
}

admin_page($route);
