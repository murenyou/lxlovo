package com.bbs.lxlovo.top.util

import android.content.Context
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request

object ApkDownloader {
    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .callTimeout(10, TimeUnit.MINUTES)
        .build()

    suspend fun download(
        context: Context,
        url: String,
        onProgress: (downloaded: Long, total: Long) -> Unit,
    ): File = withContext(Dispatchers.IO) {
        if (url.isBlank()) {
            throw IOException("更新链接为空")
        }
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "lxlovo-android")
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IOException("下载失败（HTTP ${response.code}）")
            }
            val body = response.body ?: throw IOException("下载响应为空")
            val contentType = body.contentType()?.toString().orEmpty()
            if (contentType.contains("text/html", ignoreCase = true)) {
                throw IOException("更新链接返回的是网页，不是 APK 直链")
            }
            val total = body.contentLength()
            if (total > 300L * 1024 * 1024) {
                throw IOException("安装包体积异常")
            }
            val dir = File(context.cacheDir, "update").apply { mkdirs() }
            val file = File(dir, "lxlovo-update.apk")
            if (file.exists()) {
                file.delete()
            }
            var downloaded = 0L
            var lastReport = 0L
            body.byteStream().use { input ->
                file.outputStream().buffered().use { output ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        output.write(buffer, 0, read)
                        downloaded += read
                        val now = System.currentTimeMillis()
                        if (now - lastReport > 120 || (total > 0 && downloaded >= total)) {
                            lastReport = now
                            withContext(Dispatchers.Main) {
                                onProgress(downloaded, total)
                            }
                        }
                    }
                }
            }
            if (downloaded <= 0) {
                throw IOException("下载内容为空")
            }
            file
        }
    }
}
