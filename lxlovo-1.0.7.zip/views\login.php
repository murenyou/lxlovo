<?php
$next = (string) ($_GET['next'] ?? '');
?>
<section class="auth-shell">
    <div class="auth-art">
        <div class="auth-art__glow auth-art__glow--one"></div>
        <div class="auth-art__glow auth-art__glow--two"></div>
        <a class="brand brand--auth" href="<?= e(url('home')) ?>"><span class="brand__glyph">l</span><span class="brand__text"><?= e(setting('site_name')) ?></span></a>
        <div class="auth-art__copy">
            <span class="page-head__eyebrow">Welcome back</span>
            <h1>让每一次交流，<br>都值得被看见。</h1>
            <p>回来继续你未读完的文章，回应那些认真写下的话。</p>
        </div>
        <div class="auth-art__quote">
            <span>“</span>
            <p>好的社区不是喧闹，而是每个人都能被认真听见。</p>
        </div>
    </div>
    <div class="auth-card">
        <div class="auth-card__head">
            <span class="page-head__eyebrow">Sign in</span>
            <h2>登录 <?= e(setting('site_name')) ?></h2>
            <p>使用用户名或邮箱登录。</p>
        </div>
        <form action="<?= e(url('login')) ?>" method="post" class="form-stack">
            <?= csrf_field() ?>
            <input type="hidden" name="next" value="<?= e($next) ?>">
            <label class="field">
                <span class="field__label">用户名 / 邮箱</span>
                <span class="field__box"><?= icon('person') ?><input type="text" name="login" value="<?= e(old('login')) ?>" autocomplete="username" placeholder="输入用户名或邮箱" required autofocus></span>
            </label>
            <label class="field">
                <span class="field__label">密码</span>
                <span class="field__box"><?= icon('lock') ?><input type="password" name="password" autocomplete="current-password" placeholder="输入密码" required></span>
            </label>
            <div class="form-between">
                <span class="muted-text">登录即表示同意社区约定</span>
                <a class="text-link" href="<?= e(url('forgot_password')) ?>">忘记密码？</a>
            </div>
            <button class="btn btn--primary btn--full" type="submit">登录</button>
        </form>
        <?php if (setting_bool('register_enabled', true)): ?>
            <p class="auth-switch">还没有账号？<a href="<?= e(url('register')) ?>">创建一个</a></p>
        <?php endif; ?>
        <a class="auth-back" href="<?= e(url('home')) ?>"><?= icon('arrow_back', '', 16) ?>返回首页</a>
    </div>
</section>
