package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.VerifyApplication
import com.bbs.lxlovo.top.data.VerifyStatus
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.parseColor
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VerifyScreen(
    api: ApiClient,
    onBack: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<VerifyStatus?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var key by remember { mutableIntStateOf(0) }
    var type by remember { mutableStateOf("user") }
    var reason by remember { mutableStateOf("") }
    var proof by remember { mutableStateOf("") }
    var submitting by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(key) {
        loading = data == null
        error = null
        try {
            data = api.verifyStatus()
        } catch (exception: Exception) {
            error = exception.message ?: "认证信息加载失败。"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("认证中心") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
    ) { padding ->
        when {
            loading && data == null -> LoadingBox(Modifier.padding(padding))
            error != null && data == null -> Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                ErrorBox(error!!) { key++ }
            }
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                item {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.Verified, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("lxlovo 认证", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "认证标识会展示在用户名旁。官方认证由管理员授予；用户认证与赞助认证可以在此提交申请。",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                data?.certifications?.forEach { badge ->
                                    Surface(
                                        shape = RoundedCornerShape(50),
                                        color = parseColor(badge.color).copy(alpha = 0.16f),
                                    ) {
                                        Text(
                                            badge.name,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                            style = MaterialTheme.typography.labelMedium,
                                            color = parseColor(badge.color),
                                        )
                                    }
                                }
                                if (data?.certifications.isNullOrEmpty()) {
                                    Text("暂未获得认证", color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
                                }
                            }
                        }
                    }
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                        shape = RoundedCornerShape(22.dp),
                    ) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text("提交认证申请", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(
                                    selected = type == "user",
                                    onClick = { type = "user" },
                                    label = { Text("用户认证") },
                                )
                                FilterChip(
                                    selected = type == "sponsor",
                                    onClick = { type = "sponsor" },
                                    label = { Text("赞助认证") },
                                )
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = reason,
                                onValueChange = { reason = it.take(1000) },
                                label = { Text("申请理由") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3,
                                maxLines = 6,
                            )
                            Spacer(Modifier.height(8.dp))
                            OutlinedTextField(
                                value = proof,
                                onValueChange = { proof = it.take(500) },
                                label = { Text("补充信息（可选）") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                            )
                            if (message != null) {
                                Spacer(Modifier.height(8.dp))
                                Text(message!!, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    if (!submitting) {
                                        submitting = true
                                        message = null
                                        scope.launch {
                                            try {
                                                message = api.verifyApply(type, reason.trim(), proof.trim())
                                                reason = ""
                                                proof = ""
                                                key++
                                            } catch (exception: Exception) {
                                                message = exception.message ?: "提交失败。"
                                            } finally {
                                                submitting = false
                                            }
                                        }
                                    }
                                },
                                enabled = !submitting,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                if (submitting) {
                                    CircularProgressIndicator(
                                        Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary,
                                    )
                                    Spacer(Modifier.width(6.dp))
                                }
                                Text(if (submitting) "提交中" else "提交申请")
                            }
                        }
                    }
                }

                if (!data?.applications.isNullOrEmpty()) {
                    item { Text("申请记录", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                    items(data!!.applications, key = { it.id }) { application ->
                        ApplicationRow(application)
                    }
                }
            }
        }
    }
}

@Composable
private fun ApplicationRow(application: VerifyApplication) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (application.type == "sponsor") "赞助认证" else "用户认证",
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f),
                )
                Surface(
                    shape = RoundedCornerShape(50),
                    color = when (application.status) {
                        "approved" -> MaterialTheme.colorScheme.primaryContainer
                        "rejected" -> MaterialTheme.colorScheme.errorContainer
                        else -> MaterialTheme.colorScheme.secondaryContainer
                    },
                ) {
                    Text(
                        when (application.status) {
                            "approved" -> "已通过"
                            "rejected" -> "未通过"
                            else -> "审核中"
                        },
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall,
                    )
                }
            }
            Spacer(Modifier.height(5.dp))
            Text(application.reason, style = MaterialTheme.typography.bodySmall)
        }
    }
}
