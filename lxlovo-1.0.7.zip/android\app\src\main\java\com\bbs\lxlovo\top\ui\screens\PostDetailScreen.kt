package com.bbs.lxlovo.top.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.MonetizationOn
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Send
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Star
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.ColorPainter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.bbs.lxlovo.top.BuildConfig
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Comment
import com.bbs.lxlovo.top.data.Post
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.BoardPill
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.HtmlContent
import com.bbs.lxlovo.top.ui.LevelChip
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.ui.SectionHeader
import com.bbs.lxlovo.top.ui.UserBadges
import com.bbs.lxlovo.top.ui.formatCount
import com.bbs.lxlovo.top.ui.formatTime
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostDetailScreen(
    api: ApiClient,
    postId: Int,
    currentUser: User?,
    onBack: () -> Unit,
    onRequireLogin: () -> Unit,
    onUserClick: (Int) -> Unit,
    onPostClick: (Int) -> Unit,
    onEdit: (Int) -> Unit,
    onDeleted: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val listState = rememberLazyListState()
    var post by remember { mutableStateOf<Post?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var retryKey by remember { mutableStateOf(0) }
    var replyTo by remember { mutableStateOf<Comment?>(null) }
    var commentText by remember { mutableStateOf("") }
    var sending by remember { mutableStateOf(false) }
    var rewardOpen by remember { mutableStateOf(false) }
    var rewardBusy by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }
    var deleteConfirm by remember { mutableStateOf(false) }
    var actionBusy by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    suspend fun refresh() {
        post = api.post(postId)
    }

    LaunchedEffect(postId, retryKey) {
        loading = true
        error = null
        try {
            post = api.post(postId)
        } catch (exception: Exception) {
            error = exception.message ?: "帖子加载失败。"
        } finally {
            loading = false
        }
    }

    LaunchedEffect(replyTo) {
        if (replyTo != null) {
            kotlinx.coroutines.delay(120)
            focusRequester.requestFocus()
        }
    }

    fun toggleLike() {
        val item = post ?: return
        if (currentUser == null) {
            onRequireLogin()
            return
        }
        scope.launch {
            try {
                val result = api.likePost(item.id)
                post = item.copy(liked = result.active, likes = result.count)
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "操作失败")
            }
        }
    }

    fun toggleFavorite() {
        val item = post ?: return
        if (currentUser == null) {
            onRequireLogin()
            return
        }
        scope.launch {
            try {
                val result = api.favoritePost(item.id)
                post = item.copy(favorited = result.active, favorites = result.count)
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "操作失败")
            }
        }
    }

    fun sendComment() {
        val item = post ?: return
        val content = commentText.trim()
        if (content.isEmpty() || sending) return
        if (currentUser == null) {
            onRequireLogin()
            return
        }
        sending = true
        scope.launch {
            try {
                api.createComment(item.id, content, replyTo?.id)
                commentText = ""
                replyTo = null
                refresh()
                snackbar.showSnackbar("评论已发布")
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "评论失败")
            } finally {
                sending = false
            }
        }
    }

    fun deletePost() {
        val item = post ?: return
        actionBusy = true
        scope.launch {
            try {
                api.deletePost(item.id)
                deleteConfirm = false
                onDeleted()
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "删除失败")
            } finally {
                actionBusy = false
            }
        }
    }

    fun toggleFeature() {
        val item = post ?: return
        actionBusy = true
        scope.launch {
            try {
                val featured = api.featurePost(item.id)
                post = item.copy(isFeatured = featured)
                snackbar.showSnackbar(if (featured) "已设为精华" else "已取消精华")
            } catch (exception: Exception) {
                snackbar.showSnackbar(exception.message ?: "操作失败")
            } finally {
                actionBusy = false
            }
        }
    }

    Scaffold(
        modifier = modifier,
        topBar = {
            TopAppBar(
                title = { Text("帖子详情") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
                actions = {
                    post?.let { item ->
                        IconButton(onClick = {
                            val share = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "${item.title}\n${BuildConfig.SITE_URL}index.php?r=post&id=${item.id}"
                                )
                            }
                            context.startActivity(Intent.createChooser(share, "分享帖子"))
                        }) {
                            Icon(Icons.Outlined.Share, contentDescription = "分享")
                        }
                        if (item.canEdit || item.canFeature) {
                            Box {
                                IconButton(onClick = { menuOpen = true }, enabled = !actionBusy) {
                                    Icon(Icons.Outlined.MoreVert, contentDescription = "更多")
                                }
                                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                    if (item.canEdit) {
                                        DropdownMenuItem(
                                            text = { Text("编辑帖子") },
                                            leadingIcon = { Icon(Icons.Outlined.Edit, contentDescription = null) },
                                            onClick = { menuOpen = false; onEdit(item.id) },
                                        )
                                    }
                                    if (item.canFeature) {
                                        DropdownMenuItem(
                                            text = { Text(if (item.isFeatured) "取消精华" else "设为精华") },
                                            leadingIcon = { Icon(Icons.Outlined.Star, contentDescription = null) },
                                            onClick = { menuOpen = false; toggleFeature() },
                                        )
                                    }
                                    if (item.canEdit) {
                                        DropdownMenuItem(
                                            text = { Text("删除帖子") },
                                            leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
                                            onClick = { menuOpen = false; deleteConfirm = true },
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = {
            if (post != null) {
                CommentComposer(
                    value = commentText,
                    replyTo = replyTo,
                    sending = sending,
                    focusRequester = focusRequester,
                    loggedIn = currentUser != null,
                    onValueChange = { commentText = it.take(1000) },
                    onCancelReply = { replyTo = null },
                    onLogin = onRequireLogin,
                    onSend = ::sendComment,
                )
            }
        },
    ) { padding ->
        when {
            loading && post == null -> LoadingBox(Modifier.padding(padding))
            error != null && post == null -> Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                ErrorBox(error!!) { retryKey++ }
            }
            post == null -> EmptyBox("帖子不存在", Modifier.padding(padding))
            else -> {
                val item = post!!
                LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item { PostHeader(item, onUserClick) }
                    if (item.coverUrl.isNotBlank()) {
                        item {
                            AsyncImage(
                                model = item.coverUrl,
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth().height(220.dp),
                                contentScale = ContentScale.Crop,
                                placeholder = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                                error = ColorPainter(MaterialTheme.colorScheme.surfaceVariant),
                            )
                        }
                    }
                    item {
                        HtmlContent(item.contentHtml.ifBlank { "<p>${item.excerpt}</p>" })
                    }
                    item {
                        PostActions(
                            post = item,
                            onLike = ::toggleLike,
                            onFavorite = ::toggleFavorite,
                            onReward = {
                                if (currentUser == null) onRequireLogin() else rewardOpen = true
                            },
                            onComment = {
                                scope.launch {
                                    listState.animateScrollToItem((listState.layoutInfo.totalItemsCount - 1).coerceAtLeast(0))
                                }
                            },
                        )
                    }
                    item {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    }
                    item {
                        SectionHeader("评论 ${item.commentCount}")
                    }
                    if (item.commentList.isEmpty()) {
                        item { EmptyBox("还没有评论，来抢沙发吧。") }
                    } else {
                        items(item.commentList, key = { it.id }) { comment ->
                            CommentThread(
                                comment = comment,
                                currentUserId = currentUser?.id,
                                canModerate = item.canModerate,
                                onUserClick = onUserClick,
                                onReply = { target ->
                                    if (currentUser == null) onRequireLogin() else replyTo = target
                                },
                                onLike = { target ->
                                    if (currentUser == null) {
                                        onRequireLogin()
                                    } else {
                                        scope.launch {
                                            try {
                                                val result = api.likeComment(target.id)
                                                post = post?.let { current ->
                                                    current.copy(
                                                        commentList = updateComment(
                                                            current.commentList, target.id, result.active, result.count
                                                        )
                                                    )
                                                }
                                            } catch (exception: Exception) {
                                                snackbar.showSnackbar(exception.message ?: "操作失败")
                                            }
                                        }
                                    }
                                },
                                onPin = { target ->
                                    if (currentUser == null) {
                                        onRequireLogin()
                                    } else {
                                        scope.launch {
                                            try {
                                                val pinned = api.pinComment(target.id)
                                                refresh()
                                                snackbar.showSnackbar(if (pinned) "评论已置顶" else "已取消置顶")
                                            } catch (exception: Exception) {
                                                snackbar.showSnackbar(exception.message ?: "操作失败")
                                            }
                                        }
                                    }
                                },
                                onDelete = { target ->
                                    if (currentUser == null) {
                                        onRequireLogin()
                                    } else {
                                        scope.launch {
                                            try {
                                                api.deleteComment(target.id)
                                                refresh()
                                                snackbar.showSnackbar("评论已删除")
                                            } catch (exception: Exception) {
                                                snackbar.showSnackbar(exception.message ?: "操作失败")
                                            }
                                        }
                                    }
                                },
                            )
                        }
                    }
                    if (item.related.isNotEmpty()) {
                        item { SectionHeader("相关文章") }
                        items(item.related, key = { "related-${it.id}" }) { related ->
                            com.bbs.lxlovo.top.ui.PostCard(
                                related,
                                { onPostClick(related.id) },
                                onUserClick,
                            )
                        }
                    }
                }
            }
        }
    }

    if (rewardOpen && post != null) {
        RewardDialog(
            busy = rewardBusy,
            onDismiss = { if (!rewardBusy) rewardOpen = false },
            onReward = { amount ->
                rewardBusy = true
                scope.launch {
                    try {
                        val result = api.rewardPost(post!!.id, amount)
                        post = post?.copy(rewardTotal = result.rewardTotal)
                        rewardOpen = false
                        snackbar.showSnackbar("打赏成功，消耗 ${amount} 金币")
                    } catch (exception: Exception) {
                        snackbar.showSnackbar(exception.message ?: "打赏失败")
                    } finally {
                        rewardBusy = false
                    }
                }
            },
        )
    }

    if (deleteConfirm) {
        AlertDialog(
            onDismissRequest = { if (!actionBusy) deleteConfirm = false },
            title = { Text("删除帖子") },
            text = { Text("帖子会移入回收站，确定继续吗？") },
            confirmButton = {
                Button(onClick = ::deletePost, enabled = !actionBusy) {
                    if (actionBusy) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    } else {
                        Text("删除")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirm = false }, enabled = !actionBusy) { Text("取消") }
            },
        )
    }
}

@Composable
private fun PostHeader(post: Post, onUserClick: (Int) -> Unit) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            BoardPill(post.boardName, post.boardColor)
            if (post.isPinned) {
                Spacer(Modifier.width(6.dp))
                Text("置顶", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
            }
            if (post.isFeatured) {
                Spacer(Modifier.width(6.dp))
                Text("精华", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.tertiary)
            }
            if (post.isOfficial) {
                Spacer(Modifier.width(6.dp))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primary,
                ) {
                    Text(
                        "官方",
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimary,
                    )
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            post.title,
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.ExtraBold,
        )
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            LxlovoAvatar(post.author, 42)
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        post.author.username,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onUserClick(post.author.id) },
                    )
                    Spacer(Modifier.width(6.dp))
                    LevelChip(post.author)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    UserBadges(post.author, 2)
                    Spacer(Modifier.width(6.dp))
                    Text(
                        formatTime(post.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Meta(Icons.Outlined.Visibility, formatCount(post.views))
            Meta(Icons.Outlined.FavoriteBorder, formatCount(post.likes))
            Meta(Icons.Outlined.ChatBubbleOutline, formatCount(post.commentCount))
            if (post.rewardTotal > 0) {
                Meta(Icons.Outlined.MonetizationOn, "${post.rewardTotal} 金币")
            }
        }
    }
}

@Composable
private fun Meta(icon: androidx.compose.ui.graphics.vector.ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp), tint = MaterialTheme.colorScheme.outline)
        Spacer(Modifier.width(3.dp))
        Text(text, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PostActions(
    post: Post,
    onLike: () -> Unit,
    onFavorite: () -> Unit,
    onReward: () -> Unit,
    onComment: () -> Unit,
) {
    val likeScale by animateFloatAsState(
        targetValue = if (post.liked) 1.18f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "likeScale",
    )
    val favoriteScale by animateFloatAsState(
        targetValue = if (post.favorited) 1.12f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "favoriteScale",
    )
    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        FilledTonalButton(onClick = onLike) {
            Icon(
                if (post.liked) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                contentDescription = null,
                modifier = Modifier.size(18.dp).scale(likeScale),
                tint = if (post.liked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Spacer(Modifier.width(5.dp))
            Text(if (post.liked) "已赞 ${post.likes}" else "点赞 ${post.likes}")
        }
        FilledTonalButton(onClick = onFavorite) {
            Icon(
                Icons.Outlined.FavoriteBorder,
                contentDescription = null,
                modifier = Modifier.size(18.dp).scale(favoriteScale),
                tint = if (post.favorited) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Spacer(Modifier.width(5.dp))
            Text(if (post.favorited) "已收藏" else "收藏")
        }
        FilledTonalButton(onClick = onReward) {
            Icon(Icons.Outlined.MonetizationOn, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(5.dp))
            Text("打赏")
        }
        FilledTonalButton(onClick = onComment) {
            Icon(Icons.Outlined.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(5.dp))
            Text("评论")
        }
    }
}

@Composable
private fun CommentThread(
    comment: Comment,
    currentUserId: Int?,
    canModerate: Boolean,
    onUserClick: (Int) -> Unit,
    onReply: (Comment) -> Unit,
    onLike: (Comment) -> Unit,
    onPin: (Comment) -> Unit,
    onDelete: (Comment) -> Unit,
) {
    Column {
        CommentRow(comment, currentUserId, canModerate, onUserClick, onReply, onLike, onPin, onDelete)
        comment.replies.forEach { reply ->
            Row {
                Spacer(Modifier.width(26.dp))
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(20.dp)
                        .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                )
                Spacer(Modifier.width(10.dp))
                CommentRow(reply, currentUserId, canModerate, onUserClick, onReply, onLike, onPin, onDelete)
            }
        }
    }
}

@Composable
private fun CommentRow(
    comment: Comment,
    currentUserId: Int?,
    canModerate: Boolean,
    onUserClick: (Int) -> Unit,
    onReply: (Comment) -> Unit,
    onLike: (Comment) -> Unit,
    onPin: (Comment) -> Unit,
    onDelete: (Comment) -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val canDelete = canModerate || (currentUserId != null && currentUserId == comment.user.id)
    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Row {
            LxlovoAvatar(comment.user, 34)
            Spacer(Modifier.width(9.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        comment.user.username,
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onUserClick(comment.user.id) },
                    )
                    Spacer(Modifier.width(5.dp))
                    LevelChip(comment.user)
                    if (comment.isPinned) {
                        Spacer(Modifier.width(5.dp))
                        Text("置顶", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.weight(1f))
                    if (canModerate || canDelete) {
                        Box {
                            IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(26.dp)) {
                                Icon(
                                    Icons.Outlined.MoreVert,
                                    contentDescription = "评论操作",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.outline,
                                )
                            }
                            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                                if (canModerate) {
                                    DropdownMenuItem(
                                        text = { Text(if (comment.isPinned) "取消置顶" else "置顶评论") },
                                        leadingIcon = { Icon(Icons.Outlined.PushPin, contentDescription = null) },
                                        onClick = { menuOpen = false; onPin(comment) },
                                    )
                                }
                                if (canDelete) {
                                    DropdownMenuItem(
                                        text = { Text("删除评论") },
                                        leadingIcon = { Icon(Icons.Outlined.Delete, contentDescription = null) },
                                        onClick = { menuOpen = false; onDelete(comment) },
                                    )
                                }
                            }
                        }
                    }
                }
                if (comment.replyToUsername != null) {
                    Text(
                        "回复 @${comment.replyToUsername}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(comment.content, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(5.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        formatTime(comment.createdAt),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "回复",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { onReply(comment) },
                    )
                    Spacer(Modifier.width(12.dp))
                    Row(
                        modifier = Modifier.clickable { onLike(comment) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            if (comment.liked) Icons.Outlined.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp),
                            tint = if (comment.liked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline,
                        )
                        Spacer(Modifier.width(3.dp))
                        Text(
                            comment.likes.toString(),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CommentComposer(
    value: String,
    replyTo: Comment?,
    sending: Boolean,
    focusRequester: FocusRequester,
    loggedIn: Boolean,
    onValueChange: (String) -> Unit,
    onCancelReply: () -> Unit,
    onLogin: () -> Unit,
    onSend: () -> Unit,
) {
    Surface(tonalElevation = 3.dp, color = MaterialTheme.colorScheme.surface) {
        Column(modifier = Modifier.navigationBarsPadding().imePadding().padding(horizontal = 14.dp, vertical = 8.dp)) {
            AnimatedVisibility(
                visible = replyTo != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically(),
            ) {
                replyTo?.let { target ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "回复 @${target.user.username}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = onCancelReply, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Outlined.Close, contentDescription = "取消回复", modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    modifier = Modifier.weight(1f).focusRequester(focusRequester),
                    placeholder = { Text(if (loggedIn) "写下你的评论…" else "登录后参与评论") },
                    enabled = loggedIn && !sending,
                    maxLines = 4,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onSend() }),
                )
                Spacer(Modifier.width(6.dp))
                if (loggedIn) {
                    IconButton(
                        onClick = onSend,
                        enabled = value.isNotBlank() && !sending,
                    ) {
                        if (sending) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Outlined.Send, contentDescription = "发送")
                        }
                    }
                } else {
                    TextButton(onClick = onLogin) { Text("登录") }
                }
            }
        }
    }
}

private fun updateComment(
    comments: List<Comment>,
    id: Int,
    liked: Boolean,
    count: Int,
): List<Comment> = comments.map { comment ->
    if (comment.id == id) {
        comment.copy(liked = liked, likes = count)
    } else if (comment.replies.isNotEmpty()) {
        comment.copy(replies = updateComment(comment.replies, id, liked, count))
    } else {
        comment
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RewardDialog(
    busy: Boolean,
    onDismiss: () -> Unit,
    onReward: (Int) -> Unit,
) {
    var amount by remember { mutableStateOf(5) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("打赏作者") },
        text = {
            Column {
                Text("选择金币数量，打赏会直接转入作者账户。", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf(1, 5, 10, 20, 50).forEach { value ->
                        FilledTonalButton(
                            onClick = { amount = value },
                            enabled = !busy,
                        ) {
                            Text(if (amount == value) "✓ $value" else "$value")
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = { onReward(amount) }, enabled = !busy) {
                if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp) else Text("打赏 $amount 金币")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !busy) { Text("取消") }
        },
    )
}
