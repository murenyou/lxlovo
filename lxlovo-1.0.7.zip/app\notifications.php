<?php

/* ---------------------------------------------------------------------------
 * 站内通知、@ 提醒与系统广播
 * ------------------------------------------------------------------------- */

function notification_pref_key(string $type): ?string
{
    return match ($type) {
        'comment', 'reply' => 'notify_comment',
        'mention' => 'notify_mention',
        'message' => 'notify_message',
        'system' => 'notify_system',
        'reward' => 'notify_comment',
        default => null,
    };
}

function notify_user(int $userId, ?int $actorId, string $type, string $message, string $link = '', ?string $emailTitle = null): void
{
    if ($userId <= 0 || ($actorId !== null && $userId === $actorId)) {
        return;
    }
    $user = db_one('SELECT id, email, status, notify_comment, notify_mention, notify_message, notify_system, notify_email FROM users WHERE id = ?', [$userId]);
    if (!$user || $user['status'] !== 'active') {
        return;
    }
    $prefKey = notification_pref_key($type);
    if ($prefKey !== null && (int) ($user[$prefKey] ?? 1) !== 1) {
        return;
    }
    $id = db_insert(
        'INSERT INTO notifications (user_id, actor_id, type, message, link) VALUES (?, ?, ?, ?, ?)',
        [$userId, $actorId, $type, mb_substr($message, 0, 500), mb_substr($link, 0, 500)]
    );
    if ($emailTitle !== null && setting_bool('email_notify_enabled', true) && email_configured() && (int) ($user['notify_email'] ?? 1) === 1) {
        $ok = send_notification_email($user, $emailTitle, $message, $link !== '' ? absolute_url($link) : '');
        if ($ok) {
            db_exec('UPDATE notifications SET email_sent = 1 WHERE id = ?', [$id]);
        }
    }
}

function notify_mentions(string $text, array $actor, string $postTitle, string $link, string $where = '帖子'): void
{
    $names = extract_mentions($text);
    if ($names === []) {
        return;
    }
    $users = resolve_mention_users($names);
    foreach ($users as $user) {
        if (!$user || (int) $user['id'] === (int) $actor['id'] || $user['status'] !== 'active') {
            continue;
        }
        notify_user(
            (int) $user['id'],
            (int) $actor['id'],
            'mention',
            $actor['username'] . ' 在' . $where . '《' . $postTitle . '》中提到了你',
            $link,
            '有人提到了你'
        );
    }
}

function notify_new_comment(array $post, array $comment, array $actor): void
{
    $link = url('post', ['id' => (int) $post['id']]) . '#comment-' . (int) $comment['id'];
    $title = mb_substr((string) $post['title'], 0, 50);
    if ((int) $post['user_id'] !== (int) $actor['id']) {
        notify_user(
            (int) $post['user_id'],
            (int) $actor['id'],
            'comment',
            $actor['username'] . ' 评论了你的帖子《' . $title . '》',
            $link,
            '你的帖子收到新评论'
        );
    }
    if (!empty($comment['reply_to_user_id']) && (int) $comment['reply_to_user_id'] !== (int) $actor['id']) {
        notify_user(
            (int) $comment['reply_to_user_id'],
            (int) $actor['id'],
            'reply',
            $actor['username'] . ' 回复了你的评论',
            $link,
            '你的评论收到新回复'
        );
    }
    notify_mentions((string) $comment['content'], $actor, $title, $link, '评论');
}

function notify_new_message(array $sender, int $receiverId, string $content): void
{
    if ($receiverId === (int) $sender['id']) {
        return;
    }
    notify_user(
        $receiverId,
        (int) $sender['id'],
        'message',
        $sender['username'] . ' 给你发来一条私信：' . text_excerpt($content, 40),
        url('messages', ['with' => (int) $sender['id']]),
        '你收到一条新私信'
    );
}

function notify_verification_result(array $user, bool $approved, string $type, string $note = ''): void
{
    $label = $type === 'sponsor' ? '赞助认证' : '用户认证';
    $message = $approved
        ? '你的' . $label . '申请已通过，认证已经添加到账号。'
        : '你的' . $label . '申请未通过。' . ($note !== '' ? '原因：' . $note : '');
    notify_user(
        (int) $user['id'],
        null,
        'system',
        $message,
        url('verify'),
        $approved ? $label . '申请通过' : $label . '申请结果'
    );
}

function broadcast_notification(string $message, bool $sendEmail = false, string $emailTitle = '系统通知'): int
{
    $users = db_all("SELECT id, email, notify_system, notify_email FROM users WHERE status = 'active'");
    $count = 0;
    foreach ($users as $user) {
        if ((int) ($user['notify_system'] ?? 1) !== 1) {
            continue;
        }
        $id = db_insert(
            'INSERT INTO notifications (user_id, actor_id, type, message, link) VALUES (?, NULL, "system", ?, ?)',
            [(int) $user['id'], mb_substr($message, 0, 500), url('notifications')]
        );
        $count++;
        if ($sendEmail && setting_bool('email_notify_enabled', true) && email_configured() && (int) ($user['notify_email'] ?? 1) === 1) {
            $ok = send_notification_email($user, $emailTitle, $message, absolute_url(url('notifications')));
            if ($ok) {
                db_exec('UPDATE notifications SET email_sent = 1 WHERE id = ?', [$id]);
            }
        }
    }
    return $count;
}

function mark_all_notifications_read(int $userId): void
{
    db_exec('UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0', [$userId]);
}

function notification_icon(string $type): string
{
    return match ($type) {
        'comment', 'reply' => 'comment',
        'mention' => 'message',
        'message' => 'mail',
        'reward' => 'coin',
        'system' => 'mega',
        default => 'notifications',
    };
}
