<?php
$commentUser = current_user();
$commentAuthor = [
    'id' => (int) $comment['user_id'],
    'username' => $comment['username'] ?? '',
    'avatar' => $comment['avatar'] ?? '',
    'show_official_badge' => $comment['show_official_badge'] ?? 1,
    'exp' => $comment['exp'] ?? 0,
];
$commentLevel = level_for_exp((int) ($comment['exp'] ?? 0));
$depth = $depth ?? 0;
$canDelete = $commentUser && (
    is_admin($commentUser)
    || (int) $comment['user_id'] === (int) $commentUser['id']
    || (int) $post['user_id'] === (int) $commentUser['id']
    || $canPin
);
$replyAction = $depth === 0 || !empty($comment['replies']);
?>
<article class="comment<?= (int) $comment['is_pinned'] === 1 ? ' comment--pinned' : '' ?>" id="comment-<?= (int) $comment['id'] ?>" data-comment-id="<?= (int) $comment['id'] ?>">
    <img class="avatar avatar--sm" src="<?= e(avatar_url($commentAuthor)) ?>" alt="">
    <div class="comment__main">
        <div class="comment__head">
            <a class="comment__author" href="<?= e(url('user', ['id' => (int) $comment['user_id']])) ?>"><?= e($comment['username'] ?? '') ?></a>
            <?= badge_html((int) $comment['user_id'], $commentAuthor) ?>
            <span class="level-dot" style="--level-color:<?= e($commentLevel['color']) ?>">Lv.<?= (int) $commentLevel['level'] ?></span>
            <?php if ((int) $comment['is_pinned'] === 1): ?><span class="chip chip--pin"><?= icon('pin', '', 12) ?>置顶</span><?php endif; ?>
            <time datetime="<?= e($comment['created_at']) ?>"><?= e(time_ago($comment['created_at'])) ?></time>
        </div>
        <div class="comment__content">
            <?php if (!empty($comment['reply_to_username']) && (int) ($comment['reply_to_user_id'] ?? 0) !== (int) $comment['user_id']): ?>
                <span class="comment__reply-to">回复 @<?= e($comment['reply_to_username']) ?>：</span>
            <?php endif; ?>
            <?= format_comment((string) $comment['content']) ?>
        </div>
        <div class="comment__actions">
            <button class="text-btn js-comment-like<?= !empty($comment['liked']) ? ' is-active' : '' ?>" type="button" data-comment-id="<?= (int) $comment['id'] ?>" data-count="<?= (int) $comment['likes_count'] ?>">
                <?= icon('thumb_up', '', 16) ?><span class="js-like-count"><?= (int) $comment['likes_count'] ?></span>
            </button>
            <?php if ($commentUser): ?>
                <button class="text-btn" type="button" data-reply-toggle="<?= (int) $comment['id'] ?>"><?= icon('message', '', 16) ?>回复</button>
            <?php endif; ?>
            <?php if ($canPin && $depth === 0): ?>
                <form action="<?= e(url('comment.pin')) ?>" method="post" class="inline-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="comment_id" value="<?= (int) $comment['id'] ?>">
                    <button class="text-btn" type="submit"><?= icon('pin', '', 16) ?><?= (int) $comment['is_pinned'] === 1 ? '取消置顶' : '置顶' ?></button>
                </form>
            <?php endif; ?>
            <?php if ($canDelete): ?>
                <form action="<?= e(url('comment.delete')) ?>" method="post" class="inline-form" data-confirm="确定删除这条评论吗？">
                    <?= csrf_field() ?>
                    <input type="hidden" name="comment_id" value="<?= (int) $comment['id'] ?>">
                    <button class="text-btn text-btn--danger" type="submit"><?= icon('trash', '', 16) ?>删除</button>
                </form>
            <?php endif; ?>
        </div>
        <?php if ($commentUser): ?>
            <form class="comment-form comment-form--reply" action="<?= e(url('comment.create')) ?>" method="post" data-reply-form="<?= (int) $comment['id'] ?>" hidden>
                <?= csrf_field() ?>
                <input type="hidden" name="post_id" value="<?= (int) $post['id'] ?>">
                <input type="hidden" name="parent_id" value="<?= (int) $comment['id'] ?>">
                <textarea name="content" rows="3" maxlength="1000" placeholder="回复 @<?= e($comment['username'] ?? '') ?>…" required></textarea>
                <div class="comment-form__foot">
                    <span>友善交流，尊重彼此。</span>
                    <button class="btn btn--primary btn--sm" type="submit">发送回复</button>
                </div>
            </form>
        <?php endif; ?>
        <?php if (!empty($comment['replies'])): ?>
            <div class="comment__replies">
                <?php foreach ($comment['replies'] as $reply): ?>
                    <?php $comment = $reply; $depth = 1; require LXL_VIEWS . '/partials/comment.php'; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</article>
