<?php

/* ---------------------------------------------------------------------------
 * 后台页面
 * ------------------------------------------------------------------------- */

function admin_page(string $route): void
{
    switch ($route) {
        case 'dashboard':
            admin_page_dashboard();
            break;
        case 'users':
            admin_page_users();
            break;
        case 'user':
            admin_page_user();
            break;
        case 'posts':
            admin_page_posts();
            break;
        case 'comments':
            admin_page_comments();
            break;
        case 'boards':
            admin_page_boards();
            break;
        case 'board':
            admin_page_board();
            break;
        case 'carousels':
            admin_page_carousels();
            break;
        case 'announcements':
            admin_page_announcements();
            break;
        case 'certifications':
            admin_page_certifications();
            break;
        case 'applications':
            admin_page_applications();
            break;
        case 'links':
            admin_page_links();
            break;
        case 'navigation':
            admin_page_navigation();
            break;
        case 'levels':
            admin_page_levels();
            break;
        case 'rewards':
            admin_page_rewards();
            break;
        case 'settings':
            admin_page_settings();
            break;
        case 'app':
            admin_page_app();
            break;
        case 'broadcast':
            admin_page_broadcast();
            break;
        case 'email_test':
            admin_page_email_test();
            break;
        default:
            admin_page_not_found();
    }
}

function admin_page_dashboard(): void
{
    $stats = [
        'users' => (int) db_value('SELECT COUNT(*) FROM users', [], 0),
        'posts' => (int) db_value('SELECT COUNT(*) FROM posts', [], 0),
        'comments' => (int) db_value('SELECT COUNT(*) FROM comments', [], 0),
        'pending' => (int) db_value("SELECT COUNT(*) FROM verify_applications WHERE status = 'pending'", [], 0),
        'today_users' => (int) db_value('SELECT COUNT(*) FROM users WHERE DATE(created_at) = CURDATE()', [], 0),
        'today_posts' => (int) db_value('SELECT COUNT(*) FROM posts WHERE DATE(created_at) = CURDATE()', [], 0),
        'today_checkins' => (int) db_value('SELECT COUNT(*) FROM checkins WHERE checkin_date = CURDATE()', [], 0),
        'online' => (int) db_value('SELECT COUNT(*) FROM users WHERE last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)', [setting_int('online_minutes', 15)], 0),
    ];
    $recentUsers = db_all('SELECT id, username, email, avatar, level, exp, role, status, created_at FROM users ORDER BY id DESC LIMIT 8');
    $recentPosts = db_all(post_select_sql() . ' ORDER BY p.created_at DESC LIMIT 8');
    $recentApplications = db_all(
        'SELECT a.*, u.username, u.avatar FROM verify_applications a JOIN users u ON u.id = a.user_id
         WHERE a.status = "pending" ORDER BY a.created_at DESC LIMIT 6'
    );
    preload_posts_badges($recentPosts);
    render_admin('dashboard', [
        'pageTitle' => '控制台',
        'stats' => $stats,
        'recentUsers' => $recentUsers,
        'recentPosts' => $recentPosts,
        'recentApplications' => $recentApplications,
    ]);
}

function admin_page_users(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $status = (string) ($_GET['status'] ?? '');
    $page = current_page();
    $per = 25;
    $where = '1=1';
    $params = [];
    if ($q !== '') {
        $where .= ' AND (username LIKE ? OR email LIKE ? OR id = ?)';
        $params[] = like_escape($q);
        $params[] = like_escape($q);
        $params[] = (int) $q;
    }
    if (in_array($status, ['active', 'banned'], true)) {
        $where .= ' AND status = ?';
        $params[] = $status;
    }
    $total = (int) db_value("SELECT COUNT(*) FROM users WHERE {$where}", $params, 0);
    $users = db_all(
        "SELECT * FROM users WHERE {$where} ORDER BY id DESC LIMIT {$per} OFFSET " . (($page - 1) * $per),
        $params
    );
    preload_badges(array_map(fn ($u) => (int) $u['id'], $users));
    render_admin('users', [
        'pageTitle' => '用户管理',
        'users' => $users,
        'q' => $q,
        'status' => $status,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function admin_page_user(): void
{
    $id = (int) ($_GET['id'] ?? 0);
    $user = db_one('SELECT * FROM users WHERE id = ?', [$id]);
    if (!$user) {
        flash('error', '用户不存在。');
        redirect(admin_url('users'));
    }
    preload_badges([$id]);
    $certs = db_all('SELECT * FROM certifications WHERE enabled = 1 ORDER BY sort ASC, id ASC');
    $stats = [
        'posts' => (int) db_value('SELECT COUNT(*) FROM posts WHERE user_id = ? AND status <> "deleted"', [$id], 0),
        'comments' => (int) db_value('SELECT COUNT(*) FROM comments WHERE user_id = ? AND status <> "deleted"', [$id], 0),
        'checkins' => (int) db_value('SELECT COUNT(*) FROM checkins WHERE user_id = ?', [$id], 0),
    ];
    $posts = db_all(post_select_sql() . ' WHERE p.user_id = ? ORDER BY p.created_at DESC LIMIT 8', [$id]);
    $comments = db_all(
        'SELECT c.*, p.title AS post_title FROM comments c LEFT JOIN posts p ON p.id = c.post_id WHERE c.user_id = ? ORDER BY c.created_at DESC LIMIT 8',
        [$id]
    );
    $applications = db_all('SELECT * FROM verify_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10', [$id]);
    $boards = db_all('SELECT b.*, bm.role FROM board_moderators bm JOIN boards b ON b.id = bm.board_id WHERE bm.user_id = ?', [$id]);
    preload_posts_badges($posts);
    render_admin('user', [
        'pageTitle' => '用户 · ' . $user['username'],
        'profile' => $user,
        'certs' => $certs,
        'stats' => $stats,
        'posts' => $posts,
        'comments' => $comments,
        'applications' => $applications,
        'boards' => $boards,
    ]);
}

function admin_page_posts(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $status = (string) ($_GET['status'] ?? '');
    $boardId = (int) ($_GET['board'] ?? 0);
    $page = current_page();
    $per = 20;
    $where = '1=1';
    $params = [];
    if ($q !== '') {
        $where .= ' AND (p.title LIKE ? OR p.content_text LIKE ?)';
        $params[] = like_escape($q);
        $params[] = like_escape($q);
    }
    if (in_array($status, ['published', 'draft', 'deleted'], true)) {
        $where .= ' AND p.status = ?';
        $params[] = $status;
    }
    if ($boardId > 0) {
        $where .= ' AND p.board_id = ?';
        $params[] = $boardId;
    }
    $total = (int) db_value("SELECT COUNT(*) FROM posts p WHERE {$where}", $params, 0);
    $posts = db_all(
        post_select_sql() . " WHERE {$where} ORDER BY p.created_at DESC LIMIT {$per} OFFSET " . (($page - 1) * $per),
        $params
    );
    preload_posts_badges($posts);
    $boards = board_list(false);
    render_admin('posts', [
        'pageTitle' => '帖子管理',
        'posts' => $posts,
        'boards' => $boards,
        'q' => $q,
        'status' => $status,
        'boardId' => $boardId,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function admin_page_comments(): void
{
    $page = current_page();
    $per = 25;
    $total = (int) db_value('SELECT COUNT(*) FROM comments', [], 0);
    $comments = db_all(
        'SELECT c.*, u.username, u.avatar, p.title AS post_title FROM comments c
         JOIN users u ON u.id = c.user_id LEFT JOIN posts p ON p.id = c.post_id
         ORDER BY c.created_at DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per)
    );
    render_admin('comments', [
        'pageTitle' => '评论管理',
        'comments' => $comments,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function admin_page_boards(): void
{
    $boards = db_all(
        "SELECT b.*, (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id) AS post_count
         FROM boards b ORDER BY b.sort ASC, b.id ASC"
    );
    $mods = [];
    foreach (db_all('SELECT bm.board_id, bm.role, u.id, u.username, u.avatar FROM board_moderators bm JOIN users u ON u.id = bm.user_id ORDER BY bm.role ASC, bm.id ASC') as $row) {
        $mods[(int) $row['board_id']][] = $row;
    }
    render_admin('boards', [
        'pageTitle' => '板块管理',
        'boards' => $boards,
        'mods' => $mods,
    ]);
}

function admin_page_board(): void
{
    $id = (int) ($_GET['id'] ?? 0);
    $board = $id > 0 ? db_one('SELECT * FROM boards WHERE id = ?', [$id]) : null;
    if ($id > 0 && !$board) {
        flash('error', '板块不存在。');
        redirect(admin_url('boards'));
    }
    $mods = $id > 0 ? db_all('SELECT * FROM board_moderators WHERE board_id = ?', [$id]) : [];
    $ownerId = 0;
    $coownerIds = [];
    foreach ($mods as $mod) {
        if ($mod['role'] === 'owner') {
            $ownerId = (int) $mod['user_id'];
        } else {
            $coownerIds[] = (int) $mod['user_id'];
        }
    }
    $users = db_all("SELECT id, username FROM users WHERE status = 'active' ORDER BY id ASC LIMIT 1000");
    render_admin('board', [
        'pageTitle' => $board ? '编辑板块 · ' . $board['name'] : '新建板块',
        'board' => $board,
        'ownerId' => $ownerId,
        'coownerIds' => $coownerIds,
        'users' => $users,
    ]);
}

function admin_page_carousels(): void
{
    $items = db_all('SELECT * FROM carousels ORDER BY sort ASC, id ASC');
    render_admin('carousels', [
        'pageTitle' => '首页轮播',
        'items' => $items,
    ]);
}

function admin_page_announcements(): void
{
    $items = db_all('SELECT * FROM announcements ORDER BY sort ASC, id DESC');
    render_admin('announcements', [
        'pageTitle' => '公告管理',
        'items' => $items,
    ]);
}

function admin_page_certifications(): void
{
    $items = db_all('SELECT * FROM certifications ORDER BY sort ASC, id ASC');
    $counts = [];
    foreach (db_all('SELECT cert_id, COUNT(*) AS c FROM user_certifications GROUP BY cert_id') as $row) {
        $counts[(int) $row['cert_id']] = (int) $row['c'];
    }
    render_admin('certifications', [
        'pageTitle' => '认证配置',
        'items' => $items,
        'counts' => $counts,
    ]);
}

function admin_page_applications(): void
{
    $status = (string) ($_GET['status'] ?? 'pending');
    if (!in_array($status, ['pending', 'approved', 'rejected', 'all'], true)) {
        $status = 'pending';
    }
    $where = $status === 'all' ? '1=1' : 'a.status = ?';
    $params = $status === 'all' ? [] : [$status];
    $applications = db_all(
        "SELECT a.*, u.username, u.avatar, u.level, u.exp, u.email FROM verify_applications a JOIN users u ON u.id = a.user_id
         WHERE {$where} ORDER BY a.created_at DESC LIMIT 100",
        $params
    );
    $certs = db_all('SELECT * FROM certifications WHERE enabled = 1 ORDER BY type ASC, sort ASC');
    render_admin('applications', [
        'pageTitle' => '认证审核',
        'applications' => $applications,
        'certs' => $certs,
        'status' => $status,
    ]);
}

function admin_page_links(): void
{
    $items = db_all('SELECT * FROM friend_links ORDER BY sort ASC, id ASC');
    render_admin('links', [
        'pageTitle' => '友情链接',
        'items' => $items,
    ]);
}

function admin_page_navigation(): void
{
    $items = db_all('SELECT * FROM nav_links ORDER BY sort ASC, id ASC');
    render_admin('navigation', [
        'pageTitle' => '快捷栏',
        'items' => $items,
    ]);
}

function admin_page_levels(): void
{
    render_admin('levels', [
        'pageTitle' => '用户等级',
        'items' => levels(true),
    ]);
}

function admin_page_rewards(): void
{
    render_admin('rewards', [
        'pageTitle' => '签到奖励',
        'items' => db_all('SELECT * FROM checkin_rewards ORDER BY streak_days ASC'),
    ]);
}

function admin_page_settings(): void
{
    render_admin('settings', [
        'pageTitle' => '站点设置',
        'settings' => all_settings(true),
    ]);
}

function admin_page_app(): void
{
    ensure_app_release_schema();
    render_admin('app', [
        'pageTitle' => 'App 管理',
        'releases' => app_releases(false),
        'latest' => latest_app_release(),
        'settings' => all_settings(true),
    ]);
}

function admin_page_broadcast(): void
{
    render_admin('broadcast', [
        'pageTitle' => '系统广播',
        'userCount' => (int) db_value("SELECT COUNT(*) FROM users WHERE status = 'active'", [], 0),
        'emailReady' => email_configured(),
    ]);
}

function admin_page_email_test(): void
{
    redirect(admin_url('settings') . '#email');
}

function admin_page_not_found(): void
{
    http_response_code(404);
    render_admin('404', ['pageTitle' => '页面不存在']);
}
