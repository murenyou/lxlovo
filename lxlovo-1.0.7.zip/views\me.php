<?php
$levelInfo = level_progress($profile);
$today = date('Y-m-d');
$historyByDate = [];
foreach ($checkinHistory as $item) {
    $historyByDate[$item['checkin_date']] = $item;
}
$weekDays = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-{$i} day"));
    $weekDays[] = ['date' => $date, 'label' => date('m/d', strtotime($date)), 'checked' => isset($historyByDate[$date])];
}
$notificationUnread = notification_count((int) $profile['id']);
$messageUnread = unread_message_count((int) $profile['id']);
$favoriteCount = $stats['favorites'];
?>
<section class="me-head">
    <div>
        <span class="page-head__eyebrow">My space</span>
        <h1>我的</h1>
        <p>管理你的内容、认证与每一点成长。</p>
    </div>
    <a class="btn btn--primary" href="<?= e(url('publish')) ?>"><?= icon('add', '', 18) ?>写文章</a>
</section>

<div class="me-layout">
    <div class="me-main">
        <section class="me-profile">
            <img class="avatar avatar--lg" src="<?= e(avatar_url($profile)) ?>" alt="">
            <div class="me-profile__body">
                <div class="me-profile__name"><?= e($profile['username']) ?> <?= badge_html((int) $profile['id'], $profile) ?></div>
                <p><?= e($profile['bio'] ?: '还没有简介，去设置里写一句吧。') ?></p>
                <div class="me-profile__meta">
                    <span class="level-dot" style="--level-color:<?= e($levelInfo['current']['color']) ?>">Lv.<?= (int) $levelInfo['current']['level'] ?> <?= e($levelInfo['current']['name']) ?></span>
                    <span>ID <?= (int) $profile['id'] ?></span>
                    <span>加入于 <?= e(format_date($profile['created_at'], 'Y-m-d')) ?></span>
                </div>
            </div>
            <a class="btn btn--outlined btn--sm" href="<?= e(url('settings')) ?>">编辑资料</a>
        </section>

        <section class="checkin-card">
            <div class="checkin-card__main">
                <span class="checkin-card__icon"><?= icon('bolt', '', 30) ?></span>
                <div>
                    <h2><?= $checkedIn ? '今天已经签到' : '签到，积累你的经验' ?></h2>
                    <p><?= $checkedIn ? '明天再来，连续签到奖励会更高。' : '连续签到第 ' . $nextStreak . ' 天，可获得 ' . (int) ($nextReward['exp'] ?? 3) . ' 经验与 ' . (int) ($nextReward['coins'] ?? 1) . ' 金币。' ?></p>
                </div>
            </div>
            <div class="checkin-card__action">
                <div class="checkin-card__streak"><strong><?= (int) $profile['checkin_streak'] ?></strong><span>连续天数</span></div>
                <?php if (!setting_bool('checkin_enabled', true)): ?>
                    <button class="btn btn--tonal" disabled>签到已关闭</button>
                <?php elseif ($checkedIn): ?>
                    <button class="btn btn--tonal" disabled><?= icon('check', '', 18) ?>已签到</button>
                <?php else: ?>
                    <form action="<?= e(url('checkin')) ?>" method="post"><?= csrf_field() ?><button class="btn btn--primary" type="submit"><?= icon('bolt', '', 18) ?>立即签到</button></form>
                <?php endif; ?>
            </div>
            <div class="checkin-week">
                <?php foreach ($weekDays as $day): ?>
                    <div class="checkin-day<?= $day['checked'] ? ' is-checked' : '' ?><?= $day['date'] === $today ? ' is-today' : '' ?>">
                        <span><?= $day['checked'] ? icon('check', '', 15) : '·' ?></span>
                        <small><?= e($day['label']) ?></small>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <div class="me-stats">
            <a class="stat-tile" href="<?= e(url('my_posts')) ?>"><span class="stat-tile__icon"><?= icon('article') ?></span><strong><?= short_number($stats['posts']) ?></strong><span>我的文章</span></a>
            <a class="stat-tile" href="<?= e(url('favorites')) ?>"><span class="stat-tile__icon"><?= icon('bookmark') ?></span><strong><?= short_number($favoriteCount) ?></strong><span>我的收藏</span></a>
            <a class="stat-tile" href="<?= e(url('notifications')) ?>"><span class="stat-tile__icon"><?= icon('notifications') ?></span><strong><?= short_number($notificationUnread) ?></strong><span>未读通知</span></a>
            <a class="stat-tile" href="<?= e(url('messages')) ?>"><span class="stat-tile__icon"><?= icon('mail') ?></span><strong><?= short_number($messageUnread) ?></strong><span>未读私信</span></a>
        </div>

        <section class="section">
            <div class="section__head">
                <div><span class="section__eyebrow">Recent</span><h2>最近文章</h2></div>
                <a class="text-link" href="<?= e(url('my_posts')) ?>">全部<?= icon('chevron_right', '', 17) ?></a>
            </div>
            <?php if ($posts): ?>
                <div class="post-grid">
                    <?php foreach ($posts as $post): ?>
                        <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="empty-state empty-state--small"><?= icon('edit', '', 32) ?><h3>还没有文章</h3><p>把你的第一个想法写下来吧。</p><a class="btn btn--primary btn--sm" href="<?= e(url('publish')) ?>">发布文章</a></div>
            <?php endif; ?>
        </section>
    </div>

    <aside class="me-side">
        <section class="side-card level-card">
            <div class="side-card__head"><h2>成长进度</h2></div>
            <div class="level-big">
                <span class="level-big__num">Lv.<?= (int) $levelInfo['current']['level'] ?></span>
                <span class="level-big__name"><?= e($levelInfo['current']['name']) ?></span>
            </div>
            <div class="level-progress">
                <div class="level-progress__bar"><span style="width:<?= (int) $levelInfo['progress'] ?>%"></span></div>
                <div class="level-progress__meta"><span><?= (int) $profile['exp'] ?> EXP</span><span><?= $levelInfo['next'] ? '下一级 ' . (int) $levelInfo['to_next'] . ' EXP' : '最高等级' ?></span></div>
            </div>
            <div class="coin-display"><?= icon('coin', '', 22) ?><strong><?= short_number((int) $profile['coins']) ?></strong><span>金币</span></div>
        </section>

        <section class="side-card">
            <div class="side-card__head"><h2>我的认证</h2><a class="text-link" href="<?= e(url('verify')) ?>">申请</a></div>
            <?php if ($certifications): ?>
                <div class="cert-list cert-list--stack">
                    <?php foreach ($certifications as $cert): ?>
                        <span class="verify-badge verify-badge--<?= e($cert['type']) ?>" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="muted-text">还没有认证。了解官方、用户与赞助认证。</p>
                <a class="btn btn--tonal btn--sm btn--full" href="<?= e(url('verify')) ?>">查看认证</a>
            <?php endif; ?>
            <?php if ($pendingApplications > 0): ?><p class="pending-note"><?= icon('clock', '', 15) ?>有 <?= $pendingApplications ?> 个申请正在审核</p><?php endif; ?>
        </section>

        <section class="side-card">
            <div class="side-card__head"><h2>快捷入口</h2></div>
            <div class="quick-grid">
                <a href="<?= e(url('my_posts')) ?>"><?= icon('article') ?><span>我的文章</span></a>
                <a href="<?= e(url('favorites')) ?>"><?= icon('bookmark') ?><span>我的收藏</span></a>
                <a href="<?= e(url('notifications')) ?>"><?= icon('notifications') ?><span>通知</span></a>
                <a href="<?= e(url('messages')) ?>"><?= icon('mail') ?><span>私信</span></a>
                <a href="<?= e(url('settings')) ?>"><?= icon('settings') ?><span>设置</span></a>
                <a href="<?= e(url('verify')) ?>"><?= icon('shield') ?><span>认证</span></a>
                <?php if (is_admin($profile)): ?><a href="<?= e(admin_url()) ?>"><?= icon('admin') ?><span>后台</span></a><?php endif; ?>
                <a href="<?= e(url('about')) ?>"><?= icon('info') ?><span>关于</span></a>
            </div>
        </section>

        <section class="side-card">
            <div class="side-card__head"><h2>签到奖励</h2></div>
            <div class="reward-table">
                <?php foreach ($rewards as $days => $reward): ?>
                    <div class="reward-row<?= $nextStreak >= $days && !$checkedIn ? ' is-next' : '' ?>">
                        <span>连续 <?= (int) $days ?> 天</span>
                        <span><?= (int) $reward['exp'] ?> EXP · <?= (int) $reward['coins'] ?> 金币</span>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </aside>
</div>
