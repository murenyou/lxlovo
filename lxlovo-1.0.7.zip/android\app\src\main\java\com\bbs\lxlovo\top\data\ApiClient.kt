package com.bbs.lxlovo.top.data

import android.content.Context
import android.net.Uri
import com.bbs.lxlovo.top.BuildConfig
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class ApiClient(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = AppPrefs(appContext)
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .build()

    suspend fun login(login: String, password: String): AuthResult {
        val json = call(
            "auth.login",
            mapOf("login" to login, "password" to password, "device" to "lxlovo Android"),
            post = true,
        )
        val token = json.string("token")
        if (token.isBlank()) throw ApiException("登录响应异常。")
        prefs.authToken = token
        return AuthResult(token, parseUser(json.optJSONObject("user")), json.string("message"))
    }

    suspend fun register(
        username: String,
        email: String,
        password: String,
        passwordConfirm: String,
    ): AuthResult {
        val json = call(
            "auth.register",
            mapOf(
                "username" to username,
                "email" to email,
                "password" to password,
                "password_confirm" to passwordConfirm,
                "device" to "lxlovo Android",
            ),
            post = true,
        )
        val token = json.string("token")
        if (token.isBlank()) throw ApiException("注册响应异常。")
        prefs.authToken = token
        return AuthResult(token, parseUser(json.optJSONObject("user")), json.string("message"))
    }

    suspend fun logout() {
        try {
            call("auth.logout", emptyMap(), post = true)
        } finally {
            prefs.clearAuth()
        }
    }

    suspend fun me(): MeData = parseMe(call("me"))

    suspend fun home(): HomeData = parseHome(call("home"))

    suspend fun posts(
        page: Int = 1,
        boardId: Int? = null,
        sort: String = "latest",
        query: String = "",
    ): PostPage {
        val params = mutableMapOf(
            "page" to page.toString(),
            "per" to "15",
            "sort" to sort,
        )
        if (boardId != null && boardId > 0) params["board"] = boardId.toString()
        if (query.isNotBlank()) params["q"] = query
        return parsePostPage(call("posts", params))
    }

    suspend fun post(id: Int): Post =
        parsePost(call("post", mapOf("id" to id.toString())).getJSONObject("post"))

    suspend fun likePost(id: Int): LikeResult {
        val json = call("post.like", mapOf("post_id" to id.toString()), post = true)
        return LikeResult(json.optBoolean("liked"), json.optInt("count"))
    }

    suspend fun favoritePost(id: Int): LikeResult {
        val json = call("post.favorite", mapOf("post_id" to id.toString()), post = true)
        return LikeResult(json.optBoolean("favorited"), json.optInt("count"))
    }

    suspend fun rewardPost(id: Int, amount: Int): RewardResult {
        val json = call(
            "post.reward",
            mapOf("post_id" to id.toString(), "amount" to amount.toString()),
            post = true,
        )
        return RewardResult(json.optInt("coins"), json.optInt("reward_total"))
    }

    suspend fun createComment(postId: Int, content: String, parentId: Int? = null): CommentCreated {
        val params = mutableMapOf("post_id" to postId.toString(), "content" to content)
        if (parentId != null) params["parent_id"] = parentId.toString()
        val json = call("comment.create", params, post = true)
        return CommentCreated(
            parseComment(json.getJSONObject("comment")),
            json.optInt("comments_count"),
        )
    }

    suspend fun likeComment(id: Int): LikeResult {
        val json = call("comment.like", mapOf("comment_id" to id.toString()), post = true)
        return LikeResult(json.optBoolean("liked"), json.optInt("count"))
    }

    suspend fun checkin(): CheckinResult {
        val json = call("checkin", emptyMap(), post = true)
        val reward = json.optJSONObject("reward")?.let {
            CheckinReward(it.optInt("streak_days"), it.optInt("exp"), it.optInt("coins"))
        }
        return CheckinResult(json.string("message"), parseUser(json.optJSONObject("user")), reward)
    }

    suspend fun createPost(title: String, boardId: Int, content: String, cover: String = ""): Int {
        val params = mutableMapOf(
            "title" to title,
            "board_id" to boardId.toString(),
            "content" to content,
        )
        if (cover.isNotBlank()) params["cover"] = cover
        val json = call("post.create", params, post = true)
        return json.optInt("post_id")
    }

    suspend fun notifications(page: Int = 1): NotificationPage =
        parseNotifications(call("notifications", mapOf("page" to page.toString())))

    suspend fun markNotificationsRead() {
        call("notifications.read", emptyMap(), post = true)
    }

    suspend fun conversations(): ConversationPage = parseConversations(call("messages.conversations"))

    suspend fun thread(userId: Int): MessageThread =
        parseThread(call("messages.thread", mapOf("user_id" to userId.toString())))

    suspend fun sendMessage(userId: Int, content: String): MessageItem {
        val json = call(
            "messages.send",
            mapOf("user_id" to userId.toString(), "content" to content),
            post = true,
        )
        return parseMessage(json.getJSONObject("message"))
    }

    suspend fun user(id: Int): UserPage =
        parseUserPage(call("user", mapOf("id" to id.toString())))

    suspend fun search(query: String): SearchResult =
        parseSearch(call("search", mapOf("q" to query)))

    suspend fun boards(): List<Board> = parseBoards(call("boards").array("items"))

    suspend fun createBoard(name: String, slug: String, description: String, color: String): Board {
        val json = call(
            "board.create",
            mapOf(
                "name" to name,
                "slug" to slug,
                "description" to description,
                "color" to color,
            ),
            post = true,
        )
        return parseBoard(json.getJSONObject("board"))
    }

    suspend fun updateProfile(
        bio: String,
        showOfficialBadge: Boolean,
        notifyComment: Boolean = true,
        notifyMention: Boolean = true,
        notifyMessage: Boolean = true,
        notifySystem: Boolean = true,
        notifyEmail: Boolean = true,
    ): User {
        val json = call(
            "profile.update",
            mapOf(
                "bio" to bio,
                "show_official_badge" to boolValue(showOfficialBadge),
                "notify_comment" to boolValue(notifyComment),
                "notify_mention" to boolValue(notifyMention),
                "notify_message" to boolValue(notifyMessage),
                "notify_system" to boolValue(notifySystem),
                "notify_email" to boolValue(notifyEmail),
            ),
            post = true,
        )
        return parseUser(json.optJSONObject("user"))
    }

    suspend fun uploadAvatar(uri: Uri): User {
        val json = uploadFile("profile.avatar", "avatar", uri)
        return parseUser(json.optJSONObject("user"))
    }

    suspend fun uploadPostImage(uri: Uri): String {
        val json = uploadFile("upload.image", "image", uri)
        return json.string("url")
    }

    suspend fun changePassword(oldPassword: String, newPassword: String, confirm: String): String {
        val json = call(
            "profile.password",
            mapOf(
                "old_password" to oldPassword,
                "new_password" to newPassword,
                "new_password_confirm" to confirm,
            ),
            post = true,
        )
        return json.string("message", "密码已更新。")
    }

    suspend fun changeEmail(email: String, password: String): Pair<String, User> {
        val json = call(
            "profile.email",
            mapOf("email" to email, "password" to password),
            post = true,
        )
        return json.string("message") to parseUser(json.optJSONObject("user"))
    }

    suspend fun resendVerification(): String {
        val json = call("auth.email.resend", emptyMap(), post = true)
        return json.string("message")
    }

    suspend fun verifyApply(type: String, reason: String, proof: String): String {
        val json = call(
            "auth.verify.apply",
            mapOf("type" to type, "reason" to reason, "proof" to proof),
            post = true,
        )
        return json.string("message")
    }

    suspend fun verifyStatus(): VerifyStatus = parseVerifyStatus(call("auth.verify.status"))

    suspend fun updatePost(id: Int, title: String, boardId: Int, content: String, cover: String = "") {
        call(
            "post.update",
            mapOf(
                "id" to id.toString(),
                "title" to title,
                "board_id" to boardId.toString(),
                "content" to content,
                "cover" to cover,
            ),
            post = true,
        )
    }

    suspend fun deletePost(id: Int) {
        call("post.delete", mapOf("id" to id.toString()), post = true)
    }

    suspend fun featurePost(id: Int): Boolean =
        call("post.feature", mapOf("post_id" to id.toString()), post = true).optBoolean("featured")

    suspend fun pinComment(id: Int): Boolean =
        call("comment.pin", mapOf("comment_id" to id.toString()), post = true).optBoolean("pinned")

    suspend fun deleteComment(id: Int) {
        call("comment.delete", mapOf("comment_id" to id.toString()), post = true)
    }

    suspend fun onlineUsers(): List<User> {
        val array = call("online").array("items")
        return buildList {
            for (i in 0 until array.length()) {
                array.optJSONObject(i)?.let { add(parseUser(it)) }
            }
        }
    }

    suspend fun about(): AboutData = parseAbout(call("about"))

    suspend fun favorites(page: Int = 1): PostPage =
        parsePostPage(call("favorites", mapOf("page" to page.toString())))

    suspend fun myPosts(page: Int = 1): PostPage =
        parsePostPage(call("my.posts", mapOf("page" to page.toString())))

    private suspend fun uploadFile(action: String, field: String, uri: Uri): JSONObject =
        withContext(Dispatchers.IO) {
            val bytes = appContext.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: throw ApiException("无法读取图片。")
            if (bytes.size > 12 * 1024 * 1024) throw ApiException("图片不能超过 12MB。")
            val mime = appContext.contentResolver.getType(uri) ?: "image/jpeg"
            val extension = when {
                mime.contains("png") -> "png"
                mime.contains("webp") -> "webp"
                mime.contains("gif") -> "gif"
                else -> "jpg"
            }
            val body = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart(
                    field,
                    "upload.$extension",
                    bytes.toRequestBody(mime.toMediaType()),
                )
                .build()
            val url = BuildConfig.API_URL.toHttpUrl().newBuilder()
                .addQueryParameter("action", action)
                .build()
            val request = Request.Builder()
                .url(url)
                .header("Accept", "application/json")
                .header("User-Agent", "lxlovo-android/${BuildConfig.VERSION_NAME}")
                .apply {
                    prefs.authToken?.takeIf { it.isNotBlank() }?.let {
                        header("Authorization", "Bearer $it")
                    }
                }
                .post(body)
                .build()
            execute(request)
        }

    private fun boolValue(value: Boolean): String = if (value) "1" else "0"

    private suspend fun call(
        action: String,
        params: Map<String, String> = emptyMap(),
        post: Boolean = false,
    ): JSONObject = withContext(Dispatchers.IO) {
        val urlBuilder = BuildConfig.API_URL.toHttpUrl().newBuilder()
            .addQueryParameter("action", action)
        val body = if (post) {
            FormBody.Builder().apply {
                params.forEach { (key, value) -> add(key, value) }
            }.build()
        } else {
            params.forEach { (key, value) -> urlBuilder.addQueryParameter(key, value) }
            null
        }
        val requestBuilder = Request.Builder()
            .url(urlBuilder.build())
            .header("Accept", "application/json")
            .header("User-Agent", "lxlovo-android/${BuildConfig.VERSION_NAME}")
        prefs.authToken?.takeIf { it.isNotBlank() }?.let {
            requestBuilder.header("Authorization", "Bearer $it")
        }
        if (post) {
            requestBuilder.post(body!!)
        } else {
            requestBuilder.get()
        }
        execute(requestBuilder.build())
    }

    private fun execute(request: Request): JSONObject {
        client.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            val json = try {
                JSONObject(text)
            } catch (error: Exception) {
                throw ApiException(
                    if (response.code >= 500) "服务器暂时无法处理请求。" else "接口返回异常。",
                    response.code,
                )
            }
            if (!response.isSuccessful || !json.optBoolean("ok", false)) {
                if (response.code == 401) {
                    prefs.clearAuth()
                }
                throw ApiException(
                    json.optString("message", "请求失败（${response.code}）"),
                    response.code,
                )
            }
            return json
        }
    }
}
