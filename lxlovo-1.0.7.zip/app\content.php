<?php

/* ---------------------------------------------------------------------------
 * 内容安全、富文本渲染与 @ 提醒
 * ------------------------------------------------------------------------- */

function allowed_html_tags(): array
{
    return ['p', 'br', 'div', 'span', 'strong', 'b', 'em', 'i', 'u', 's', 'strike', 'h2', 'h3', 'h4', 'blockquote', 'ul', 'ol', 'li', 'a', 'img', 'pre', 'code', 'hr', 'font', 'figure', 'figcaption'];
}

function clean_style_value(string $property, string $value): ?string
{
    $value = trim($value);
    if ($value === '' || preg_match('/url\s*\(|expression|javascript|@import/i', $value)) {
        return null;
    }
    return match ($property) {
        'color' => preg_match('/^(#[0-9a-f]{3,8}|rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\)|rgba\([0-9.,\s]+\)|[a-z]{3,20})$/i', $value) ? $value : null,
        'font-size' => preg_match('/^(?:[8-9]|[1-6]\d|72)(?:px|pt)?$|^(?:0\.[6-9]|1(?:\.\d)?|2(?:\.\d)?)em$|^\d{1,3}%$/', $value) ? $value : null,
        'font-weight' => preg_match('/^(normal|bold|bolder|lighter|[1-9]00)$/i', $value) ? $value : null,
        'text-align' => in_array(strtolower($value), ['left', 'right', 'center', 'justify'], true) ? strtolower($value) : null,
        'text-decoration' => preg_match('/^(none|underline|line-through|overline)(\s+(underline|line-through|overline))*$/i', $value) ? $value : null,
        'font-style' => in_array(strtolower($value), ['normal', 'italic'], true) ? strtolower($value) : null,
        default => null,
    };
}

function clean_style_attr(string $style): string
{
    $clean = [];
    foreach (explode(';', $style) as $part) {
        if (!str_contains($part, ':')) {
            continue;
        }
        [$property, $value] = array_map('trim', explode(':', $part, 2));
        $property = strtolower($property);
        $safe = clean_style_value($property, $value);
        if ($safe !== null) {
            $clean[] = $property . ':' . $safe;
        }
    }
    return implode(';', $clean);
}

function safe_content_url(string $url, bool $image = false): ?string
{
    $url = trim(html_entity_decode($url, ENT_QUOTES, 'UTF-8'));
    if ($url === '') {
        return null;
    }
    if (preg_match('#^https?://#i', $url)) {
        return $url;
    }
    if (!$image && preg_match('#^mailto:[^\s]+$#i', $url)) {
        return $url;
    }
    if (str_starts_with($url, '#')) {
        return $url;
    }
    if (str_starts_with($url, '//')) {
        return null;
    }
    if (preg_match('#^(index\.php\?|uploads/|assets/|/)#', $url)) {
        return $url;
    }
    return null;
}

function sanitize_html(string $html): string
{
    $html = trim($html);
    if ($html === '') {
        return '';
    }
    $doc = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $wrapped = '<?xml encoding="UTF-8"><div id="lxl-sanitize-root">' . $html . '</div>';
    $loaded = $doc->loadHTML($wrapped, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    if (!$loaded) {
        return '';
    }
    $root = $doc->getElementById('lxl-sanitize-root');
    if (!$root) {
        return '';
    }

    $allowed = allowed_html_tags();
    $classAllow = ['video-embed', 'text-center', 'text-right', 'text-left', 'mention'];
    $dropTags = ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input', 'button', 'textarea', 'select', 'option', 'link', 'meta', 'base', 'svg', 'math'];
    $walk = function (DOMNode $node) use (&$walk, $allowed, $classAllow, $dropTags): void {
        foreach (iterator_to_array($node->childNodes) as $child) {
            if ($child instanceof DOMComment) {
                $node->removeChild($child);
                continue;
            }
            if (!$child instanceof DOMElement) {
                continue;
            }
            $tag = strtolower($child->tagName);
            if (in_array($tag, $dropTags, true)) {
                $node->removeChild($child);
                continue;
            }
            $walk($child);
            if (!in_array($tag, $allowed, true)) {
                $parent = $child->parentNode;
                if ($parent) {
                    while ($child->firstChild) {
                        $parent->insertBefore($child->firstChild, $child);
                    }
                    $parent->removeChild($child);
                }
                continue;
            }

            foreach (iterator_to_array($child->attributes) as $attribute) {
                $name = strtolower($attribute->name);
                $value = $attribute->value;
                $keep = false;
                if ($name === 'class') {
                    $tokens = preg_split('/\s+/', trim($value)) ?: [];
                    $tokens = array_values(array_intersect($tokens, $classAllow));
                    if ($tokens !== []) {
                        $child->setAttribute('class', implode(' ', $tokens));
                    } else {
                        $child->removeAttribute('class');
                    }
                    continue;
                }
                if ($name === 'style') {
                    $cleanStyle = clean_style_attr($value);
                    if ($cleanStyle !== '') {
                        $child->setAttribute('style', $cleanStyle);
                    } else {
                        $child->removeAttribute('style');
                    }
                    continue;
                }
                if ($tag === 'a' && in_array($name, ['href', 'title'], true)) {
                    if ($name === 'href') {
                        $safe = safe_content_url($value);
                        if ($safe !== null) {
                            $child->setAttribute('href', $safe);
                            $keep = true;
                        }
                    } else {
                        $child->setAttribute('title', mb_substr($value, 0, 200));
                        $keep = true;
                    }
                } elseif ($tag === 'img' && in_array($name, ['src', 'alt', 'title'], true)) {
                    if ($name === 'src') {
                        $safe = safe_content_url($value, true);
                        if ($safe !== null) {
                            $child->setAttribute('src', $safe);
                            $keep = true;
                        }
                    } else {
                        $child->setAttribute($name, mb_substr($value, 0, 200));
                        $keep = true;
                    }
                } elseif ($tag === 'font' && $name === 'color') {
                    if (preg_match('/^#[0-9a-f]{3,8}$/i', $value) || preg_match('/^[a-z]{3,20}$/i', $value)) {
                        $child->setAttribute('color', $value);
                        $keep = true;
                    }
                } elseif ($tag === 'font' && $name === 'size') {
                    if (preg_match('/^[1-7]$/', $value)) {
                        $child->setAttribute('size', $value);
                        $keep = true;
                    }
                } elseif ($tag === 'div' && $name === 'data-video') {
                    $safe = safe_content_url($value);
                    if ($safe !== null) {
                        $child->setAttribute('data-video', $safe);
                        $keep = true;
                    }
                }
                if (!$keep) {
                    $child->removeAttribute($attribute->name);
                }
            }
            if ($tag === 'a' && $child->hasAttribute('href')) {
                $child->setAttribute('rel', 'nofollow noopener noreferrer');
                $child->setAttribute('target', '_blank');
            }
            if ($tag === 'img') {
                $child->setAttribute('loading', 'lazy');
                $child->setAttribute('decoding', 'async');
            }
        }
    };
    $walk($root);

    $output = '';
    foreach ($root->childNodes as $child) {
        $output .= $doc->saveHTML($child);
    }
    return trim($output);
}

function resolve_mention_users(array $names): array
{
    $names = array_values(array_unique(array_filter(array_map('trim', $names))));
    if ($names === []) {
        return [];
    }
    $cache = $GLOBALS['lxl_mention_user_cache'] ?? [];
    $missing = array_values(array_filter($names, fn ($name) => !array_key_exists(mb_strtolower($name), $cache)));
    if ($missing === []) {
        return $cache;
    }
    $placeholders = implode(',', array_fill(0, count($missing), '?'));
    $rows = db_all("SELECT id, username, avatar, status FROM users WHERE username IN ({$placeholders})", $missing);
    foreach ($rows as $row) {
        $cache[mb_strtolower($row['username'])] = $row;
    }
    $GLOBALS['lxl_mention_user_cache'] = $cache;
    return $cache;
}

function extract_mentions(string $text): array
{
    $text = html_entity_decode(strip_tags($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    preg_match_all('/@([\p{L}\p{N}_\-]{2,32})/u', $text, $matches);
    return array_values(array_unique($matches[1] ?? []));
}

function linkify_mentions_html(string $html): string
{
    if (!str_contains($html, '@')) {
        return $html;
    }
    $doc = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8"><div id="lxl-mention-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $root = $doc->getElementById('lxl-mention-root');
    if (!$root) {
        return $html;
    }

    $textNodes = [];
    $xpath = new DOMXPath($doc);
    foreach ($xpath->query('.//text()[not(ancestor::a) and not(ancestor::code) and not(ancestor::pre)]') as $node) {
        if ($node instanceof DOMText && str_contains($node->nodeValue, '@')) {
            $textNodes[] = $node;
        }
    }
    if ($textNodes === []) {
        return $html;
    }
    $names = [];
    foreach ($textNodes as $node) {
        preg_match_all('/@([\p{L}\p{N}_\-]{2,32})/u', $node->nodeValue, $matches);
        foreach ($matches[1] ?? [] as $name) {
            $names[] = $name;
        }
    }
    $users = resolve_mention_users($names);
    if ($users === []) {
        return $html;
    }

    foreach ($textNodes as $node) {
        $text = $node->nodeValue;
        $parts = preg_split('/(@[\p{L}\p{N}_\-]{2,32})/u', $text, -1, PREG_SPLIT_DELIM_CAPTURE);
        if ($parts === false) {
            continue;
        }
        $fragment = $doc->createDocumentFragment();
        foreach ($parts as $part) {
            if (preg_match('/^@([\p{L}\p{N}_\-]{2,32})$/u', $part, $m)) {
                $user = $users[mb_strtolower($m[1])] ?? null;
                if ($user && $user['status'] === 'active') {
                    $a = $doc->createElement('a');
                    $a->setAttribute('class', 'mention');
                    $a->setAttribute('href', url('user', ['id' => (int) $user['id']]));
                    $a->textContent = $part;
                    $fragment->appendChild($a);
                    continue;
                }
            }
            $fragment->appendChild($doc->createTextNode($part));
        }
        $node->parentNode->replaceChild($fragment, $node);
    }

    $output = '';
    foreach ($root->childNodes as $child) {
        $output .= $doc->saveHTML($child);
    }
    return trim($output);
}

function video_embed_url(string $url): ?string
{
    if (preg_match('#(?:youtube\.com/(?:watch\?v=|embed/)|youtu\.be/)([A-Za-z0-9_-]{6,})#i', $url, $m)) {
        return 'https://www.youtube.com/embed/' . $m[1];
    }
    if (preg_match('#bilibili\.com/video/(BV[A-Za-z0-9]+)#i', $url, $m)) {
        return 'https://player.bilibili.com/player.html?bvid=' . $m[1] . '&autoplay=0';
    }
    if (preg_match('#bilibili\.com/video/av(\d+)#i', $url, $m)) {
        return 'https://player.bilibili.com/player.html?aid=' . $m[1] . '&autoplay=0';
    }
    if (preg_match('#v\.qq\.com/(?:x/page|x/cover/[^/]+)/([A-Za-z0-9]+)\.html#i', $url, $m)) {
        return 'https://v.qq.com/txp/iframe/player.html?vid=' . $m[1];
    }
    if (preg_match('#v\.youku\.com/v_show/id_([A-Za-z0-9=]+)\.html#i', $url, $m)) {
        return 'https://player.youku.com/embed/' . $m[1];
    }
    return null;
}

function embed_videos(string $html): string
{
    if (!str_contains($html, 'data-video')) {
        return $html;
    }
    $doc = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $doc->loadHTML('<?xml encoding="UTF-8"><div id="lxl-video-root">' . $html . '</div>', LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    libxml_clear_errors();
    libxml_use_internal_errors($previous);
    $root = $doc->getElementById('lxl-video-root');
    if (!$root) {
        return $html;
    }
    $xpath = new DOMXPath($doc);
    foreach ($xpath->query('.//div[@data-video]') as $div) {
        if (!$div instanceof DOMElement) {
            continue;
        }
        $url = $div->getAttribute('data-video');
        $embed = video_embed_url($url);
        if ($embed !== null) {
            $wrapper = $doc->createElement('div');
            $wrapper->setAttribute('class', 'video-frame');
            $iframe = $doc->createElement('iframe');
            $iframe->setAttribute('src', $embed);
            $iframe->setAttribute('loading', 'lazy');
            $iframe->setAttribute('allowfullscreen', 'allowfullscreen');
            $iframe->setAttribute('allow', 'autoplay; fullscreen; picture-in-picture');
            $iframe->setAttribute('referrerpolicy', 'strict-origin-when-cross-origin');
            $wrapper->appendChild($iframe);
            $div->parentNode->replaceChild($wrapper, $div);
        } else {
            $p = $doc->createElement('p');
            $a = $doc->createElement('a');
            $a->setAttribute('href', $url);
            $a->setAttribute('target', '_blank');
            $a->setAttribute('rel', 'noopener noreferrer');
            $a->textContent = '打开视频：' . $url;
            $p->appendChild($a);
            $div->parentNode->replaceChild($p, $div);
        }
    }
    $output = '';
    foreach ($root->childNodes as $child) {
        $output .= $doc->saveHTML($child);
    }
    return trim($output);
}

function render_content(string $html): string
{
    return embed_videos(linkify_mentions_html(sanitize_html($html)));
}

function format_comment(string $content): string
{
    $safe = nl2br(e($content));
    $names = extract_mentions($content);
    $users = resolve_mention_users($names);
    if ($users === []) {
        return $safe;
    }
    return preg_replace_callback('/@([\p{L}\p{N}_\-]{2,32})/u', function ($m) use ($users) {
        $user = $users[mb_strtolower($m[1])] ?? null;
        if ($user && $user['status'] === 'active') {
            return '<a class="mention" href="' . e(url('user', ['id' => (int) $user['id']])) . '">@' . e($m[1]) . '</a>';
        }
        return '@' . e($m[1]);
    }, $safe) ?? $safe;
}

function plain_text_from_html(string $html): string
{
    $html = preg_replace('#<(br|/p|/div|/li|/h[1-6]|/blockquote)\s*/?>#i', ' ', $html) ?? $html;
    $text = html_entity_decode(strip_tags($html), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return trim(preg_replace('/\s+/u', ' ', $text) ?? '');
}

function comment_text(string $content): string
{
    return trim(preg_replace('/\s+/u', ' ', $content) ?? '');
}
