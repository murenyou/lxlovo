<?php

/* ---------------------------------------------------------------------------
 * 前台写操作
 * ------------------------------------------------------------------------- */

function site_action(string $route): void
{
    switch ($route) {
        case 'register':
            action_register();
            break;
        case 'login':
            action_login();
            break;
        case 'logout':
            action_logout();
            break;
        case 'checkin':
            action_checkin();
            break;
        case 'post.save':
            action_post_save();
            break;
        case 'post.delete':
            action_post_delete();
            break;
        case 'post.like':
            action_post_like();
            break;
        case 'post.favorite':
            action_post_favorite();
            break;
        case 'post.reward':
            action_post_reward();
            break;
        case 'post.feature':
            action_post_feature();
            break;
        case 'comment.create':
            action_comment_create();
            break;
        case 'comment.like':
            action_comment_like();
            break;
        case 'comment.pin':
            action_comment_pin();
            break;
        case 'comment.delete':
            action_comment_delete();
            break;
        case 'profile.save':
            action_profile_save();
            break;
        case 'profile.avatar':
            action_profile_avatar();
            break;
        case 'profile.password':
            action_profile_password();
            break;
        case 'profile.email':
            action_profile_email();
            break;
        case 'notifications.read':
            action_notifications_read();
            break;
        case 'message.send':
            action_message_send();
            break;
        case 'verify.apply':
            action_verify_apply();
            break;
        case 'upload.image':
            action_upload_image();
            break;
        case 'resend_verification':
            action_resend_verification();
            break;
        case 'forgot_password':
            action_forgot_password();
            break;
        case 'reset_password':
            action_reset_password();
            break;
        case 'announcement.seen':
            action_announcement_seen();
            break;
        default:
            http_response_code(404);
            flash('error', '请求的页面不存在。');
            redirect(url('home'));
    }
}

function action_register(): void
{
    if (!rate_limit('register', 5, 3600)) {
        fail_back('注册过于频繁，请稍后再试。', url('register'));
    }
    [$ok, $message, $user] = register_user(
        (string) ($_POST['username'] ?? ''),
        (string) ($_POST['email'] ?? ''),
        (string) ($_POST['password'] ?? ''),
        (string) ($_POST['password_confirm'] ?? '')
    );
    if (!$ok) {
        fail_back($message, url('register'), [
            'username' => (string) ($_POST['username'] ?? ''),
            'email' => (string) ($_POST['email'] ?? ''),
        ]);
    }
    login_user($user);
    clear_old();
    if ($message !== '') {
        flash('warning', $message);
    } else {
        flash('success', '注册成功，欢迎来到 lxlovo。');
    }
    if (setting_bool('email_verify_required') && !email_verified()) {
        redirect(url('verify_email'));
    }
    redirect(url('home'));
}

function action_login(): void
{
    $next = safe_next_url($_POST['next'] ?? null);
    [$ok, $message] = login_user_by_credentials(
        (string) ($_POST['login'] ?? ''),
        (string) ($_POST['password'] ?? '')
    );
    if (!$ok) {
        fail_back($message, url('login', ['next' => $next]), ['login' => (string) ($_POST['login'] ?? '')]);
    }
    clear_old();
    flash('success', '欢迎回来。');
    redirect($next);
}

function action_logout(): void
{
    logout_user();
    flash('success', '你已退出登录。');
    redirect(url('home'));
}

function action_checkin(): void
{
    $user = require_login();
    [$ok, $message] = apply_checkin($user);
    flash($ok ? 'success' : 'info', $message);
    redirect(url('me'));
}

function action_post_save(): void
{
    $user = require_login();
    if (setting_bool('email_verify_required') && !email_verified($user)) {
        fail_back('请先完成邮箱验证。', url('verify_email'));
    }
    $id = (int) ($_POST['id'] ?? 0);
    $title = trim((string) ($_POST['title'] ?? ''));
    $boardId = (int) ($_POST['board_id'] ?? 0);
    $rawContent = (string) ($_POST['content'] ?? '');
    $board = board_by_id($boardId);
    $safeContent = sanitize_html($rawContent);
    if (!$board || $board['status'] !== 'active') {
        fail_back('请选择有效的板块。', $id > 0 ? url('publish', ['id' => $id]) : url('publish'), ['title' => $title, 'content' => $safeContent, 'board_id' => $boardId]);
    }
    if (mb_strlen($title) < 2 || mb_strlen($title) > 120) {
        fail_back('标题长度需为 2-120 个字符。', $id > 0 ? url('publish', ['id' => $id]) : url('publish'), ['title' => $title, 'content' => $safeContent, 'board_id' => $boardId]);
    }
    $content = $safeContent;
    $plain = plain_text_from_html($content);
    if (mb_strlen($plain) < 2) {
        fail_back('正文内容不能为空。', $id > 0 ? url('publish', ['id' => $id]) : url('publish'), ['title' => $title, 'content' => $safeContent, 'board_id' => $boardId]);
    }
    if (mb_strlen($plain) > 100000) {
        fail_back('正文内容过长。', $id > 0 ? url('publish', ['id' => $id]) : url('publish'));
    }
    $cover = pick_cover_from_html($content);

    if ($id > 0) {
        $post = post_by_id($id, true);
        if (!$post || !can_edit_post($post, $user)) {
            fail_back('你没有权限编辑这篇帖子。', url('home'));
        }
        db_exec(
            'UPDATE posts SET board_id = ?, title = ?, content = ?, content_text = ?, cover = ? WHERE id = ?',
            [$boardId, $title, $content, $plain, $cover, $id]
        );
        db_exec('UPDATE posts SET updated_at = NOW() WHERE id = ?', [$id]);
        flash('success', '帖子已更新。');
        redirect(url('post', ['id' => $id]));
    }

    $postId = db_insert(
        'INSERT INTO posts (board_id, user_id, title, content, content_text, cover, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, "published", NOW(), NOW())',
        [$boardId, (int) $user['id'], $title, $content, $plain, $cover]
    );
    notify_mentions($content, $user, $title, url('post', ['id' => $postId]));
    flash('success', '发布成功。');
    redirect(url('post', ['id' => $postId]));
}

function action_post_delete(): void
{
    $user = require_login();
    $id = (int) ($_POST['id'] ?? 0);
    $post = post_by_id($id, true);
    if (!$post || !can_edit_post($post, $user)) {
        fail_back('你没有权限删除这篇帖子。', url('home'));
    }
    db_exec('UPDATE posts SET status = "deleted" WHERE id = ?', [$id]);
    flash('success', '帖子已删除。');
    redirect(url('me'));
}

function action_post_like(): void
{
    $user = require_login();
    $postId = (int) ($_POST['post_id'] ?? 0);
    $post = post_by_id($postId);
    if (!$post) {
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => '帖子不存在。'], 404);
        }
        fail_back('帖子不存在。', url('home'));
    }
    $exists = db_value('SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM post_likes WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO post_likes (post_id, user_id) VALUES (?, ?)', [$postId, (int) $user['id']]);
    }
    sync_post_counters($postId);
    $count = (int) db_value('SELECT likes_count FROM posts WHERE id = ?', [$postId], 0);
    if (is_ajax()) {
        json_response(['ok' => true, 'liked' => !$exists, 'count' => $count]);
    }
    redirect(url('post', ['id' => $postId]));
}

function action_post_favorite(): void
{
    $user = require_login();
    $postId = (int) ($_POST['post_id'] ?? 0);
    $post = post_by_id($postId);
    if (!$post) {
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => '帖子不存在。'], 404);
        }
        fail_back('帖子不存在。', url('home'));
    }
    $exists = db_value('SELECT COUNT(*) FROM post_favorites WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM post_favorites WHERE post_id = ? AND user_id = ?', [$postId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO post_favorites (post_id, user_id) VALUES (?, ?)', [$postId, (int) $user['id']]);
    }
    sync_post_counters($postId);
    $count = (int) db_value('SELECT favorites_count FROM posts WHERE id = ?', [$postId], 0);
    if (is_ajax()) {
        json_response(['ok' => true, 'favorited' => !$exists, 'count' => $count]);
    }
    redirect(url('post', ['id' => $postId]));
}

function action_post_reward(): void
{
    $user = require_login();
    $postId = (int) ($_POST['post_id'] ?? 0);
    $amount = (int) ($_POST['amount'] ?? 0);
    $post = post_by_id($postId);
    if (!$post) {
        fail_back('帖子不存在。', url('home'));
    }
    if ((int) $post['user_id'] === (int) $user['id']) {
        fail_back('不能打赏自己的帖子。', url('post', ['id' => $postId]));
    }
    if ($amount < 1 || $amount > 1000) {
        fail_back('打赏金额需在 1-1000 金币之间。', url('post', ['id' => $postId]));
    }
    try {
        db_transaction(function (PDO $pdo) use ($user, $post, $amount, $postId) {
            $stmt = $pdo->prepare('SELECT coins FROM users WHERE id = ? FOR UPDATE');
            $stmt->execute([(int) $user['id']]);
            $coins = (int) $stmt->fetchColumn();
            if ($coins < $amount) {
                throw new RuntimeException('金币不足，先去签到攒一些金币吧。');
            }
            $pdo->prepare('UPDATE users SET coins = coins - ? WHERE id = ?')->execute([$amount, (int) $user['id']]);
            $pdo->prepare('UPDATE users SET coins = coins + ? WHERE id = ?')->execute([$amount, (int) $post['user_id']]);
            $pdo->prepare('INSERT INTO post_rewards (post_id, user_id, amount) VALUES (?, ?, ?)')->execute([$postId, (int) $user['id'], $amount]);
        });
    } catch (RuntimeException $e) {
        fail_back($e->getMessage(), url('post', ['id' => $postId]));
    }
    sync_post_counters($postId);
    refresh_current_user();
    notify_user(
        (int) $post['user_id'],
        (int) $user['id'],
        'reward',
        $user['username'] . ' 打赏了你的帖子《' . mb_substr($post['title'], 0, 50) . '》' . $amount . ' 金币',
        url('post', ['id' => $postId])
    );
    flash('success', '打赏成功，感谢你的支持。');
    redirect(url('post', ['id' => $postId]));
}

function action_post_feature(): void
{
    $user = require_login();
    if (!is_admin($user) && !is_official_user((int) $user['id'])) {
        fail_back('只有官方认证账号可以设置精选帖子。', url('home'));
    }
    $postId = (int) ($_POST['post_id'] ?? 0);
    $post = post_by_id($postId);
    if (!$post) {
        fail_back('帖子不存在。', url('home'));
    }
    $newValue = (int) $post['is_featured'] === 1 ? 0 : 1;
    db_exec('UPDATE posts SET is_featured = ?, featured_by = ? WHERE id = ?', [$newValue, $newValue ? (int) $user['id'] : null, $postId]);
    flash('success', $newValue ? '已设为精选。' : '已取消精选。');
    redirect(url('post', ['id' => $postId]));
}

function action_comment_create(): void
{
    $user = require_login();
    if (setting_bool('email_verify_required') && !email_verified($user)) {
        fail_back('请先完成邮箱验证。', url('verify_email'));
    }
    $postId = (int) ($_POST['post_id'] ?? 0);
    $post = post_by_id($postId);
    if (!$post) {
        fail_back('帖子不存在。', url('home'));
    }
    $content = comment_text((string) ($_POST['content'] ?? ''));
    if (mb_strlen($content) < 1 || mb_strlen($content) > 1000) {
        fail_back('评论长度需为 1-1000 个字符。', url('post', ['id' => $postId]));
    }
    $parentId = null;
    $replyToUserId = null;
    $parent = null;
    $parentInput = (int) ($_POST['parent_id'] ?? 0);
    if ($parentInput > 0) {
        $parent = comment_by_id($parentInput);
        if (!$parent || (int) $parent['post_id'] !== $postId || $parent['status'] !== 'published') {
            fail_back('回复的评论不存在。', url('post', ['id' => $postId]));
        }
        $parentId = !empty($parent['parent_id']) ? (int) $parent['parent_id'] : (int) $parent['id'];
        $replyToUserId = (int) $parent['user_id'];
    }
    $commentId = db_insert(
        'INSERT INTO comments (post_id, user_id, parent_id, reply_to_user_id, content) VALUES (?, ?, ?, ?, ?)',
        [$postId, (int) $user['id'], $parentId, $replyToUserId, $content]
    );
    sync_post_counters($postId);
    $comment = comment_by_id($commentId) ?? [];
    notify_new_comment($post, $comment, $user);
    flash('success', '评论已发布。');
    redirect(url('post', ['id' => $postId]) . '#comment-' . $commentId);
}

function action_comment_like(): void
{
    $user = require_login();
    $commentId = (int) ($_POST['comment_id'] ?? 0);
    $comment = comment_by_id($commentId);
    if (!$comment || $comment['status'] !== 'published') {
        if (is_ajax()) {
            json_response(['ok' => false, 'message' => '评论不存在。'], 404);
        }
        fail_back('评论不存在。', url('home'));
    }
    $exists = db_value('SELECT COUNT(*) FROM comment_likes WHERE comment_id = ? AND user_id = ?', [$commentId, (int) $user['id']], 0) > 0;
    if ($exists) {
        db_exec('DELETE FROM comment_likes WHERE comment_id = ? AND user_id = ?', [$commentId, (int) $user['id']]);
    } else {
        db_exec('INSERT IGNORE INTO comment_likes (comment_id, user_id) VALUES (?, ?)', [$commentId, (int) $user['id']]);
    }
    $count = (int) db_value('SELECT COUNT(*) FROM comment_likes WHERE comment_id = ?', [$commentId], 0);
    db_exec('UPDATE comments SET likes_count = ? WHERE id = ?', [$count, $commentId]);
    if (is_ajax()) {
        json_response(['ok' => true, 'liked' => !$exists, 'count' => $count]);
    }
    redirect(url('post', ['id' => (int) $comment['post_id']]) . '#comment-' . $commentId);
}

function action_comment_pin(): void
{    $user = require_login();
    $commentId = (int) ($_POST['comment_id'] ?? 0);
    $comment = comment_by_id($commentId);
    if (!$comment || $comment['status'] !== 'published') {
        fail_back('评论不存在。', url('home'));
    }
    $post = post_by_id((int) $comment['post_id'], true);
    if (!$post) {
        fail_back('帖子不存在。', url('home'));
    }
    if ((int) $post['user_id'] !== (int) $user['id'] && !is_admin($user) && !can_moderate_board((int) $post['board_id'], $user)) {
        fail_back('只有帖主或板块管理员可以置顶评论。', url('post', ['id' => (int) $post['id']]));
    }
    $pinned = (int) $comment['is_pinned'] === 1;
    db_exec('UPDATE comments SET is_pinned = 0 WHERE post_id = ?', [(int) $post['id']]);
    if (!$pinned) {
        db_exec('UPDATE comments SET is_pinned = 1 WHERE id = ?', [$commentId]);
    }
    flash('success', $pinned ? '已取消评论置顶。' : '评论已置顶。');
    redirect(url('post', ['id' => (int) $post['id']]) . '#comment-' . $commentId);
}

function action_comment_delete(): void
{
    $user = require_login();
    $commentId = (int) ($_POST['comment_id'] ?? 0);
    $comment = comment_by_id($commentId);
    if (!$comment) {
        fail_back('评论不存在。', url('home'));
    }
    $post = post_by_id((int) $comment['post_id'], true);
    if (!$post) {
        fail_back('帖子不存在。', url('home'));
    }
    $allowed = is_admin($user) || (int) $comment['user_id'] === (int) $user['id'] || (int) $post['user_id'] === (int) $user['id'] || can_moderate_board((int) $post['board_id'], $user);
    if (!$allowed) {
        fail_back('你没有权限删除这条评论。', url('post', ['id' => (int) $post['id']]));
    }
    db_exec('UPDATE comments SET status = "deleted" WHERE id = ? OR parent_id = ?', [$commentId, $commentId]);
    sync_post_counters((int) $post['id']);
    flash('success', '评论已删除。');
    redirect(url('post', ['id' => (int) $post['id']]));
}

function action_profile_save(): void
{
    $user = require_login();
    $bio = trim((string) ($_POST['bio'] ?? ''));
    if (mb_strlen($bio) > 500) {
        fail_back('个人简介不能超过 500 个字符。', url('settings'));
    }
    db_exec(
        'UPDATE users SET bio = ?, show_official_badge = ?, notify_comment = ?, notify_mention = ?, notify_message = ?, notify_system = ?, notify_email = ? WHERE id = ?',
        [
            $bio,
            isset($_POST['show_official_badge']) ? 1 : 0,
            isset($_POST['notify_comment']) ? 1 : 0,
            isset($_POST['notify_mention']) ? 1 : 0,
            isset($_POST['notify_message']) ? 1 : 0,
            isset($_POST['notify_system']) ? 1 : 0,
            isset($_POST['notify_email']) ? 1 : 0,
            (int) $user['id'],
        ]
    );
    refresh_current_user();
    flash('success', '个人资料已保存。');
    redirect(url('settings'));
}

function action_profile_avatar(): void
{
    $user = require_login();
    try {
        $path = upload_image($_FILES['avatar'] ?? [], 'avatar');
    } catch (RuntimeException $e) {
        fail_back($e->getMessage(), url('settings'));
    }
    db_exec('UPDATE users SET avatar = ? WHERE id = ?', [$path, (int) $user['id']]);
    refresh_current_user();
    flash('success', '头像已更新。');
    redirect(url('settings'));
}

function action_profile_password(): void
{
    $user = require_login();
    [$ok, $message] = change_password($user, (string) ($_POST['old_password'] ?? ''), (string) ($_POST['new_password'] ?? ''), (string) ($_POST['new_password_confirm'] ?? ''));
    flash($ok ? 'success' : 'error', $message);
    redirect(url('settings') . '#security');
}

function action_profile_email(): void
{
    $user = require_login();
    [$ok, $message] = change_email($user, (string) ($_POST['email'] ?? ''), (string) ($_POST['password'] ?? ''));
    flash($ok ? 'success' : 'error', $message);
    redirect(url('settings') . '#account');
}

function action_notifications_read(): void
{
    $user = require_login();
    mark_all_notifications_read((int) $user['id']);
    flash('success', '通知已全部标记为已读。');
    redirect(url('notifications'));
}

function action_message_send(): void
{
    $user = require_login();
    $receiverId = (int) ($_POST['receiver_id'] ?? 0);
    $content = trim((string) ($_POST['content'] ?? ''));
    $receiver = db_one("SELECT * FROM users WHERE id = ? AND status = 'active'", [$receiverId]);
    if (!$receiver) {
        fail_back('收信人不存在。', url('messages'));
    }
    if ($receiverId === (int) $user['id']) {
        fail_back('不能给自己发私信。', url('messages'));
    }
    if (mb_strlen($content) < 1 || mb_strlen($content) > 1000) {
        fail_back('私信长度需为 1-1000 个字符。', url('messages', ['with' => $receiverId]));
    }
    db_insert('INSERT INTO messages (sender_id, receiver_id, content) VALUES (?, ?, ?)', [(int) $user['id'], $receiverId, $content]);
    notify_new_message($user, $receiverId, $content);
    redirect(url('messages', ['with' => $receiverId]));
}

function action_verify_apply(): void
{
    $user = require_login();
    $type = (string) ($_POST['type'] ?? '');
    if (!in_array($type, ['user', 'sponsor'], true)) {
        fail_back('认证类型无效。', url('verify'));
    }
    if (db_value("SELECT COUNT(*) FROM verify_applications WHERE user_id = ? AND type = ? AND status = 'pending'", [(int) $user['id'], $type], 0) > 0) {
        fail_back('你已经提交过该认证申请，请耐心等待审核。', url('verify'));
    }
    if ($type === 'user') {
        $minLevel = setting_int('user_verify_min_level', 2);
        if ((int) $user['level'] < $minLevel) {
            fail_back('用户认证需要达到 Lv.' . $minLevel . '。', url('verify'));
        }
    }
    $reason = trim((string) ($_POST['reason'] ?? ''));
    $proof = trim((string) ($_POST['proof'] ?? ''));
    if (mb_strlen($reason) < 5 || mb_strlen($reason) > 1000) {
        fail_back('申请理由需为 5-1000 个字符。', url('verify'));
    }
    if (mb_strlen($proof) > 500) {
        fail_back('补充信息过长。', url('verify'));
    }
    $id = db_insert('INSERT INTO verify_applications (user_id, type, reason, proof) VALUES (?, ?, ?, ?)', [(int) $user['id'], $type, $reason, $proof]);
    foreach (db_all("SELECT id FROM users WHERE role = 'admin' AND status = 'active'") as $admin) {
        notify_user((int) $admin['id'], (int) $user['id'], 'system', $user['username'] . ' 提交了' . ($type === 'sponsor' ? '赞助认证' : '用户认证') . '申请', admin_url('applications', ['id' => $id]));
    }
    flash('success', '申请已提交，请耐心等待审核。');
    redirect(url('verify'));
}

function action_upload_image(): void
{
    $user = require_login();
    if (!can_upload_posts($user)) {
        json_response(['ok' => false, 'message' => '你的账号暂时没有上传图片的权限。'], 403);
    }
    try {
        $path = upload_image($_FILES['image'] ?? [], 'post');
    } catch (RuntimeException $e) {
        json_response(['ok' => false, 'message' => $e->getMessage()], 422);
    }
    json_response(['ok' => true, 'url' => media_url($path)]);
}

function action_resend_verification(): void
{
    $user = require_login();
    if (!rate_limit('resend_verify_' . $user['id'], 3, 600)) {
        fail_back('发送过于频繁，请十分钟后再试。', url('verify_email'));
    }
    if (!empty($user['email_verified_at'])) {
        flash('info', '你的邮箱已经验证过了。');
        redirect(url('settings'));
    }
    [$ok, $message] = send_email_verification((int) $user['id']);
    flash($ok ? 'success' : 'error', $ok ? '验证邮件已发送，请查收。' : $message);
    redirect(url('verify_email'));
}

function action_forgot_password(): void
{
    if (!rate_limit('forgot_password', 5, 600)) {
        fail_back('请求过于频繁，请稍后再试。', url('forgot_password'));
    }
    [$ok, $message] = request_password_reset((string) ($_POST['email'] ?? ''));
    flash($ok ? 'success' : 'error', $message);
    redirect(url('forgot_password'));
}

function action_reset_password(): void
{
    $token = (string) ($_POST['token'] ?? '');
    [$ok, $message] = reset_password_with_token($token, (string) ($_POST['password'] ?? ''), (string) ($_POST['password_confirm'] ?? ''));
    if (!$ok) {
        fail_back($message, url('reset_password', ['token' => $token]));
    }
    flash('success', $message);
    redirect(url('login'));
}

function action_announcement_seen(): void
{
    $id = (int) ($_POST['id'] ?? 0);
    $user = current_user();
    if ($id > 0 && $user) {
        db_exec(
            'INSERT INTO announcement_views (announcement_id, user_id, last_seen_date, seen_at)
             VALUES (?, ?, CURDATE(), NOW())
             ON DUPLICATE KEY UPDATE last_seen_date = VALUES(last_seen_date), seen_at = NOW()',
            [$id, (int) $user['id']]
        );
    }
    if (is_ajax()) {
        json_response(['ok' => true]);
    }
    redirect_back('home');
}
