<?php ?>
<section class="about-hero">
    <div class="about-hero__glow"></div>
    <span class="page-head__eyebrow">About</span>
    <h1>关于 <?= e(setting('site_name')) ?></h1>
    <p><?= e(setting('site_tagline')) ?></p>
    <div class="about-hero__stats">
        <span><strong><?= short_number($stats['users']) ?></strong>成员</span>
        <span><strong><?= short_number($stats['posts']) ?></strong>文章</span>
        <span><strong><?= short_number($stats['comments']) ?></strong>评论</span>
        <span><strong><?= short_number($stats['today_checkins']) ?></strong>今日签到</span>
    </div>
</section>

<div class="about-layout">
    <article class="panel prose about-content">
        <?= render_content(setting('about_content', '<p>关于页面还没有填写。</p>')) ?>
    </article>
    <aside class="about-side">
        <section class="side-card">
            <div class="side-card__head"><h2>社区一览</h2></div>
            <div class="about-facts">
                <div><span>在线成员</span><strong><?= (int) $stats['online'] ?></strong></div>
                <div><span>今日新文章</span><strong><?= (int) $stats['today_posts'] ?></strong></div>
                <div><span>今日签到</span><strong><?= (int) $stats['today_checkins'] ?></strong></div>
                <div><span>开源免费</span><strong>Yes</strong></div>
            </div>
        </section>
        <section class="side-card">
            <div class="side-card__head"><h2>此刻在线</h2></div>
            <div class="online-list">
                <?php foreach ($online as $onlineUser): ?>
                    <a class="online-user" href="<?= e(url('user', ['id' => (int) $onlineUser['id']])) ?>" title="<?= e($onlineUser['username']) ?>">
                        <img class="avatar avatar--sm" src="<?= e(avatar_url($onlineUser)) ?>" alt="<?= e($onlineUser['username']) ?>"><span></span>
                    </a>
                <?php endforeach; ?>
                <?php if (!$online): ?><p class="muted-text">此刻还没有人在线。</p><?php endif; ?>
            </div>
        </section>
        <section class="side-card">
            <div class="side-card__head"><h2>加入我们</h2></div>
            <p class="muted-text">注册账号，签到最后一级，分享你的第一篇内容。</p>
            <a class="btn btn--primary btn--full" href="<?= e(current_user() ? url('me') : url('register')) ?>"><?= current_user() ? '回到我的主页' : '创建账号' ?></a>            <a class="btn btn--text btn--full" href="<?= e(url('links')) ?>">看看友链</a>
        </section>
    </aside>
</div>
