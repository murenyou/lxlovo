<?php
$typeLabels = ['official' => '官方认证', 'user' => '用户认证', 'sponsor' => '赞助认证'];
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Identity</span><h2>认证配置</h2><p>认证名称、颜色、说明和申请条件都可以自定义。官方认证支持多个并存。</p></div></div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>新增认证</h3></div>
    <form action="<?= e(admin_url('cert.save')) ?>" method="post" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">认证标识</span><span class="field__box"><input type="text" name="code" placeholder="例如 creator" pattern="[a-z0-9_-]{2,40}" required></span></label>
            <label class="field"><span class="field__label">显示名称</span><span class="field__box"><input type="text" name="name" maxlength="40" required></span></label>
            <label class="field"><span class="field__label">类型</span><span class="field__box field__box--select"><select name="type"><?php foreach ($typeLabels as $key => $label): ?><option value="<?= $key ?>"><?= $label ?></option><?php endforeach; ?></select></span></label>
            <label class="field"><span class="field__label">颜色</span><span class="field__box field__box--color"><input type="color" name="color" value="#1A73E8"></span></label>
            <label class="field field--span-2"><span class="field__label">简短说明</span><span class="field__box"><input type="text" name="description" maxlength="255"></span></label>
            <label class="field field--span-2"><span class="field__label">申请条件</span><span class="field__box field__box--textarea"><textarea name="conditions" rows="3" placeholder="展示在认证申请页面的条件说明"></textarea></span></label>
            <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="50"></span></label>
            <label class="check-line"><input type="checkbox" name="enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">添加认证</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <span class="verify-badge verify-badge--<?= e($item['type']) ?>" style="--badge-color:<?= e($item['color']) ?>"><?= icon('verified') ?><span><?= e($item['name']) ?></span></span>
                <div><h3><?= e($item['name']) ?></h3><p><?= e($typeLabels[$item['type']] ?? $item['type']) ?> · <?= e($item['code']) ?> · <?= (int) ($counts[(int) $item['id']] ?? 0) ?> 位用户</p></div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('cert.save')) ?>" method="post" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">认证标识</span><span class="field__box"><input type="text" name="code" value="<?= e($item['code']) ?>" pattern="[a-z0-9_-]{2,40}" required></span></label>
                                <label class="field"><span class="field__label">显示名称</span><span class="field__box"><input type="text" name="name" value="<?= e($item['name']) ?>" maxlength="40" required></span></label>
                                <label class="field"><span class="field__label">类型</span><span class="field__box field__box--select"><select name="type"><?php foreach ($typeLabels as $key => $label): ?><option value="<?= $key ?>" <?= $item['type'] === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></span></label>
                                <label class="field"><span class="field__label">颜色</span><span class="field__box field__box--color"><input type="color" name="color" value="<?= e($item['color']) ?>"></span></label>
                                <label class="field field--span-2"><span class="field__label">简短说明</span><span class="field__box"><input type="text" name="description" value="<?= e($item['description']) ?>" maxlength="255"></span></label>
                                <label class="field field--span-2"><span class="field__label">申请条件</span><span class="field__box field__box--textarea"><textarea name="conditions" rows="3"><?= e($item['conditions']) ?></textarea></span></label>
                                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) $item['sort'] ?>"></span></label>
                                <label class="check-line"><input type="checkbox" name="enabled" value="1" <?= $item['enabled'] ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('cert.delete')) ?>" method="post" data-confirm="删除后所有用户身上的该认证也会被移除，确定吗？" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
