package com.bbs.lxlovo.top.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Article
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Forum
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.Login
import androidx.compose.material.icons.outlined.Logout
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.BuildConfig
import com.bbs.lxlovo.top.data.AppPrefs
import com.bbs.lxlovo.top.data.User
import com.bbs.lxlovo.top.ui.LxlovoAvatar
import com.bbs.lxlovo.top.util.openUrl

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    prefs: AppPrefs,
    user: User?,
    checking: Boolean,
    snackbarHostState: SnackbarHostState,
    onBack: () -> Unit,
    onLogin: () -> Unit,
    onLogout: () -> Unit,
    onAccount: () -> Unit,
    onFavorites: () -> Unit,
    onMyPosts: () -> Unit,
    onBoards: () -> Unit,
    onOnline: () -> Unit,
    onAbout: () -> Unit,
    onCheckUpdate: () -> Unit,
    onOpenLog: () -> Unit,
) {
    val context = LocalContext.current
    var inAppBrowser by remember { mutableStateOf(prefs.useInAppBrowser) }
    var logoutDialog by remember { mutableStateOf(false) }

    BackHandler(onBack = onBack)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("设置") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item { SectionTitle("账号") }
            item {
                SettingsCard {
                    if (user == null) {
                        ListItem(
                            headlineContent = { Text("登录 / 注册") },
                            supportingContent = { Text("登录后可发帖、评论、签到和私信") },
                            leadingContent = { Icon(Icons.Outlined.Login, contentDescription = null) },
                            trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                            modifier = Modifier.clickable(onClick = onLogin),
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                    } else {
                        ListItem(
                            headlineContent = { Text(user.username) },
                            supportingContent = {
                                Text(if (user.email.isNotBlank()) user.email else "Lv.${user.level} ${user.levelName}")
                            },
                            leadingContent = { LxlovoAvatar(user, 40) },
                            trailingContent = {
                                TextButton(onClick = { logoutDialog = true }) { Text("退出登录") }
                            },
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        ListItem(
                            headlineContent = { Text("账号与安全") },
                            supportingContent = { Text("头像、邮箱、密码、认证与通知偏好") },
                            leadingContent = { Icon(Icons.Outlined.Person, contentDescription = null) },
                            trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                            modifier = Modifier.clickable(onClick = onAccount),
                            colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                        )
                    }
                }
            }

            item { SectionTitle("社区") }
            item {
                SettingsCard {
                    ListItem(
                        headlineContent = { Text("我的收藏") },
                        supportingContent = { Text("收藏过的文章") },
                        leadingContent = { Icon(Icons.Outlined.FavoriteBorder, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onFavorites),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("我的文章") },
                        supportingContent = { Text("管理自己发布的文章") },
                        leadingContent = { Icon(Icons.Outlined.Article, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onMyPosts),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("论坛板块") },
                        supportingContent = { Text("浏览全部板块") },
                        leadingContent = { Icon(Icons.Outlined.Forum, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onBoards),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("在线用户") },
                        supportingContent = { Text("看看谁正在社区里") },
                        leadingContent = { Icon(Icons.Outlined.People, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onOnline),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("关于 lxlovo") },
                        supportingContent = { Text("社区介绍、数据与友情链接") },
                        leadingContent = { Icon(Icons.Outlined.Info, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onAbout),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                }
            }

            item { SectionTitle("浏览") }
            item {
                SettingsCard {
                    ListItem(
                        headlineContent = { Text("使用内置浏览器") },
                        supportingContent = {
                            Text("站外链接和更新页面优先在 App 内打开；关闭后使用系统浏览器。")
                        },
                        trailingContent = {
                            Switch(
                                checked = inAppBrowser,
                                onCheckedChange = {
                                    inAppBrowser = it
                                    prefs.useInAppBrowser = it
                                },
                            )
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                }
            }

            item { SectionTitle("更新") }
            item {
                SettingsCard {
                    ListItem(
                        headlineContent = { Text("检查更新") },
                        supportingContent = { Text("当前版本 ${BuildConfig.VERSION_NAME}") },
                        leadingContent = { Icon(Icons.Outlined.Refresh, contentDescription = null) },
                        trailingContent = {
                            if (checking) {
                                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null)
                            }
                        },
                        modifier = Modifier.clickable(enabled = !checking, onClick = onCheckUpdate),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("更新日志") },
                        supportingContent = { Text("查看全部版本与累计更新内容") },
                        leadingContent = { Icon(Icons.Outlined.Article, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable(onClick = onOpenLog),
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                }
            }

            item { SectionTitle("关于") }
            item {
                SettingsCard {
                    ListItem(
                        headlineContent = { Text("lxlovo") },
                        supportingContent = { Text("开放、自由、原创的中文社区") },
                        leadingContent = { Icon(Icons.Outlined.Info, contentDescription = null) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("版本") },
                        trailingContent = { Text(BuildConfig.VERSION_NAME) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    ListItem(
                        headlineContent = { Text("包名") },
                        trailingContent = { Text(BuildConfig.APPLICATION_ID) },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    ListItem(
                        headlineContent = { Text("访问官网") },
                        supportingContent = { Text(BuildConfig.SITE_URL) },
                        leadingContent = { Icon(Icons.Outlined.Language, contentDescription = null) },
                        trailingContent = { Icon(Icons.Outlined.KeyboardArrowRight, contentDescription = null) },
                        modifier = Modifier.clickable {
                            openUrl(context, BuildConfig.SITE_URL, inAppBrowser)
                        },
                        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                    )
                }
            }

            item {
                Spacer(Modifier.height(10.dp))
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally,
                ) {
                    Text(
                        "lxlovo by 夭获",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Text(
                        "完全开源 · 完全免费",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline,
                    )
                }
            }
        }
    }

    if (logoutDialog) {
        AlertDialog(
            onDismissRequest = { logoutDialog = false },
            title = { Text("退出登录") },
            text = { Text("退出后需要重新登录才能发帖、评论和签到。") },
            confirmButton = {
                TextButton(onClick = {
                    logoutDialog = false
                    onLogout()
                }) {
                    Text("退出", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { logoutDialog = false }) { Text("取消") }
            },
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 4.dp, top = 8.dp),
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow,
        ),
    ) {
        Column { content() }
    }
}
