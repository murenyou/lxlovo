<?php ?>
<div class="admin-page-head">
    <div><span class="admin-eyebrow">Overview</span><h2>今天也在好好运转</h2><p>这里是 <?= e(setting('site_name')) ?> 的实时概览。</p></div>
    <div class="admin-page-head__actions">
        <a class="btn btn--tonal btn--sm" href="<?= e(url('home')) ?>" target="_blank"><?= icon('external', '', 17) ?>访问前台</a>
        <a class="btn btn--primary btn--sm" href="<?= e(admin_url('broadcast')) ?>"><?= icon('send', '', 17) ?>发广播</a>
    </div>
</div>

<?php if (!email_configured()): ?>
    <div class="notice notice--warning"><?= icon('mail', '', 20) ?>SMTP 尚未配置，邮箱验证与邮件提醒暂时不可用。<a href="<?= e(admin_url('settings') . '#email') ?>">去配置</a></div>
<?php endif; ?>

<div class="admin-stat-grid">
    <div class="admin-stat"><span class="admin-stat__icon admin-stat__icon--violet"><?= icon('users') ?></span><div><strong><?= short_number($stats['users']) ?></strong><span>注册用户</span><small>今日 +<?= (int) $stats['today_users'] ?></small></div></div>
    <div class="admin-stat"><span class="admin-stat__icon admin-stat__icon--green"><?= icon('article') ?></span><div><strong><?= short_number($stats['posts']) ?></strong><span>帖子总数</span><small>今日 +<?= (int) $stats['today_posts'] ?></small></div></div>
    <div class="admin-stat"><span class="admin-stat__icon admin-stat__icon--orange"><?= icon('comment') ?></span><div><strong><?= short_number($stats['comments']) ?></strong><span>评论总数</span><small><?= (int) $stats['today_checkins'] ?> 人今日签到</small></div></div>
    <div class="admin-stat"><span class="admin-stat__icon admin-stat__icon--blue"><?= icon('shield') ?></span><div><strong><?= short_number($stats['pending']) ?></strong><span>待审认证</span><small><?= (int) $stats['online'] ?> 人在线</small></div></div>
</div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>最近注册</h3><a href="<?= e(admin_url('users')) ?>">全部用户</a></div>
        <div class="admin-list">
            <?php foreach ($recentUsers as $item): ?>
                <a class="admin-list__item" href="<?= e(admin_url('user', ['id' => (int) $item['id']])) ?>">
                    <img class="avatar avatar--sm" src="<?= e(avatar_url($item)) ?>" alt="">
                    <span class="admin-list__body"><strong><?= e($item['username']) ?> <?= badge_html((int) $item['id'], $item) ?></strong><span>#<?= (int) $item['id'] ?> · Lv.<?= (int) $item['level'] ?> · <?= e($item['email'] ?: '未绑定邮箱') ?></span></span>
                    <time><?= e(time_ago($item['created_at'])) ?></time>
                </a>
            <?php endforeach; ?>
            <?php if (!$recentUsers): ?><p class="admin-empty">暂无用户。</p><?php endif; ?>
        </div>
    </section>

    <section class="admin-panel">
        <div class="admin-panel__head"><h3>等待审核</h3><a href="<?= e(admin_url('applications')) ?>">全部申请</a></div>
        <div class="admin-list">
            <?php foreach ($recentApplications as $application): ?>
                <a class="admin-list__item" href="<?= e(admin_url('applications')) ?>">
                    <img class="avatar avatar--sm" src="<?= e(avatar_url($application)) ?>" alt="">
                    <span class="admin-list__body"><strong><?= e($application['username']) ?></strong><span><?= $application['type'] === 'sponsor' ? '赞助认证' : '用户认证' ?> · <?= e(text_excerpt($application['reason'], 40)) ?></span></span>
                    <span class="status-chip status-chip--warning">待审核</span>
                </a>
            <?php endforeach; ?>
            <?php if (!$recentApplications): ?><p class="admin-empty">没有待审核的申请。</p><?php endif; ?>
        </div>
    </section>
</div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>最新帖子</h3><a href="<?= e(admin_url('posts')) ?>">管理帖子</a></div>
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>标题</th><th>板块</th><th>作者</th><th>数据</th><th>状态</th><th>时间</th></tr></thead>
            <tbody>
            <?php foreach ($recentPosts as $post): ?>
                <tr>
                    <td><a class="table-title" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>" target="_blank"><?= e($post['title']) ?></a></td>
                    <td><?= e($post['board_name']) ?></td>
                    <td><?= e($post['username']) ?></td>
                    <td><?= (int) $post['views'] ?> 阅 · <?= (int) $post['likes_count'] ?> 赞</td>
                    <td>
                        <?php if ((int) $post['is_pinned'] === 1): ?><span class="chip chip--pin">置顶</span><?php endif; ?>
                        <?php if ((int) $post['is_featured'] === 1): ?><span class="chip chip--feature">精选</span><?php endif; ?>
                        <span class="status-chip status-chip--<?= $post['status'] === 'published' ? 'success' : 'neutral' ?>"><?= $post['status'] === 'published' ? '已发布' : $post['status'] ?></span>
                    </td>
                    <td><?= e(time_ago($post['created_at'])) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="admin-quick">
    <a href="<?= e(admin_url('board')) ?>"><?= icon('add', '', 20) ?><span>新建板块</span></a>
    <a href="<?= e(admin_url('carousels')) ?>"><?= icon('image', '', 20) ?><span>管理轮播</span></a>
    <a href="<?= e(admin_url('certifications')) ?>"><?= icon('verified', '', 20) ?><span>认证配置</span></a>
    <a href="<?= e(admin_url('settings')) ?>"><?= icon('settings', '', 20) ?><span>站点设置</span></a>
</div>
