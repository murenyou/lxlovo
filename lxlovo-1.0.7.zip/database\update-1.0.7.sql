-- lxlovo 1.0.7 升级脚本
-- 适用于已有 1.0.4 / 1.0.5 / 1.0.6 站点；全新安装直接导入 install.sql。

USE `bbs_lxlovo_top`;

CREATE TABLE IF NOT EXISTS `app_releases` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `version_name` VARCHAR(40) NOT NULL,
  `version_code` INT UNSIGNED NOT NULL,
  `download_url` VARCHAR(1000) NOT NULL DEFAULT '',
  `download_mode` ENUM('auto','direct','page') NOT NULL DEFAULT 'auto',
  `is_forced` TINYINT(1) NOT NULL DEFAULT 0,
  `changelog` TEXT,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_version_code` (`version_code`),
  KEY `idx_enabled_code` (`is_enabled`,`version_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_name` VARCHAR(120) NOT NULL DEFAULT '',
  `last_used_at` DATETIME DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token_hash` (`token_hash`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `settings` (`skey`,`svalue`) VALUES
('app_inapp_browser_default','1');

INSERT IGNORE INTO `app_releases`
(`version_name`,`version_code`,`download_url`,`download_mode`,`is_forced`,`changelog`,`is_enabled`,`published_at`) VALUES
('1.0.5',105,'https://bbs.lxlovo.top/download/lxlovo-1.0.5.apk','auto',0,'首个 Android 客户端版本。\n\n- 使用 Material Design 3 组件构建\n- 支持应用内更新检测、强制更新与下载进度\n- 支持内置浏览器与更新日志',1,NOW()),
('1.0.6',106,'https://bbs.lxlovo.top/download/lxlovo-1.0.6.apk','auto',0,'原生 Android 重写版本。\n\n- 移除论坛网页套壳，全部页面改为原生 Jetpack Compose\n- 原生首页、文章列表、文章详情、评论、发帖与搜索\n- 原生登录注册、个人主页、签到、通知与私信\n- 原生设置、更新日志、内置浏览器与下载进度\n- 保留后台 App 版本管理',1,NOW()),
('1.0.7',107,'https://bbs.lxlovo.top/download/lxlovo-1.0.7.apk','auto',0,'原生功能补齐与体验升级。\n\n- 新增账号与安全：头像上传、修改密码、更换邮箱、邮箱验证状态、通知偏好\n- 新增认证中心：用户认证、赞助认证申请与申请记录\n- 新增帖子编辑、删除、封面图、精华设置\n- 新增评论置顶与评论删除\n- 新增我的收藏、我的文章、板块列表、在线用户、关于页面\n- 新增随机推荐、轮播自动播放、骨架屏与页面转场动画\n- 优化点赞动效、评论回复动画与整体交互',1,NOW());
