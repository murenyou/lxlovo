<?php ?>
<section class="auth-shell">
    <div class="auth-art auth-art--register">
        <div class="auth-art__glow auth-art__glow--one"></div>
        <div class="auth-art__glow auth-art__glow--two"></div>
        <a class="brand brand--auth" href="<?= e(url('home')) ?>"><span class="brand__glyph">l</span><span class="brand__text"><?= e(setting('site_name')) ?></span></a>
        <div class="auth-art__copy">
            <span class="page-head__eyebrow">Join the community</span>
            <h1>从这里开始，<br>留下你的第一句话。</h1>
            <p>注册账号，签到升级，认识同频的人。</p>
        </div>
        <ul class="auth-features">
            <li><?= icon('check', '', 17) ?>完全免费，开源开放</li>
            <li><?= icon('check', '', 17) ?>12 个等级，见证成长</li>
            <li><?= icon('check', '', 17) ?>帖子、私信与认证体系</li>
        </ul>
    </div>
    <div class="auth-card">
        <div class="auth-card__head">
            <span class="page-head__eyebrow">Create account</span>
            <h2>注册 <?= e(setting('site_name')) ?></h2>
            <p>第一个账号的 ID 为 1，之后依次递增。</p>
        </div>
        <?php if ($closed): ?>
            <div class="notice notice--warning"><?= icon('lock', '', 20) ?>站点暂时关闭了注册，请稍后再来。</div>
            <a class="btn btn--primary btn--full" href="<?= e(url('login')) ?>">已有账号，去登录</a>
        <?php else: ?>
            <form action="<?= e(url('register')) ?>" method="post" class="form-stack">
                <?= csrf_field() ?>
                <label class="field">
                    <span class="field__label">用户名</span>
                    <span class="field__box"><?= icon('person') ?><input type="text" name="username" value="<?= e(old('username')) ?>" autocomplete="username" minlength="2" maxlength="32" placeholder="2-32 位中文、字母或数字" required autofocus></span>
                    <span class="field__hint">用户名将展示在你的文章与评论旁。</span>
                </label>
                <label class="field">
                    <span class="field__label">邮箱</span>
                    <span class="field__box"><?= icon('mail') ?><input type="email" name="email" value="<?= e(old('email')) ?>" autocomplete="email" placeholder="you@example.com" required></span>
                    <span class="field__hint">用于邮箱验证、密码找回与重要提醒。</span>
                </label>
                <div class="form-two">
                    <label class="field">
                        <span class="field__label">密码</span>
                        <span class="field__box"><?= icon('lock') ?><input type="password" name="password" autocomplete="new-password" minlength="8" maxlength="72" placeholder="至少 8 位" required></span>
                    </label>
                    <label class="field">
                        <span class="field__label">确认密码</span>
                        <span class="field__box"><?= icon('check') ?><input type="password" name="password_confirm" autocomplete="new-password" minlength="8" maxlength="72" placeholder="再次输入" required></span>
                    </label>
                </div>
                <?php if (setting_bool('email_verify_required')): ?>
                    <p class="form-note"><?= icon('mail', '', 16) ?>注册后需要完成邮箱验证才能发帖与评论。</p>
                <?php endif; ?>
                <button class="btn btn--primary btn--full" type="submit">创建账号</button>
            </form>
            <p class="auth-switch">已经有账号？<a href="<?= e(url('login')) ?>">去登录</a></p>
        <?php endif; ?>
        <a class="auth-back" href="<?= e(url('home')) ?>"><?= icon('arrow_back', '', 16) ?>返回首页</a>
    </div>
</section>
