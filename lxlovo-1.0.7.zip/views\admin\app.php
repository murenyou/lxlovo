<?php
$versionParts = array_pad(array_map('intval', explode('.', LXL_VERSION)), 3, 0);
$versionCode = $versionParts[0] * 100 + $versionParts[1] * 10 + $versionParts[2];
$maxReleaseCode = 0;
foreach ($releases as $releaseRow) {
    $maxReleaseCode = max($maxReleaseCode, (int) $releaseRow['version_code']);
}
$suggestedParts = array_pad(array_map('intval', explode('.', $latest['version_name'] ?? LXL_VERSION)), 3, 0);
if ($latest) {
    $suggestedParts[2]++;
    $suggestedName = implode('.', $suggestedParts);
} else {
    $suggestedName = LXL_VERSION;
}
$suggestedCode = max($versionCode, $maxReleaseCode + 1);
$modeLabels = ['auto' => '自动判断', 'direct' => '直链下载', 'page' => '网页 / 下载页'];
$apiUrl = absolute_url('api.php') . '?action=app.version';
?>
<div class="admin-page-head">
    <div><span class="admin-eyebrow">Android</span><h2>App 管理</h2><p>管理纯原生 lxlovo Android 客户端的版本、更新链接、强制更新与累计更新日志。</p></div>
    <a class="btn btn--tonal btn--sm" href="<?= e($apiUrl) ?>" target="_blank"><?= icon('external', '', 17) ?>查看更新接口</a>
</div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>当前版本</h3><span>与网站版本 <?= e(LXL_VERSION) ?> 同步</span></div>
        <?php if ($latest): ?>
            <div class="admin-app-current">
                <span class="admin-app-current__icon"><?= icon('phone', '', 26) ?></span>
                <div>
                    <strong>lxlovo <?= e($latest['version_name']) ?></strong>
                    <span>versionCode <?= (int) $latest['version_code'] ?> · <?= $latest['is_forced'] ? '强制更新' : '普通更新' ?> · <?= (int) $latest['is_enabled'] === 1 ? '已启用' : '已停用' ?></span>
                </div>
                <span class="status-chip status-chip--success">当前</span>
            </div>
            <div class="admin-kv"><span>下载地址</span><strong class="break-text"><?= e($latest['download_url']) ?></strong></div>
            <div class="admin-kv"><span>下载方式</span><strong><?= e($modeLabels[$latest['download_mode']] ?? $latest['download_mode']) ?></strong></div>
            <div class="admin-kv"><span>发布时间</span><strong><?= e(format_date($latest['published_at'], 'Y-m-d H:i')) ?></strong></div>
        <?php else: ?>
            <div class="admin-empty">还没有启用中的 App 版本，请先在下方发布。</div>
        <?php endif; ?>
    </section>

    <section class="admin-panel">
        <div class="admin-panel__head"><h3>客户端设置</h3></div>
        <form action="<?= e(admin_url('app.settings.save')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <div class="switch-row">
                <div><strong>默认使用内置浏览器</strong><p>App 首次启动时默认开启。用户仍可在 App 设置中自行关闭；关闭后站外链接与更新页面会跳转系统浏览器。</p></div>
                <label class="switch"><input type="checkbox" name="app_inapp_browser_default" value="1" <?= ($settings['app_inapp_browser_default'] ?? '1') === '1' ? 'checked' : '' ?>><span></span></label>
            </div>
            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存 App 设置</button></div>
        </form>
        <div class="admin-note admin-note--small">
            <p><strong>包名</strong> com.bbs.lxlovo.top</p>
            <p><strong>更新接口</strong> <span class="break-text"><?= e($apiUrl) ?></span></p>
        </div>
    </section>
</div>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>发布新版本</h3><span>版本代码必须递增</span></div>
    <form action="<?= e(admin_url('app.release.save')) ?>" method="post" class="admin-form">
        <?= csrf_field() ?>
        <div class="admin-form-grid">
            <label class="field"><span class="field__label">版本名称</span><span class="field__box"><input type="text" name="version_name" value="<?= e($suggestedName) ?>" maxlength="40" required></span></label>
            <label class="field"><span class="field__label">版本代码</span><span class="field__box"><input type="number" name="version_code" value="<?= (int) $suggestedCode ?>" min="1" required></span><span class="field__hint">必须大于当前版本，例如 1.0.7 → 107。</span></label>
            <label class="field field--span-2"><span class="field__label">更新链接</span><span class="field__box"><input type="url" name="download_url" placeholder="https://bbs.lxlovo.top/download/lxlovo-1.0.7.apk" required></span></label>
            <label class="field"><span class="field__label">下载方式</span><span class="field__box field__box--select"><select name="download_mode"><?php foreach ($modeLabels as $key => $label): ?><option value="<?= $key ?>"><?= $label ?></option><?php endforeach; ?></select></span><span class="field__hint">自动：.apk 结尾视为直链。</span></label>
            <label class="field"><span class="field__label">发布时间</span><span class="field__box"><input type="datetime-local" name="published_at" value="<?= e(date('Y-m-d\TH:i')) ?>"></span></label>
            <label class="field field--span-2"><span class="field__label">本次更新内容</span><span class="field__box field__box--textarea"><textarea name="changelog" rows="5" placeholder="每行一条更新内容，App 会按版本累计展示。"></textarea></span></label>
            <label class="check-line"><input type="checkbox" name="is_forced" value="1"><span>强制更新</span></label>
            <label class="check-line"><input type="checkbox" name="is_enabled" value="1" checked><span>启用</span></label>
        </div>
        <div class="form-actions"><button class="btn btn--primary" type="submit">发布版本</button></div>
    </form>
</section>

<div class="admin-stack">
    <?php foreach ($releases as $release): ?>
        <section class="admin-panel admin-edit-row">
            <div class="admin-edit-row__head">
                <span class="admin-edit-row__icon"><?= icon('phone', '', 22) ?></span>
                <div>
                    <h3>lxlovo <?= e($release['version_name']) ?> <span class="chip chip--soft">code <?= (int) $release['version_code'] ?></span></h3>
                    <p><?= e($modeLabels[$release['download_mode']] ?? $release['download_mode']) ?> · <?= e(time_ago($release['published_at'])) ?> · <?= (int) $release['is_enabled'] === 1 ? '启用中' : '已停用' ?></p>
                </div>
                <div class="chip-row">
                    <?php if ((int) $release['is_forced'] === 1): ?><span class="status-chip status-chip--danger">强制</span><?php endif; ?>
                    <span class="status-chip status-chip--<?= (int) $release['is_enabled'] === 1 ? 'success' : 'neutral' ?>"><?= (int) $release['is_enabled'] === 1 ? '启用' : '停用' ?></span>
                </div>
                <details class="admin-disclosure"><summary class="btn btn--tonal btn--sm">编辑</summary>
                    <div class="admin-disclosure__body">
                        <form action="<?= e(admin_url('app.release.save')) ?>" method="post" class="admin-form">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $release['id'] ?>">
                            <div class="admin-form-grid">
                                <label class="field"><span class="field__label">版本名称</span><span class="field__box"><input type="text" name="version_name" value="<?= e($release['version_name']) ?>" maxlength="40" required></span></label>
                                <label class="field"><span class="field__label">版本代码</span><span class="field__box"><input type="number" name="version_code" value="<?= (int) $release['version_code'] ?>" min="1" required></span></label>
                                <label class="field field--span-2"><span class="field__label">更新链接</span><span class="field__box"><input type="url" name="download_url" value="<?= e($release['download_url']) ?>" required></span></label>
                                <label class="field"><span class="field__label">下载方式</span><span class="field__box field__box--select"><select name="download_mode"><?php foreach ($modeLabels as $key => $label): ?><option value="<?= $key ?>" <?= $release['download_mode'] === $key ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></span></label>
                                <label class="field"><span class="field__label">发布时间</span><span class="field__box"><input type="datetime-local" name="published_at" value="<?= e(date('Y-m-d\TH:i', strtotime($release['published_at']))) ?>"></span></label>
                                <label class="field field--span-2"><span class="field__label">更新内容</span><span class="field__box field__box--textarea"><textarea name="changelog" rows="5"><?= e($release['changelog']) ?></textarea></span></label>
                                <label class="check-line"><input type="checkbox" name="is_forced" value="1" <?= (int) $release['is_forced'] === 1 ? 'checked' : '' ?>><span>强制更新</span></label>
                                <label class="check-line"><input type="checkbox" name="is_enabled" value="1" <?= (int) $release['is_enabled'] === 1 ? 'checked' : '' ?>><span>启用</span></label>
                            </div>
                            <div class="form-actions"><button class="btn btn--primary btn--sm" type="submit">保存修改</button></div>
                        </form>
                        <form action="<?= e(admin_url('app.release.delete')) ?>" method="post" data-confirm="确定删除这个版本记录吗？已安装该版本的用户不会受到影响。" class="admin-delete-form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $release['id'] ?>"><button class="btn btn--danger btn--sm" type="submit">删除记录</button></form>
                    </div>
                </details>
            </div>
        </section>
    <?php endforeach; ?>
</div>
<?php if (!$releases): ?><div class="admin-empty">还没有 App 版本记录。</div><?php endif; ?>

<section class="admin-panel">
    <div class="admin-panel__head"><h3>更新规则</h3></div>
    <div class="admin-note">
        <p>App 会在启动时请求更新接口，并在设置中提供手动检查更新。</p>
        <p>普通更新可以点击「下次更新」暂缓；强制更新会禁用关闭按钮，必须完成更新。</p>
        <p>更新内容按版本累计展示，设置中的「更新日志」会显示全部启用版本。</p>
        <p>直链下载会在 App 内显示下载进度；网页链接会使用内置浏览器，用户关闭内置浏览器后改用系统浏览器。</p>
    </div>
</section>
