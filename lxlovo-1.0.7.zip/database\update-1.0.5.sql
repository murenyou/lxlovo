-- lxlovo 1.0.5 升级脚本
-- 已有站点升级时执行一次；全新安装直接导入 install.sql 即可。

USE `bbs_lxlovo_top`;

CREATE TABLE IF NOT EXISTS `app_releases` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `version_name` VARCHAR(40) NOT NULL,
  `version_code` INT UNSIGNED NOT NULL,
  `download_url` VARCHAR(1000) NOT NULL DEFAULT '',
  `download_mode` ENUM('auto','direct','page') NOT NULL DEFAULT 'auto',
  `is_forced` TINYINT(1) NOT NULL DEFAULT 0,
  `changelog` TEXT,
  `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
  `published_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_version_code` (`version_code`),
  KEY `idx_enabled_code` (`is_enabled`,`version_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `app_tokens` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `token_hash` CHAR(64) NOT NULL,
  `device_name` VARCHAR(120) NOT NULL DEFAULT '',
  `last_used_at` DATETIME DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token_hash` (`token_hash`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO `settings` (`skey`,`svalue`) VALUES
('app_inapp_browser_default','1');

INSERT IGNORE INTO `app_releases` (`id`,`version_name`,`version_code`,`download_url`,`download_mode`,`is_forced`,`changelog`,`is_enabled`,`published_at`) VALUES
(1,'1.0.5',105,'https://bbs.lxlovo.top/download/lxlovo-1.0.5.apk','auto',0,'lxlovo Android 客户端首个版本。\n\n- 使用 Material Design 3 组件构建\n- 接入 lxlovo 论坛全部网页功能\n- 支持应用内更新检测、强制更新与下载进度\n- 支持内置浏览器与更新日志',1,NOW());
