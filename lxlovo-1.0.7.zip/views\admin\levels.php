<?php ?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Growth</span><h2>用户等级</h2><p>经验值区间与等级名称可调整，保存后会重新计算所有用户等级。</p></div></div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>新增等级</h3></div>
        <form action="<?= e(admin_url('level.save')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="0">
            <div class="admin-form-grid">
                <label class="field"><span class="field__label">等级数字</span><span class="field__box"><input type="number" name="level" min="0" max="99" required></span></label>
                <label class="field"><span class="field__label">等级名称</span><span class="field__box"><input type="text" name="name" maxlength="40" required></span></label>
                <label class="field"><span class="field__label">最低经验</span><span class="field__box"><input type="number" name="min_exp" min="0" value="0" required></span></label>
                <label class="field"><span class="field__label">最高经验</span><span class="field__box"><input type="number" name="max_exp" min="0" placeholder="留空表示无上限"></span></label>
                <label class="field"><span class="field__label">颜色</span><span class="field__box field__box--color"><input type="color" name="color" value="#6750A4"></span></label>
            </div>
            <div class="form-actions"><button class="btn btn--primary" type="submit">添加等级</button></div>
        </form>
    </section>
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>默认等级说明</h3></div>
        <div class="admin-note">
            <p>新注册用户默认 Lv.0，第一次签到获得 3 点经验后进入 Lv.1，成为正式用户。</p>
            <p>经验值按累计值计算，等级区间只用于判定当前等级；达到最高等级后继续累积经验。</p>
        </div>
    </section>
</div>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <form action="<?= e(admin_url('level.save')) ?>" method="post" class="level-row">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                <span class="level-row__badge" style="--level-color:<?= e($item['color']) ?>">Lv.<?= (int) $item['level'] ?></span>
                <label class="field"><span class="field__label">数字</span><span class="field__box"><input type="number" name="level" value="<?= (int) $item['level'] ?>" min="0" max="99" required></span></label>
                <label class="field"><span class="field__label">名称</span><span class="field__box"><input type="text" name="name" value="<?= e($item['name']) ?>" required></span></label>
                <label class="field"><span class="field__label">最低经验</span><span class="field__box"><input type="number" name="min_exp" value="<?= (int) $item['min_exp'] ?>" min="0" required></span></label>
                <label class="field"><span class="field__label">最高经验</span><span class="field__box"><input type="number" name="max_exp" value="<?= $item['max_exp'] === null ? '' : (int) $item['max_exp'] ?>" min="0" placeholder="无上限"></span></label>
                <label class="field field--color-sm"><span class="field__label">颜色</span><span class="field__box field__box--color"><input type="color" name="color" value="<?= e($item['color']) ?>"></span></label>
                <button class="btn btn--tonal btn--sm" type="submit">保存</button>
            </form>
        </section>
    <?php endforeach; ?>
</div>
