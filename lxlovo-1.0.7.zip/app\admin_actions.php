<?php

/* ---------------------------------------------------------------------------
 * 后台写操作
 * ------------------------------------------------------------------------- */

function admin_action(string $route): void
{
    switch ($route) {
        case 'user.update':
            admin_user_update();
            break;
        case 'user.cert':
            admin_user_cert_add();
            break;
        case 'user.cert.remove':
            admin_user_cert_remove();
            break;
        case 'user.notify':
            admin_user_notify();
            break;
        case 'post.action':
            admin_post_action();
            break;
        case 'post.batch':
            admin_post_batch();
            break;
        case 'comment.delete':
            admin_comment_delete();
            break;
        case 'board.save':
            admin_board_save();
            break;
        case 'board.delete':
            admin_board_delete();
            break;
        case 'carousel.save':
            admin_carousel_save();
            break;
        case 'carousel.delete':
            admin_carousel_delete();
            break;
        case 'announcement.save':
            admin_announcement_save();
            break;
        case 'announcement.delete':
            admin_announcement_delete();
            break;
        case 'cert.save':
            admin_cert_save();
            break;
        case 'cert.delete':
            admin_cert_delete();
            break;
        case 'application.review':
            admin_application_review();
            break;
        case 'link.save':
            admin_link_save();
            break;
        case 'link.delete':
            admin_link_delete();
            break;
        case 'nav.save':
            admin_nav_save();
            break;
        case 'nav.delete':
            admin_nav_delete();
            break;
        case 'level.save':
            admin_level_save();
            break;
        case 'reward.save':
            admin_reward_save();
            break;
        case 'reward.delete':
            admin_reward_delete();
            break;
        case 'settings.save':
            admin_settings_save();
            break;
        case 'app.release.save':
            admin_app_release_save();
            break;
        case 'app.release.delete':
            admin_app_release_delete();
            break;
        case 'app.settings.save':
            admin_app_settings_save();
            break;
        case 'broadcast.send':
            admin_broadcast_send();
            break;
        case 'email.test':
            admin_email_test();
            break;
        default:
            http_response_code(404);
            flash('error', '后台操作不存在。');
            redirect(admin_url('dashboard'));
    }
}

function admin_fail(string $message, string $url): never
{
    flash('error', $message);
    redirect($url);
}

function admin_user_update(): void
{
    $admin = require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $user = db_one('SELECT * FROM users WHERE id = ?', [$id]);
    if (!$user) {
        admin_fail('用户不存在。', admin_url('users'));
    }
    $username = normalize_username((string) ($_POST['username'] ?? ''));
    $email = mb_strtolower(trim((string) ($_POST['email'] ?? '')));
    $role = (string) ($_POST['role'] ?? 'user');
    $status = (string) ($_POST['status'] ?? 'active');
    $bio = trim((string) ($_POST['bio'] ?? ''));
    $exp = max(0, (int) ($_POST['exp'] ?? 0));
    $coins = max(0, (int) ($_POST['coins'] ?? 0));
    if (!username_is_valid($username)) {
        admin_fail('用户名格式不正确。', admin_url('user', ['id' => $id]));
    }
    if ($email !== '' && !valid_email($email)) {
        admin_fail('邮箱格式不正确。', admin_url('user', ['id' => $id]));
    }
    if (!in_array($role, ['user', 'admin'], true) || !in_array($status, ['active', 'banned'], true)) {
        admin_fail('角色或状态无效。', admin_url('user', ['id' => $id]));
    }
    if ($id === (int) $admin['id'] && ($role !== 'admin' || $status !== 'active')) {
        admin_fail('不能封禁或降级当前登录的管理员账号。', admin_url('user', ['id' => $id]));
    }
    if ($user['role'] === 'admin' && ($role !== 'admin' || $status !== 'active')) {
        $adminCount = (int) db_value("SELECT COUNT(*) FROM users WHERE role = 'admin' AND status = 'active'", [], 0);
        if ($adminCount <= 1) {
            admin_fail('必须保留至少一个可用的管理员账号。', admin_url('user', ['id' => $id]));
        }
    }
    if (db_value('SELECT COUNT(*) FROM users WHERE username = ? AND id <> ?', [$username, $id], 0) > 0) {
        admin_fail('用户名已被使用。', admin_url('user', ['id' => $id]));
    }
    if ($email !== '' && db_value('SELECT COUNT(*) FROM users WHERE email = ? AND id <> ?', [$email, $id], 0) > 0) {
        admin_fail('邮箱已被使用。', admin_url('user', ['id' => $id]));
    }
    if (mb_strlen($bio) > 500) {
        admin_fail('简介不能超过 500 个字符。', admin_url('user', ['id' => $id]));
    }
    $emailVerified = isset($_POST['email_verified']) ? 'NOW()' : 'NULL';
    $password = (string) ($_POST['new_password'] ?? '');
    $sql = "UPDATE users SET username = ?, email = ?, bio = ?, role = ?, status = ?, exp = ?, coins = ?, email_verified_at = {$emailVerified} WHERE id = ?";
    $params = [$username, $email !== '' ? $email : null, $bio, $role, $status, $exp, $coins, $id];
    db_exec($sql, $params);
    if (mb_strlen($password) > 0) {
        if (mb_strlen($password) < 8 || mb_strlen($password) > 72) {
            admin_fail('新密码长度需为 8-72 位。', admin_url('user', ['id' => $id]));
        }
        db_exec('UPDATE users SET password_hash = ? WHERE id = ?', [password_hash($password, PASSWORD_BCRYPT), $id]);
    }
    recalculate_level($id);
    flash('success', '用户资料已更新。');
    redirect(admin_url('user', ['id' => $id]));
}

function admin_user_cert_add(): void
{
    require_admin();
    $userId = (int) ($_POST['user_id'] ?? 0);
    $certId = (int) ($_POST['cert_id'] ?? 0);
    $cert = db_one('SELECT * FROM certifications WHERE id = ?', [$certId]);
    if (!$cert || !db_one('SELECT id FROM users WHERE id = ?', [$userId])) {
        admin_fail('用户或认证不存在。', admin_url('user', ['id' => $userId]));
    }
    db_exec('INSERT IGNORE INTO user_certifications (user_id, cert_id, granted_by) VALUES (?, ?, ?)', [$userId, $certId, (int) current_user()['id']]);
    $target = db_one('SELECT * FROM users WHERE id = ?', [$userId]);
    notify_user($userId, (int) current_user()['id'], 'system', '你已获得「' . $cert['name'] . '」认证。', url('user', ['id' => $userId]), '你获得了新认证');
    flash('success', '认证已授予。');
    redirect(admin_url('user', ['id' => $userId]));
}

function admin_user_cert_remove(): void
{
    require_admin();
    $userId = (int) ($_POST['user_id'] ?? 0);
    $certId = (int) ($_POST['cert_id'] ?? 0);
    db_exec('DELETE FROM user_certifications WHERE user_id = ? AND cert_id = ?', [$userId, $certId]);
    flash('success', '认证已移除。');
    redirect(admin_url('user', ['id' => $userId]));
}

function admin_user_notify(): void
{
    $admin = require_admin();
    $userId = (int) ($_POST['user_id'] ?? 0);
    $message = trim((string) ($_POST['message'] ?? ''));
    if (!db_one('SELECT id FROM users WHERE id = ?', [$userId])) {
        admin_fail('用户不存在。', admin_url('users'));
    }
    if ($message === '' || mb_strlen($message) > 500) {
        admin_fail('消息不能为空，且不能超过 500 个字符。', admin_url('user', ['id' => $userId]));
    }
    notify_user($userId, (int) $admin['id'], 'system', $message, url('notifications'), '来自管理员的消息');
    flash('success', '系统消息已发送。');
    redirect(admin_url('user', ['id' => $userId]));
}

function admin_post_action(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');
    $post = db_one('SELECT * FROM posts WHERE id = ?', [$id]);
    if (!$post) {
        admin_fail('帖子不存在或已经被彻底删除。', admin_url('posts'));
    }
    switch ($action) {
        case 'pin':
            db_exec('UPDATE posts SET is_pinned = ? WHERE id = ?', [(int) $post['is_pinned'] === 1 ? 0 : 1, $id]);
            flash('success', '置顶状态已更新。');
            break;
        case 'feature':
            db_exec('UPDATE posts SET is_featured = ?, featured_by = ? WHERE id = ?', [(int) $post['is_featured'] === 1 ? 0 : 1, (int) current_user()['id'], $id]);
            flash('success', '精选状态已更新。');
            break;
        case 'delete':
            db_exec('UPDATE posts SET status = "deleted" WHERE id = ?', [$id]);
            flash('success', '帖子已移入回收站，可随时恢复或彻底删除。');
            break;
        case 'restore':
            db_exec('UPDATE posts SET status = "published" WHERE id = ?', [$id]);
            flash('success', '帖子已恢复。');
            break;
        case 'purge':
            purge_posts([$id]);
            flash('success', '帖子已彻底删除，相关评论、点赞、收藏、打赏与通知已一并清理。');
            break;
        default:
            admin_fail('操作无效。', admin_url('posts'));
    }
    redirect(admin_url('posts'));
}

function admin_post_batch(): void
{
    require_admin();
    $ids = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['ids'] ?? [])), fn ($id) => $id > 0)));
    $action = (string) ($_POST['action'] ?? '');
    if ($ids === []) {
        admin_fail('请先选择要处理的帖子。', admin_url('posts'));
    }
    if (!in_array($action, ['purge', 'delete', 'restore'], true)) {
        admin_fail('批量操作无效。', admin_url('posts'));
    }

    if ($action === 'purge') {
        $count = purge_posts($ids);
        flash('success', '已彻底删除 ' . $count . ' 篇帖子，相关互动数据已清理。');
    } else {
        $status = $action === 'restore' ? 'published' : 'deleted';
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $count = db_exec("UPDATE posts SET status = ? WHERE id IN ({$placeholders})", array_merge([$status], $ids));
        flash('success', $action === 'restore' ? '已恢复 ' . $count . ' 篇帖子。' : '已将 ' . $count . ' 篇帖子移入回收站。');
    }
    redirect(admin_url('posts'));
}

function purge_posts(array $ids): int
{
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn ($id) => $id > 0)));
    if ($ids === []) {
        return 0;
    }
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $posts = db_all("SELECT id, cover, content FROM posts WHERE id IN ({$placeholders})", $ids);
    if ($posts === []) {
        return 0;
    }
    $postIds = array_map(fn ($post) => (int) $post['id'], $posts);
    $postPlaceholders = implode(',', array_fill(0, count($postIds), '?'));
    $commentIds = array_map(
        fn ($row) => (int) $row['id'],
        db_all("SELECT id FROM comments WHERE post_id IN ({$postPlaceholders})", $postIds)
    );

    db_transaction(function (PDO $pdo) use ($postIds, $postPlaceholders, $commentIds) {
        if ($commentIds !== []) {
            $commentPlaceholders = implode(',', array_fill(0, count($commentIds), '?'));
            $pdo->prepare("DELETE FROM comment_likes WHERE comment_id IN ({$commentPlaceholders})")->execute($commentIds);
        }
        $pdo->prepare("DELETE FROM comments WHERE post_id IN ({$postPlaceholders})")->execute($postIds);
        $pdo->prepare("DELETE FROM post_likes WHERE post_id IN ({$postPlaceholders})")->execute($postIds);
        $pdo->prepare("DELETE FROM post_favorites WHERE post_id IN ({$postPlaceholders})")->execute($postIds);
        $pdo->prepare("DELETE FROM post_rewards WHERE post_id IN ({$postPlaceholders})")->execute($postIds);

        $notificationWhere = [];
        $notificationParams = [];
        foreach ($postIds as $postId) {
            $notificationWhere[] = '(link LIKE ? OR link LIKE ?)';
            $notificationParams[] = '%r=post&id=' . $postId;
            $notificationParams[] = '%r=post&id=' . $postId . '#%';
        }
        $pdo->prepare('DELETE FROM notifications WHERE ' . implode(' OR ', $notificationWhere))->execute($notificationParams);
        $pdo->prepare("DELETE FROM posts WHERE id IN ({$postPlaceholders})")->execute($postIds);
    });

    delete_post_uploaded_media($posts);
    return count($postIds);
}

function normalize_uploaded_media_path(string $url): ?string
{
    $url = html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '') {
        return null;
    }
    if (preg_match('#^https?://#i', $url)) {
        $path = parse_url($url, PHP_URL_PATH);
        $url = is_string($path) ? $path : '';
    }
    $url = ltrim($url, '/');
    $base = ltrim(LXL_BASE_PATH, '/');
    if ($base !== '' && str_starts_with($url, $base . '/')) {
        $url = substr($url, strlen($base) + 1);
    }
    if (!preg_match('#^uploads/posts/[A-Za-z0-9_./-]+\.(?:jpe?g|png|webp|gif)$#i', $url) || str_contains($url, '..')) {
        return null;
    }
    return $url;
}

function delete_post_uploaded_media(array $posts): void
{
    $paths = [];
    foreach ($posts as $post) {
        $candidate = normalize_uploaded_media_path((string) ($post['cover'] ?? ''));
        if ($candidate !== null) {
            $paths[] = $candidate;
        }
        if (preg_match_all('/<img[^>]+src=["\']([^"\']+)["\']/i', (string) ($post['content'] ?? ''), $matches)) {
            foreach ($matches[1] as $src) {
                $candidate = normalize_uploaded_media_path($src);
                if ($candidate !== null) {
                    $paths[] = $candidate;
                }
            }
        }
    }
    $paths = array_values(array_unique($paths));
    if ($paths === []) {
        return;
    }
    $uploadsRoot = realpath(LXL_UPLOADS);
    if ($uploadsRoot === false) {
        return;
    }
    foreach ($paths as $path) {
        $like = like_escape($path);
        $references = (int) db_value(
            'SELECT
                (SELECT COUNT(*) FROM posts WHERE cover LIKE ? OR content LIKE ?)
                + (SELECT COUNT(*) FROM carousels WHERE image LIKE ?)
                + (SELECT COUNT(*) FROM announcements WHERE content LIKE ?)
                + (SELECT COUNT(*) FROM settings WHERE svalue LIKE ?)
                + (SELECT COUNT(*) FROM friend_links WHERE logo LIKE ?)',
            array_fill(0, 6, $like),
            0
        );
        if ($references > 0) {
            continue;
        }
        $relative = substr($path, strlen('uploads/'));
        $file = realpath(LXL_UPLOADS . '/' . $relative);
        if ($file !== false && str_starts_with($file, $uploadsRoot . DIRECTORY_SEPARATOR) && is_file($file)) {
            @unlink($file);
        }
    }
}

function admin_comment_delete(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $comment = comment_by_id($id);
    if (!$comment) {
        admin_fail('评论不存在。', admin_url('comments'));
    }
    db_exec('UPDATE comments SET status = "deleted" WHERE id = ? OR parent_id = ?', [$id, $id]);
    sync_post_counters((int) $comment['post_id']);
    flash('success', '评论已删除。');
    redirect(admin_url('comments'));
}

function admin_board_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $slug = trim((string) ($_POST['slug'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $icon = trim((string) ($_POST['icon'] ?? 'board')) ?: 'board';
    $color = trim((string) ($_POST['color'] ?? '#6750A4'));
    $sort = (int) ($_POST['sort'] ?? 0);
    $status = (string) ($_POST['status'] ?? 'active');
    if (mb_strlen($name) < 1 || mb_strlen($name) > 40) {
        admin_fail('板块名称需为 1-40 个字符。', admin_url('board', ['id' => $id]));
    }
    if ($slug === '') {
        $slug = 'board-' . ($id > 0 ? $id : time());
    }
    if (!preg_match('/^[a-z0-9\-]{2,60}$/', $slug)) {
        admin_fail('板块标识只能使用小写字母、数字和短横线。', admin_url('board', ['id' => $id]));
    }
    if (!preg_match('/^#[0-9a-f]{6}$/i', $color)) {
        $color = '#6750A4';
    }
    if (!in_array($status, ['active', 'hidden'], true)) {
        $status = 'active';
    }
    if (db_value('SELECT COUNT(*) FROM boards WHERE slug = ? AND id <> ?', [$slug, $id], 0) > 0) {
        admin_fail('板块标识已被使用。', admin_url('board', ['id' => $id]));
    }
    $ownerId = (int) ($_POST['owner_id'] ?? 0);
    $coowners = array_values(array_unique(array_filter(array_map('intval', (array) ($_POST['coowner_ids'] ?? [])))));
    $coowners = array_slice(array_values(array_filter($coowners, fn ($uid) => $uid > 0 && $uid !== $ownerId)), 0, 3);
    if ($ownerId > 0 && !db_one('SELECT id FROM users WHERE id = ?', [$ownerId])) {
        admin_fail('板块主不存在。', admin_url('board', ['id' => $id]));
    }
    foreach ($coowners as $uid) {
        if (!db_one('SELECT id FROM users WHERE id = ?', [$uid])) {
            admin_fail('副板块主不存在。', admin_url('board', ['id' => $id]));
        }
    }
    $newId = db_transaction(function (PDO $pdo) use ($id, $name, $slug, $description, $icon, $color, $sort, $status, $ownerId, $coowners) {
        if ($id > 0) {
            $pdo->prepare('UPDATE boards SET name = ?, slug = ?, description = ?, icon = ?, color = ?, sort = ?, status = ? WHERE id = ?')
                ->execute([$name, $slug, $description, $icon, $color, $sort, $status, $id]);
            $boardId = $id;
            $pdo->prepare('DELETE FROM board_moderators WHERE board_id = ?')->execute([$boardId]);
        } else {
            $pdo->prepare('INSERT INTO boards (name, slug, description, icon, color, sort, status) VALUES (?, ?, ?, ?, ?, ?, ?)')
                ->execute([$name, $slug, $description, $icon, $color, $sort, $status]);
            $boardId = (int) $pdo->lastInsertId();
        }
        if ($ownerId > 0) {
            $pdo->prepare('INSERT INTO board_moderators (board_id, user_id, role) VALUES (?, ?, "owner")')->execute([$boardId, $ownerId]);
        }
        foreach ($coowners as $uid) {
            $pdo->prepare('INSERT INTO board_moderators (board_id, user_id, role) VALUES (?, ?, "coowner")')->execute([$boardId, $uid]);
        }
        return $boardId;
    });
    flash('success', '板块已保存。');
    redirect(admin_url('board', ['id' => $newId]));
}

function admin_board_delete(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $count = (int) db_value('SELECT COUNT(*) FROM posts WHERE board_id = ?', [$id], 0);
    if ($count > 0) {
        admin_fail('该板块下还有 ' . $count . ' 篇帖子，不能删除。可以先将板块设为隐藏。', admin_url('board', ['id' => $id]));
    }
    db_transaction(function (PDO $pdo) use ($id) {
        $pdo->prepare('DELETE FROM board_moderators WHERE board_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM boards WHERE id = ?')->execute([$id]);
    });
    flash('success', '板块已删除。');
    redirect(admin_url('boards'));
}

function admin_carousel_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $title = trim((string) ($_POST['title'] ?? ''));
    $subtitle = trim((string) ($_POST['subtitle'] ?? ''));
    $image = trim((string) ($_POST['image'] ?? ''));
    $link = trim((string) ($_POST['link'] ?? ''));
    $sort = (int) ($_POST['sort'] ?? 0);
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    if ($title === '') {
        admin_fail('轮播标题不能为空。', admin_url('carousels'));
    }
    if (!empty($_FILES['image_file']['name'])) {
        try {
            $image = upload_image($_FILES['image_file'], 'carousel');
        } catch (RuntimeException $e) {
            admin_fail($e->getMessage(), admin_url('carousels'));
        }
    }
    if ($image === '') {
        admin_fail('请填写图片地址或上传图片。', admin_url('carousels'));
    }
    if (preg_match('/^\s*javascript:/i', $image) || !preg_match('#^(https?://|uploads/|assets/|/)#i', $image)) {
        admin_fail('图片地址格式无效。', admin_url('carousels'));
    }
    if ($link !== '' && !preg_match('#^(https?://|index\.php\?|admin\.php\?|/|#)#i', $link)) {
        admin_fail('跳转链接格式无效。', admin_url('carousels'));
    }
    if ($id > 0) {
        db_exec('UPDATE carousels SET title = ?, subtitle = ?, image = ?, link = ?, sort = ?, enabled = ? WHERE id = ?', [$title, $subtitle, $image, $link, $sort, $enabled, $id]);
    } else {
        db_insert('INSERT INTO carousels (title, subtitle, image, link, sort, enabled) VALUES (?, ?, ?, ?, ?, ?)', [$title, $subtitle, $image, $link, $sort, $enabled]);
    }
    flash('success', '轮播图已保存。');
    redirect(admin_url('carousels'));
}

function admin_carousel_delete(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    db_exec('DELETE FROM carousels WHERE id = ?', [$id]);
    flash('success', '轮播图已删除。');
    redirect(admin_url('carousels'));
}

function admin_announcement_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $title = trim((string) ($_POST['title'] ?? ''));
    $content = sanitize_html((string) ($_POST['content'] ?? ''));
    $mode = (string) ($_POST['display_mode'] ?? 'daily');
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $sort = (int) ($_POST['sort'] ?? 0);
    $starts = trim((string) ($_POST['starts_at'] ?? ''));
    $ends = trim((string) ($_POST['ends_at'] ?? ''));
    if ($title === '' || plain_text_from_html($content) === '') {
        admin_fail('公告标题和内容不能为空。', admin_url('announcements'));
    }
    if (!in_array($mode, ['every', 'daily', 'once'], true)) {
        $mode = 'daily';
    }
    $startsAt = $starts !== '' ? date('Y-m-d H:i:s', strtotime($starts)) : null;
    $endsAt = $ends !== '' ? date('Y-m-d H:i:s', strtotime($ends)) : null;
    if ($id > 0) {
        db_exec('UPDATE announcements SET title = ?, content = ?, display_mode = ?, enabled = ?, sort = ?, starts_at = ?, ends_at = ? WHERE id = ?', [$title, $content, $mode, $enabled, $sort, $startsAt, $endsAt, $id]);
    } else {
        db_insert('INSERT INTO announcements (title, content, display_mode, enabled, sort, starts_at, ends_at) VALUES (?, ?, ?, ?, ?, ?, ?)', [$title, $content, $mode, $enabled, $sort, $startsAt, $endsAt]);
    }
    flash('success', '公告已保存。');
    redirect(admin_url('announcements'));
}

function admin_announcement_delete(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    db_exec('DELETE FROM announcements WHERE id = ?', [$id]);
    flash('success', '公告已删除。');
    redirect(admin_url('announcements'));
}

function admin_cert_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $code = strtolower(trim((string) ($_POST['code'] ?? '')));
    $name = trim((string) ($_POST['name'] ?? ''));
    $type = (string) ($_POST['type'] ?? 'official');
    $color = trim((string) ($_POST['color'] ?? '#1A73E8'));
    $description = trim((string) ($_POST['description'] ?? ''));
    $conditions = trim((string) ($_POST['conditions'] ?? ''));
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    $sort = (int) ($_POST['sort'] ?? 0);
    if (!preg_match('/^[a-z0-9_-]{2,40}$/', $code) || $name === '') {
        admin_fail('认证标识或名称格式不正确。', admin_url('certifications'));
    }
    if (!in_array($type, ['official', 'user', 'sponsor'], true)) {
        admin_fail('认证类型无效。', admin_url('certifications'));
    }
    if (!preg_match('/^#[0-9a-f]{6}$/i', $color)) {
        $color = '#1A73E8';
    }
    if (db_value('SELECT COUNT(*) FROM certifications WHERE code = ? AND id <> ?', [$code, $id], 0) > 0) {
        admin_fail('认证标识已被使用。', admin_url('certifications'));
    }
    if ($id > 0) {
        db_exec('UPDATE certifications SET code = ?, name = ?, type = ?, color = ?, description = ?, conditions = ?, enabled = ?, sort = ? WHERE id = ?', [$code, $name, $type, $color, $description, $conditions, $enabled, $sort, $id]);
    } else {
        db_insert('INSERT INTO certifications (code, name, type, color, description, conditions, enabled, sort) VALUES (?, ?, ?, ?, ?, ?, ?, ?)', [$code, $name, $type, $color, $description, $conditions, $enabled, $sort]);
    }
    flash('success', '认证配置已保存。');
    redirect(admin_url('certifications'));
}

function admin_cert_delete(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    db_transaction(function (PDO $pdo) use ($id) {
        $pdo->prepare('DELETE FROM user_certifications WHERE cert_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM certifications WHERE id = ?')->execute([$id]);
    });
    flash('success', '认证已删除，相关用户的认证也已移除。');
    redirect(admin_url('certifications'));
}

function admin_application_review(): void
{
    $admin = require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $decision = (string) ($_POST['decision'] ?? '');
    $certId = (int) ($_POST['cert_id'] ?? 0);
    $note = trim((string) ($_POST['admin_note'] ?? ''));
    $application = db_one('SELECT * FROM verify_applications WHERE id = ?', [$id]);
    if (!$application || $application['status'] !== 'pending') {
        admin_fail('申请不存在或已经处理过。', admin_url('applications'));
    }
    if (!in_array($decision, ['approve', 'reject'], true)) {
        admin_fail('处理方式无效。', admin_url('applications'));
    }
    $user = db_one('SELECT * FROM users WHERE id = ?', [(int) $application['user_id']]);
    if (!$user) {
        admin_fail('申请人不存在。', admin_url('applications'));
    }
    if (mb_strlen($note) > 500) {
        admin_fail('审核备注不能超过 500 个字符。', admin_url('applications'));
    }
    if ($decision === 'approve') {
        $cert = db_one('SELECT * FROM certifications WHERE id = ? AND enabled = 1', [$certId]);
        if (!$cert || $cert['type'] !== $application['type']) {
            admin_fail('请选择与申请类型匹配的有效认证。', admin_url('applications'));
        }
        db_transaction(function (PDO $pdo) use ($id, $application, $certId, $admin, $note) {
            $pdo->prepare('UPDATE verify_applications SET status = "approved", admin_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?')
                ->execute([$note, (int) $admin['id'], $id]);
            $pdo->prepare('INSERT IGNORE INTO user_certifications (user_id, cert_id, granted_by) VALUES (?, ?, ?)')
                ->execute([(int) $application['user_id'], $certId, (int) $admin['id']]);
        });
        notify_verification_result($user, true, $application['type'], $note);
        flash('success', '申请已通过，认证已授予。');
    } else {
        db_exec('UPDATE verify_applications SET status = "rejected", admin_note = ?, reviewed_by = ?, reviewed_at = NOW() WHERE id = ?', [$note, (int) $admin['id'], $id]);
        notify_verification_result($user, false, $application['type'], $note);
        flash('success', '申请已拒绝。');
    }
    redirect(admin_url('applications'));
}

function admin_link_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $url = trim((string) ($_POST['url'] ?? ''));
    $description = trim((string) ($_POST['description'] ?? ''));
    $logo = trim((string) ($_POST['logo'] ?? ''));
    $tag = trim((string) ($_POST['tag'] ?? ''));
    $sort = (int) ($_POST['sort'] ?? 0);
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    if ($name === '' || !preg_match('#^https?://#i', $url)) {
        admin_fail('友链名称不能为空，链接需以 http(s):// 开头。', admin_url('links'));
    }
    if ($logo !== '' && !preg_match('#^(https?://|uploads/|assets/|/)#i', $logo)) {
        $logo = '';
    }
    if ($id > 0) {
        db_exec('UPDATE friend_links SET name = ?, url = ?, description = ?, logo = ?, tag = ?, sort = ?, enabled = ? WHERE id = ?', [$name, $url, $description, $logo, $tag, $sort, $enabled, $id]);
    } else {
        db_insert('INSERT INTO friend_links (name, url, description, logo, tag, sort, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)', [$name, $url, $description, $logo, $tag, $sort, $enabled]);
    }
    flash('success', '友链已保存。');
    redirect(admin_url('links'));
}

function admin_link_delete(): void
{
    require_admin();
    db_exec('DELETE FROM friend_links WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
    flash('success', '友链已删除。');
    redirect(admin_url('links'));
}

function admin_nav_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $label = trim((string) ($_POST['label'] ?? ''));
    $urlValue = trim((string) ($_POST['url'] ?? ''));
    $iconName = trim((string) ($_POST['icon'] ?? 'link'));
    $sort = (int) ($_POST['sort'] ?? 0);
    $enabled = isset($_POST['enabled']) ? 1 : 0;
    if ($label === '' || $urlValue === '') {
        admin_fail('快捷方式名称和地址不能为空。', admin_url('navigation'));
    }
    if (!array_key_exists($iconName, icon_paths())) {
        $iconName = 'link';
    }
    if (!preg_match('#^(https?://|index\.php\?|admin\.php\?|/|#)#i', $urlValue)) {
        admin_fail('快捷方式地址格式无效。', admin_url('navigation'));
    }
    if ($id > 0) {
        db_exec('UPDATE nav_links SET label = ?, url = ?, icon = ?, sort = ?, enabled = ? WHERE id = ?', [$label, $urlValue, $iconName, $sort, $enabled, $id]);
    } else {
        db_insert('INSERT INTO nav_links (label, url, icon, sort, enabled) VALUES (?, ?, ?, ?, ?)', [$label, $urlValue, $iconName, $sort, $enabled]);
    }
    flash('success', '快捷方式已保存。');
    redirect(admin_url('navigation'));
}

function admin_nav_delete(): void
{
    require_admin();
    db_exec('DELETE FROM nav_links WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
    flash('success', '快捷方式已删除。');
    redirect(admin_url('navigation'));
}

function admin_level_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $level = (int) ($_POST['level'] ?? 0);
    $name = trim((string) ($_POST['name'] ?? ''));
    $minExp = max(0, (int) ($_POST['min_exp'] ?? 0));
    $maxExpRaw = trim((string) ($_POST['max_exp'] ?? ''));
    $maxExp = $maxExpRaw === '' ? null : max(0, (int) $maxExpRaw);
    $color = trim((string) ($_POST['color'] ?? '#6750A4'));
    if ($level < 0 || $level > 99 || $name === '') {
        admin_fail('等级配置无效。', admin_url('levels'));
    }
    if ($maxExp !== null && $maxExp < $minExp) {
        admin_fail('最高经验不能小于最低经验。', admin_url('levels'));
    }
    if (db_value('SELECT COUNT(*) FROM levels WHERE level = ? AND id <> ?', [$level, $id], 0) > 0) {
        admin_fail('等级数字已存在。', admin_url('levels'));
    }
    if (!preg_match('/^#[0-9a-f]{6}$/i', $color)) {
        $color = '#6750A4';
    }
    if ($id > 0) {
        db_exec('UPDATE levels SET level = ?, name = ?, min_exp = ?, max_exp = ?, color = ? WHERE id = ?', [$level, $name, $minExp, $maxExp, $color, $id]);
    } else {
        db_insert('INSERT INTO levels (level, name, min_exp, max_exp, color, sort) VALUES (?, ?, ?, ?, ?, ?)', [$level, $name, $minExp, $maxExp, $color, $level]);
    }
    $GLOBALS['lxl_levels_cache'] = null;
    levels(true);
    foreach (db_all('SELECT id FROM users') as $row) {
        recalculate_level((int) $row['id']);
    }
    flash('success', '等级配置已保存，所有用户等级已重新计算。');
    redirect(admin_url('levels'));
}

function admin_reward_save(): void
{
    require_admin();
    $id = (int) ($_POST['id'] ?? 0);
    $streak = (int) ($_POST['streak_days'] ?? 0);
    $exp = max(0, (int) ($_POST['exp'] ?? 0));
    $coins = max(0, (int) ($_POST['coins'] ?? 0));
    if ($streak < 1 || $streak > 3650) {
        admin_fail('连续天数需在 1-3650 之间。', admin_url('rewards'));
    }
    if (db_value('SELECT COUNT(*) FROM checkin_rewards WHERE streak_days = ? AND id <> ?', [$streak, $id], 0) > 0) {
        admin_fail('该连续天数已有奖励配置。', admin_url('rewards'));
    }
    if ($id > 0) {
        db_exec('UPDATE checkin_rewards SET streak_days = ?, exp = ?, coins = ? WHERE id = ?', [$streak, $exp, $coins, $id]);
    } else {
        db_insert('INSERT INTO checkin_rewards (streak_days, exp, coins) VALUES (?, ?, ?)', [$streak, $exp, $coins]);
    }
    flash('success', '签到奖励已保存。');
    redirect(admin_url('rewards'));
}

function admin_reward_delete(): void
{
    require_admin();
    db_exec('DELETE FROM checkin_rewards WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
    flash('success', '签到奖励已删除。');
    redirect(admin_url('rewards'));
}

function admin_settings_save(): void
{
    require_admin();
    $textKeys = [
        'site_name', 'site_tagline', 'site_description', 'site_keywords', 'site_url', 'filing_info', 'footer_extra',
        'theme_default', 'online_minutes', 'smtp_host', 'smtp_port', 'smtp_secure', 'smtp_user', 'smtp_from',
        'smtp_from_name', 'upload_max_kb', 'upload_roles', 'upload_max_width', 'avatar_max_kb', 'avatar_max_width',
        'carousel_max_kb', 'user_verify_min_level', 'user_verify_note', 'sponsor_url', 'sponsor_note', 'post_per_page',
    ];
    $boolKeys = [
        'register_enabled', 'checkin_enabled', 'official_badge_enabled', 'official_card_enabled', 'show_online_users',
        'email_verify_required', 'email_notify_enabled', 'upload_enabled', 'announcement_enabled',
    ];
    $values = [];
    foreach ($textKeys as $key) {
        if (array_key_exists($key, $_POST)) {
            $values[$key] = trim((string) $_POST[$key]);
        }
    }
    foreach ($boolKeys as $key) {
        $values[$key] = isset($_POST[$key]) ? '1' : '0';
    }
    if (isset($_POST['about_content'])) {
        $values['about_content'] = sanitize_html((string) $_POST['about_content']);
        $values['about_updated_at'] = date('Y-m-d H:i:s');
    }
    if (isset($values['site_url']) && $values['site_url'] !== '' && !preg_match('#^https?://#i', $values['site_url'])) {
        admin_fail('站点地址需以 http:// 或 https:// 开头。', admin_url('settings'));
    }
    if (isset($values['smtp_port'])) {
        $port = (int) $values['smtp_port'];
        if ($port < 1 || $port > 65535) {
            admin_fail('SMTP 端口无效。', admin_url('settings'));
        }
        $values['smtp_port'] = (string) $port;
    }
    if (isset($values['smtp_secure']) && !in_array($values['smtp_secure'], ['ssl', 'tls', 'none'], true)) {
        $values['smtp_secure'] = 'ssl';
    }
    if (isset($_POST['smtp_pass']) && (string) $_POST['smtp_pass'] !== '') {
        $values['smtp_pass'] = (string) $_POST['smtp_pass'];
    }
    if (isset($_POST['clear_smtp_pass'])) {
        $values['smtp_pass'] = '';
    }
    if (isset($values['theme_default']) && !in_array($values['theme_default'], ['light', 'dark', 'system'], true)) {
        $values['theme_default'] = 'light';
    }
    foreach (['online_minutes', 'upload_max_kb', 'upload_max_width', 'avatar_max_kb', 'avatar_max_width', 'carousel_max_kb', 'user_verify_min_level', 'post_per_page'] as $key) {
        if (isset($values[$key])) {
            $values[$key] = (string) max(1, (int) $values[$key]);
        }
    }
    if (isset($values['upload_roles'])) {
        $allowedRoles = ['official', 'sponsor', 'user'];
        $roles = array_values(array_intersect(array_filter(array_map('trim', explode(',', $values['upload_roles']))), $allowedRoles));
        $values['upload_roles'] = implode(',', $roles);
    }
    set_settings($values);
    flash('success', '站点设置已保存。');
    redirect(admin_url('settings'));
}

function admin_app_release_save(): void
{
    require_admin();
    ensure_app_release_schema();
    $id = (int) ($_POST['id'] ?? 0);
    $versionName = trim((string) ($_POST['version_name'] ?? ''));
    $versionCode = (int) ($_POST['version_code'] ?? 0);
    $downloadUrl = trim((string) ($_POST['download_url'] ?? ''));
    $downloadMode = (string) ($_POST['download_mode'] ?? 'auto');
    $isForced = isset($_POST['is_forced']) ? 1 : 0;
    $isEnabled = isset($_POST['is_enabled']) ? 1 : 0;
    $changelog = trim((string) ($_POST['changelog'] ?? ''));
    $publishedAtRaw = trim((string) ($_POST['published_at'] ?? ''));

    if ($versionName === '' || mb_strlen($versionName) > 40) {
        admin_fail('版本号名称不能为空，且不能超过 40 个字符。', admin_url('app'));
    }
    if ($versionCode < 1) {
        admin_fail('版本代码必须是大于 0 的整数。', admin_url('app'));
    }
    if (!in_array($downloadMode, ['auto', 'direct', 'page'], true)) {
        $downloadMode = 'auto';
    }
    if ($downloadUrl !== '' && !preg_match('#^https://#i', $downloadUrl)) {
        admin_fail('更新链接必须使用 HTTPS。', admin_url('app'));
    }
    if ($isEnabled && $downloadUrl === '') {
        admin_fail('启用中的版本必须填写更新链接。', admin_url('app'));
    }
    if (mb_strlen($changelog) > 20000) {
        admin_fail('更新内容不能超过 20000 个字符。', admin_url('app'));
    }
    if (db_value('SELECT COUNT(*) FROM app_releases WHERE version_code = ? AND id <> ?', [$versionCode, $id], 0) > 0) {
        admin_fail('这个版本代码已经存在。', admin_url('app'));
    }
    $publishedAt = $publishedAtRaw !== '' ? date('Y-m-d H:i:s', strtotime($publishedAtRaw)) : date('Y-m-d H:i:s');

    if ($id > 0) {
        db_exec(
            'UPDATE app_releases SET version_name = ?, version_code = ?, download_url = ?, download_mode = ?, is_forced = ?, changelog = ?, is_enabled = ?, published_at = ? WHERE id = ?',
            [$versionName, $versionCode, $downloadUrl, $downloadMode, $isForced, $changelog, $isEnabled, $publishedAt, $id]
        );
    } else {
        db_insert(
            'INSERT INTO app_releases (version_name, version_code, download_url, download_mode, is_forced, changelog, is_enabled, published_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            [$versionName, $versionCode, $downloadUrl, $downloadMode, $isForced, $changelog, $isEnabled, $publishedAt]
        );
    }
    flash('success', 'App 版本已保存。');
    redirect(admin_url('app'));
}

function admin_app_release_delete(): void
{
    require_admin();
    ensure_app_release_schema();
    db_exec('DELETE FROM app_releases WHERE id = ?', [(int) ($_POST['id'] ?? 0)]);
    flash('success', 'App 版本记录已删除。');
    redirect(admin_url('app'));
}

function admin_app_settings_save(): void
{
    require_admin();
    set_setting('app_inapp_browser_default', isset($_POST['app_inapp_browser_default']) ? '1' : '0');
    flash('success', 'App 设置已保存。');
    redirect(admin_url('app'));
}

function admin_broadcast_send(): void
{
    require_admin();
    $message = trim((string) ($_POST['message'] ?? ''));
    $sendEmail = isset($_POST['send_email']);
    if ($message === '' || mb_strlen($message) > 500) {
        admin_fail('广播内容不能为空，且不能超过 500 个字符。', admin_url('broadcast'));
    }
    $count = broadcast_notification($message, $sendEmail, '站点公告');
    flash('success', '已向 ' . $count . ' 位用户发送系统消息。');
    redirect(admin_url('broadcast'));
}

function admin_email_test(): void
{
    require_admin();
    $email = trim((string) ($_POST['email'] ?? ''));
    if (!valid_email($email)) {
        admin_fail('请输入有效的收件邮箱。', admin_url('settings') . '#email');
    }
    $result = send_test_email($email);
    flash($result['ok'] ? 'success' : 'error', $result['ok'] ? '测试邮件已发送。' : '发送失败：' . ($result['error'] ?? '未知错误'));
    redirect(admin_url('settings') . '#email');
}
