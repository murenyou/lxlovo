<?php
$buildUrl = fn (int $page): string => admin_url('comments', ['page' => $page]);
?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Content</span><h2>评论管理</h2><p>共 <?= (int) $total ?> 条评论。</p></div></div>
<section class="admin-panel">
    <div class="table-wrap">
        <table class="data-table">
            <thead><tr><th>评论</th><th>作者</th><th>所属帖子</th><th>状态</th><th>时间</th><th>操作</th></tr></thead>
            <tbody>
            <?php foreach ($comments as $comment): ?>
                <tr>
                    <td class="table-cell-clamp"><?= e(text_excerpt($comment['content'], 90)) ?></td>
                    <td><a class="table-action" href="<?= e(admin_url('user', ['id' => (int) $comment['user_id']])) ?>"><?= e($comment['username']) ?></a></td>
                    <td><a class="table-action" href="<?= e(url('post', ['id' => (int) $comment['post_id']])) ?>" target="_blank"><?= e($comment['post_title'] ?: '已删除') ?></a></td>
                    <td><span class="status-chip status-chip--<?= $comment['status'] === 'published' ? 'success' : 'danger' ?>"><?= $comment['status'] === 'published' ? '正常' : '已删除' ?></span></td>
                    <td><?= e(time_ago($comment['created_at'])) ?></td>
                    <td>
                        <?php if ($comment['status'] === 'published'): ?>
                            <form action="<?= e(admin_url('comment.delete')) ?>" method="post" data-confirm="确定删除这条评论吗？"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $comment['id'] ?>"><button class="table-action table-action--danger" type="submit">删除</button></form>
                        <?php else: ?><span class="muted-text">—</span><?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (!$comments): ?><div class="admin-empty">还没有评论。</div><?php endif; ?>
    <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
</section>
