<?php

/* ---------------------------------------------------------------------------
 * 前台页面
 * ------------------------------------------------------------------------- */

function site_page(string $route): void
{
    switch ($route) {
        case 'home':
            page_home();
            break;
        case 'posts':
            page_posts();
            break;
        case 'board':
            page_board();
            break;
        case 'boards':
            page_boards();
            break;
        case 'post':
            page_post();
            break;
        case 'publish':
            page_publish();
            break;
        case 'user':
            page_user();
            break;
        case 'me':
            page_me();
            break;
        case 'settings':
            page_settings();
            break;
        case 'notifications':
            page_notifications();
            break;
        case 'notification.go':
            page_notification_go();
            break;
        case 'messages':
            page_messages();
            break;
        case 'verify':
            page_verify();
            break;
        case 'about':
            page_about();
            break;
        case 'links':
            page_links();
            break;
        case 'search':
            page_search();
            break;
        case 'favorites':
            page_favorites();
            break;
        case 'my_posts':
            page_my_posts();
            break;
        case 'login':
            page_login();
            break;
        case 'register':
            page_register();
            break;
        case 'verify_email':
            page_verify_email();
            break;
        case 'forgot_password':
            page_forgot_password();
            break;
        case 'reset_password':
            page_reset_password();
            break;
        case 'online':
            page_online();
            break;
        default:
            page_not_found();
    }
}

function post_select_sql(): string
{
    return "SELECT p.*, b.name AS board_name, b.slug AS board_slug, b.color AS board_color, b.icon AS board_icon,
                   u.username, u.avatar, u.bio, u.exp, u.level, u.show_official_badge, u.status AS user_status
            FROM posts p
            JOIN users u ON u.id = p.user_id
            LEFT JOIN boards b ON b.id = p.board_id";
}

function preload_posts_badges(array $posts): void
{
    preload_badges(array_map(fn ($post) => (int) $post['user_id'], $posts));
}

function site_stats(): array
{
    return [
        'users' => (int) db_value('SELECT COUNT(*) FROM users', [], 0),
        'posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE status = 'published'", [], 0),
        'comments' => (int) db_value("SELECT COUNT(*) FROM comments WHERE status = 'published'", [], 0),
        'today_posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE status = 'published' AND DATE(created_at) = CURDATE()", [], 0),
        'today_checkins' => (int) db_value('SELECT COUNT(*) FROM checkins WHERE checkin_date = CURDATE()', [], 0),
        'online' => (int) db_value('SELECT COUNT(*) FROM users WHERE last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)', [setting_int('online_minutes', 15)], 0),
    ];
}

function online_users(int $limit = 12): array
{
    return db_all(
        'SELECT id, username, avatar, level, exp, last_active_at FROM users
         WHERE status = "active" AND last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
         ORDER BY last_active_at DESC LIMIT ' . max(1, $limit),
        [setting_int('online_minutes', 15)]
    );
}

function displayable_announcements(): array
{
    if (!setting_bool('announcement_enabled', true)) {
        return [];
    }
    $rows = db_all(
        "SELECT * FROM announcements
         WHERE enabled = 1
           AND (starts_at IS NULL OR starts_at <= NOW())
           AND (ends_at IS NULL OR ends_at >= NOW())
         ORDER BY sort ASC, id ASC"
    );
    if ($rows === []) {
        return [];
    }
    $user = current_user();
    $views = [];
    if ($user) {
        $ids = array_map(fn ($row) => (int) $row['id'], $rows);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        foreach (db_all("SELECT * FROM announcement_views WHERE user_id = ? AND announcement_id IN ({$placeholders})", array_merge([(int) $user['id']], $ids)) as $view) {
            $views[(int) $view['announcement_id']] = $view;
        }
    }
    $show = [];
    foreach ($rows as $row) {
        $id = (int) $row['id'];
        $mode = $row['display_mode'];
        if ($mode === 'every') {
            $show[] = $row;
            continue;
        }
        if ($user) {
            $view = $views[$id] ?? null;
            if ($mode === 'once' && $view) {
                continue;
            }
            if ($mode === 'daily' && $view && $view['last_seen_date'] === date('Y-m-d')) {
                continue;
            }
            $show[] = $row;
        } else {
            $cookie = (string) ($_COOKIE['lxl_ann_' . $id] ?? '');
            if ($mode === 'once' && $cookie === '1') {
                continue;
            }
            if ($mode === 'daily' && $cookie === date('Y-m-d')) {
                continue;
            }
            $show[] = $row;
        }
    }
    return $show;
}

function page_home(): void
{
    $carousels = db_all('SELECT * FROM carousels WHERE enabled = 1 ORDER BY sort ASC, id ASC');
    $boards = db_all(
        "SELECT b.*,
            (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count,
            (SELECT MAX(p.created_at) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS last_post_at
         FROM boards b WHERE b.status = 'active' ORDER BY b.sort ASC, b.id ASC"
    );
    $pinned = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.is_pinned = 1 ORDER BY p.updated_at DESC LIMIT 5");
    $latest = db_all(post_select_sql() . " WHERE p.status = 'published' ORDER BY p.created_at DESC LIMIT 8");
    $hot = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY (p.views + p.likes_count * 8 + p.comments_count * 12 + p.favorites_count * 6) DESC, p.created_at DESC LIMIT 6");
    $featured = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.is_featured = 1 ORDER BY p.updated_at DESC LIMIT 4");
    $random = db_all(post_select_sql() . " WHERE p.status = 'published' ORDER BY RAND() LIMIT 4");
    $online = online_users(12);
    $stats = site_stats();
    preload_posts_badges(array_merge($pinned, $latest, $hot, $featured, $random));
    render('home', [
        'pageTitle' => setting('site_name') . ' · ' . setting('site_tagline'),
        'pageDescription' => setting('site_description'),
        'bodyClass' => 'page-home',
        'carousels' => $carousels,
        'boards' => $boards,
        'pinned' => $pinned,
        'latest' => $latest,
        'hot' => $hot,
        'featured' => $featured,
        'random' => $random,
        'online' => $online,
        'stats' => $stats,
    ]);
}

function page_posts(): void
{
    $boardId = (int) ($_GET['board'] ?? 0);
    $q = trim((string) ($_GET['q'] ?? ''));
    $sort = (string) ($_GET['sort'] ?? 'latest');
    if (!in_array($sort, ['latest', 'hot', 'featured'], true)) {
        $sort = 'latest';
    }
    $where = "p.status = 'published'";
    $params = [];
    $board = null;
    if ($boardId > 0) {
        $board = board_by_id($boardId);
        if (!$board || $board['status'] !== 'active') {
            page_not_found();
            return;
        }
        $where .= ' AND p.board_id = ?';
        $params[] = $boardId;
    }
    if ($q !== '') {
        $where .= ' AND (p.title LIKE ? OR p.content_text LIKE ?)';
        $params[] = like_escape($q);
        $params[] = like_escape($q);
    }
    if ($sort === 'featured') {
        $where .= ' AND p.is_featured = 1';
    }
    $order = $sort === 'hot'
        ? '(p.views + p.likes_count * 8 + p.comments_count * 12 + p.favorites_count * 6) DESC, p.created_at DESC'
        : 'p.is_pinned DESC, p.created_at DESC';
    $per = max(6, min(30, setting_int('post_per_page', 12)));
    $page = current_page();
    $total = (int) db_value("SELECT COUNT(*) FROM posts p WHERE {$where}", $params, 0);
    $posts = db_all(post_select_sql() . " WHERE {$where} ORDER BY {$order} LIMIT {$per} OFFSET " . (($page - 1) * $per), $params);
    preload_posts_badges($posts);
    $boards = db_all(
        "SELECT b.*, (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count
         FROM boards b WHERE b.status = 'active' ORDER BY b.sort ASC"
    );
    $sidebarHot = db_all(post_select_sql() . " WHERE p.status = 'published' ORDER BY (p.views + p.likes_count * 8 + p.comments_count * 12) DESC LIMIT 5");
    preload_posts_badges($sidebarHot);
    render('posts', [
        'pageTitle' => ($board ? $board['name'] : '文章') . ' · ' . setting('site_name'),
        'bodyClass' => 'page-posts',
        'posts' => $posts,
        'board' => $board,
        'boards' => $boards,
        'q' => $q,
        'sort' => $sort,
        'total' => $total,
        'page' => $page,
        'per' => $per,
        'sidebarHot' => $sidebarHot,
    ]);
}

function page_board(): void
{
    page_posts();
}

function page_boards(): void
{
    $boards = db_all(
        "SELECT b.*,
            (SELECT COUNT(*) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS post_count,
            (SELECT MAX(p.created_at) FROM posts p WHERE p.board_id = b.id AND p.status = 'published') AS last_post_at
         FROM boards b WHERE b.status = 'active' ORDER BY b.sort ASC, b.id ASC"
    );
    $mods = [];
    foreach (db_all(
        'SELECT bm.board_id, bm.role, u.id, u.username, u.avatar
         FROM board_moderators bm JOIN users u ON u.id = bm.user_id
         ORDER BY bm.role ASC, bm.id ASC'
    ) as $row) {
        $mods[(int) $row['board_id']][] = $row;
    }
    $latest = [];
    foreach ($boards as $board) {
        $latest[(int) $board['id']] = db_one(
            'SELECT id, title, created_at FROM posts WHERE board_id = ? AND status = "published" ORDER BY created_at DESC LIMIT 1',
            [(int) $board['id']]
        );
    }
    render('boards', [
        'pageTitle' => '板块 · ' . setting('site_name'),
        'bodyClass' => 'page-boards',
        'boards' => $boards,
        'mods' => $mods,
        'latest' => $latest,
    ]);
}

function page_post(): void
{
    $id = (int) ($_GET['id'] ?? 0);
    $post = post_by_id($id, true);
    if (!$post || ($post['status'] !== 'published' && !can_edit_post($post))) {
        page_not_found();
        return;
    }
    $viewed = $_SESSION['viewed_posts'][$id] ?? 0;
    if (time() - (int) $viewed > 1800) {
        db_exec('UPDATE posts SET views = views + 1 WHERE id = ?', [$id]);
        $post['views'] = (int) $post['views'] + 1;
        $_SESSION['viewed_posts'][$id] = time();
    }
    $user = current_user();
    $liked = false;
    $favorited = false;
    if ($user) {
        $liked = db_value('SELECT COUNT(*) FROM post_likes WHERE post_id = ? AND user_id = ?', [$id, (int) $user['id']], 0) > 0;
        $favorited = db_value('SELECT COUNT(*) FROM post_favorites WHERE post_id = ? AND user_id = ?', [$id, (int) $user['id']], 0) > 0;
    }
    $commentsRaw = db_all(
        "SELECT c.*, u.username, u.avatar, u.level, u.exp, u.show_official_badge, ru.username AS reply_to_username
         FROM comments c JOIN users u ON u.id = c.user_id
         LEFT JOIN users ru ON ru.id = c.reply_to_user_id
         WHERE c.post_id = ? AND c.status = 'published'
         ORDER BY c.is_pinned DESC, c.created_at ASC",
        [$id]
    );
    preload_badges(array_map(fn ($c) => (int) $c['user_id'], $commentsRaw));
    $likedComments = [];
    if ($user && $commentsRaw !== []) {
        $commentIds = array_map(fn ($c) => (int) $c['id'], $commentsRaw);
        $placeholders = implode(',', array_fill(0, count($commentIds), '?'));
        foreach (db_all("SELECT comment_id FROM comment_likes WHERE user_id = ? AND comment_id IN ({$placeholders})", array_merge([(int) $user['id']], $commentIds)) as $row) {
            $likedComments[(int) $row['comment_id']] = true;
        }
    }
    $tree = [];
    $replies = [];
    foreach ($commentsRaw as $comment) {
        $comment['liked'] = isset($likedComments[(int) $comment['id']]);
        if (empty($comment['parent_id'])) {
            $comment['replies'] = [];
            $tree[(int) $comment['id']] = $comment;
        } else {
            $replies[(int) $comment['parent_id']][] = $comment;
        }
    }
    foreach ($replies as $parentId => $items) {
        if (isset($tree[$parentId])) {
            $tree[$parentId]['replies'] = $items;
        }
    }
    $related = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.board_id = ? AND p.id <> ? ORDER BY p.created_at DESC LIMIT 4", [(int) $post['board_id'], $id]);
    preload_posts_badges($related);
    $rewardTotal = (int) db_value('SELECT COALESCE(SUM(amount), 0) FROM post_rewards WHERE post_id = ?', [$id], 0);
    $canPin = false;
    if ($user) {
        $canPin = is_admin($user) || (int) $post['user_id'] === (int) $user['id'] || can_moderate_board((int) $post['board_id'], $user);
    }
    $canFeature = $user && (is_admin($user) || is_official_user((int) $user['id']));
    $boardMods = db_all('SELECT u.id, u.username, u.avatar, bm.role FROM board_moderators bm JOIN users u ON u.id = bm.user_id WHERE bm.board_id = ?', [(int) $post['board_id']]);
    render('post', [
        'pageTitle' => $post['title'] . ' · ' . setting('site_name'),
        'pageDescription' => post_excerpt($post, 100),
        'bodyClass' => 'page-post',
        'post' => $post,
        'comments' => $tree,
        'related' => $related,
        'liked' => $liked,
        'favorited' => $favorited,
        'rewardTotal' => $rewardTotal,
        'canPin' => $canPin,
        'canFeature' => $canFeature,
        'boardMods' => $boardMods,
        'page' => current_page(),
    ]);
}

function page_publish(): void
{
    $user = require_login();
    if (setting_bool('email_verify_required') && !email_verified($user)) {
        flash('warning', '请先完成邮箱验证，再发布内容。');
        redirect(url('verify_email'));
    }
    $boards = board_list();
    if ($boards === []) {
        flash('warning', '还没有可用板块，请联系管理员。');
        redirect(url('home'));
    }
    $editId = (int) ($_GET['id'] ?? 0);
    $post = null;
    if ($editId > 0) {
        $post = post_by_id($editId, true);
        if (!$post || !can_edit_post($post, $user)) {
            flash('error', '你没有权限编辑这篇帖子。');
            redirect(url('home'));
        }
    }
    render('publish', [
        'pageTitle' => ($post ? '编辑文章' : '发布文章') . ' · ' . setting('site_name'),
        'bodyClass' => 'page-editor',
        'boards' => $boards,
        'post' => $post,
        'canUpload' => can_upload_posts($user),
    ]);
}

function page_user(): void
{
    $id = (int) ($_GET['id'] ?? 0);
    $user = db_one('SELECT * FROM users WHERE id = ? LIMIT 1', [$id]);
    if (!$user || $user['status'] === 'banned') {
        page_not_found();
        return;
    }
    $stats = [
        'posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE user_id = ? AND status = 'published'", [$id], 0),
        'comments' => (int) db_value("SELECT COUNT(*) FROM comments WHERE user_id = ? AND status = 'published'", [$id], 0),
        'likes' => (int) db_value('SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE user_id = ? AND status = "published"', [$id], 0),
        'favorites' => (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE p.user_id = ? AND p.status = 'published'", [$id], 0),
    ];
    $posts = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.user_id = ? ORDER BY p.created_at DESC LIMIT 6", [$id]);
    preload_posts_badges($posts);
    $comments = db_all(
        "SELECT c.*, p.title AS post_title FROM comments c JOIN posts p ON p.id = c.post_id
         WHERE c.user_id = ? AND c.status = 'published' AND p.status = 'published'
         ORDER BY c.created_at DESC LIMIT 6",
        [$id]
    );
    $isSelf = (int) (current_user()['id'] ?? 0) === $id;
    render('user', [
        'pageTitle' => $user['username'] . ' · ' . setting('site_name'),
        'pageDescription' => text_excerpt($user['bio'], 100),
        'bodyClass' => 'page-user',
        'profile' => $user,
        'stats' => $stats,
        'posts' => $posts,
        'comments' => $comments,
        'isSelf' => $isSelf,
    ]);
}

function page_me(): void
{
    $user = require_login();
    $today = date('Y-m-d');
    $checkedIn = ($user['last_checkin_date'] ?? '') === $today;
    $rewards = db_all('SELECT * FROM checkin_rewards ORDER BY streak_days ASC');
    $nextReward = null;
    $nextStreak = $checkedIn ? (int) $user['checkin_streak'] : (int) $user['checkin_streak'] + 1;
    $rewardsByDays = [];
    foreach ($rewards as $reward) {
        $rewardsByDays[(int) $reward['streak_days']] = $reward;
        if ((int) $reward['streak_days'] >= $nextStreak) {
            $nextReward = $reward;
            break;
        }
    }
    if ($nextReward === null && $rewards !== []) {
        $nextReward = end($rewards);
    }
    $posts = db_all(post_select_sql() . " WHERE p.status = 'published' AND p.user_id = ? ORDER BY p.created_at DESC LIMIT 4", [(int) $user['id']]);
    preload_posts_badges($posts);
    $stats = [
        'posts' => (int) db_value("SELECT COUNT(*) FROM posts WHERE user_id = ? AND status = 'published'", [(int) $user['id']], 0),
        'comments' => (int) db_value("SELECT COUNT(*) FROM comments WHERE user_id = ? AND status = 'published'", [(int) $user['id']], 0),
        'favorites' => (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE pf.user_id = ? AND p.status = 'published'", [(int) $user['id']], 0),
        'likes' => (int) db_value('SELECT COALESCE(SUM(likes_count), 0) FROM posts WHERE user_id = ? AND status = "published"', [(int) $user['id']], 0),
    ];
    $checkinHistory = db_all('SELECT * FROM checkins WHERE user_id = ? ORDER BY checkin_date DESC LIMIT 7', [(int) $user['id']]);
    $pendingApplications = (int) db_value("SELECT COUNT(*) FROM verify_applications WHERE user_id = ? AND status = 'pending'", [(int) $user['id']], 0);
    $certifications = user_badges((int) $user['id']);
    render('me', [
        'pageTitle' => '我的 · ' . setting('site_name'),
        'bodyClass' => 'page-me',
        'profile' => $user,
        'checkedIn' => $checkedIn,
        'rewards' => $rewardsByDays,
        'nextReward' => $nextReward,
        'nextStreak' => $nextStreak,
        'posts' => $posts,
        'stats' => $stats,
        'checkinHistory' => $checkinHistory,
        'pendingApplications' => $pendingApplications,
        'certifications' => $certifications,
    ]);
}

function page_settings(): void
{
    $user = require_login();
    render('settings', [
        'pageTitle' => '设置 · ' . setting('site_name'),
        'bodyClass' => 'page-settings',
        'profile' => $user,
    ]);
}

function page_notifications(): void
{
    $user = require_login();
    $per = 20;
    $page = current_page();
    $total = (int) db_value('SELECT COUNT(*) FROM notifications WHERE user_id = ?', [(int) $user['id']], 0);
    $notifications = db_all(
        'SELECT n.*, u.username AS actor_name, u.avatar AS actor_avatar
         FROM notifications n LEFT JOIN users u ON u.id = n.actor_id
         WHERE n.user_id = ? ORDER BY n.created_at DESC LIMIT ' . $per . ' OFFSET ' . (($page - 1) * $per),
        [(int) $user['id']]
    );
    render('notifications', [
        'pageTitle' => '通知 · ' . setting('site_name'),
        'bodyClass' => 'page-notifications',
        'notifications' => $notifications,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function page_notification_go(): void
{
    $user = require_login();
    $id = (int) ($_GET['id'] ?? 0);
    $notification = db_one('SELECT * FROM notifications WHERE id = ? AND user_id = ?', [$id, (int) $user['id']]);
    if (!$notification) {
        redirect(url('notifications'));
    }
    db_exec('UPDATE notifications SET is_read = 1 WHERE id = ?', [$id]);
    $link = trim((string) $notification['link']);
    if ($link === '') {
        redirect(url('notifications'));
    }
    redirect(safe_next_url($link));
}

function page_messages(): void
{
    $user = require_login();
    $uid = (int) $user['id'];
    $rows = db_all(
        'SELECT m.*, u.id AS other_id, u.username, u.avatar, u.last_active_at
         FROM messages m
         JOIN users u ON u.id = CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END
         WHERE m.sender_id = ? OR m.receiver_id = ?
         ORDER BY m.created_at DESC LIMIT 200',
        [$uid, $uid, $uid]
    );
    $conversations = [];
    foreach ($rows as $row) {
        $other = (int) $row['other_id'];
        if (!isset($conversations[$other])) {
            $conversations[$other] = $row;
        }
    }
    $unread = [];
    foreach (db_all('SELECT sender_id, COUNT(*) AS c FROM messages WHERE receiver_id = ? AND is_read = 0 GROUP BY sender_id', [$uid]) as $row) {
        $unread[(int) $row['sender_id']] = (int) $row['c'];
    }
    $withId = (int) ($_GET['with'] ?? 0);
    $chatUser = null;
    $messages = [];
    if ($withId > 0) {
        $chatUser = db_one("SELECT * FROM users WHERE id = ? AND status = 'active'", [$withId]);
        if (!$chatUser) {
            page_not_found();
            return;
        }
        $messages = db_all(
            'SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
             ORDER BY created_at ASC LIMIT 200',
            [$uid, $withId, $withId, $uid]
        );
        db_exec('UPDATE messages SET is_read = 1 WHERE sender_id = ? AND receiver_id = ? AND is_read = 0', [$withId, $uid]);
        $unread[$withId] = 0;
    }
    render('messages', [
        'pageTitle' => '私信 · ' . setting('site_name'),
        'bodyClass' => 'page-messages',
        'conversations' => $conversations,
        'unread' => $unread,
        'chatUser' => $chatUser,
        'messages' => $messages,
    ]);
}

function page_verify(): void
{
    $user = require_login();
    $applications = db_all('SELECT * FROM verify_applications WHERE user_id = ? ORDER BY created_at DESC LIMIT 20', [(int) $user['id']]);
    $pending = [];
    foreach ($applications as $application) {
        if ($application['status'] === 'pending') {
            $pending[$application['type']] = $application;
        }
    }
    render('verify', [
        'pageTitle' => '账号认证 · ' . setting('site_name'),
        'bodyClass' => 'page-verify',
        'profile' => $user,
        'applications' => $applications,
        'pending' => $pending,
        'certifications' => user_badges((int) $user['id']),
        'certDefs' => db_all('SELECT * FROM certifications WHERE enabled = 1 ORDER BY sort ASC, id ASC'),
    ]);
}

function page_about(): void
{
    render('about', [
        'pageTitle' => '关于 · ' . setting('site_name'),
        'bodyClass' => 'page-about',
        'stats' => site_stats(),
        'online' => online_users(8),
    ]);
}

function page_links(): void
{
    $links = db_all('SELECT * FROM friend_links WHERE enabled = 1 ORDER BY sort ASC, id ASC');
    $groups = [];
    foreach ($links as $link) {
        $tag = trim((string) $link['tag']) ?: '友情链接';
        $groups[$tag][] = $link;
    }
    render('links', [
        'pageTitle' => '友链 · ' . setting('site_name'),
        'bodyClass' => 'page-links',
        'groups' => $groups,
    ]);
}

function page_search(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $type = (string) ($_GET['type'] ?? 'all');
    if (!in_array($type, ['all', 'posts', 'users', 'boards'], true)) {
        $type = 'all';
    }
    $posts = [];
    $users = [];
    $boards = [];
    $total = 0;
    $page = current_page();
    $per = 15;
    if ($q !== '') {
        $like = like_escape($q);
        if ($type === 'all' || $type === 'posts') {
            $where = "p.status = 'published' AND (p.title LIKE ? OR p.content_text LIKE ?)";
            $total = (int) db_value("SELECT COUNT(*) FROM posts p WHERE {$where}", [$like, $like], 0);
            $posts = db_all(post_select_sql() . " WHERE {$where} ORDER BY p.created_at DESC LIMIT {$per} OFFSET " . (($page - 1) * $per), [$like, $like]);
            preload_posts_badges($posts);
        }
        if ($type === 'all' || $type === 'users') {
            $users = db_all("SELECT id, username, avatar, bio, exp, level, last_active_at FROM users WHERE status = 'active' AND (username LIKE ? OR bio LIKE ?) ORDER BY id ASC LIMIT 12", [$like, $like]);
            preload_badges(array_map(fn ($u) => (int) $u['id'], $users));
        }
        if ($type === 'all' || $type === 'boards') {
            $boards = db_all("SELECT * FROM boards WHERE status = 'active' AND (name LIKE ? OR description LIKE ?) ORDER BY sort ASC LIMIT 12", [$like, $like]);
        }
    }
    render('search', [
        'pageTitle' => '搜索 · ' . setting('site_name'),
        'bodyClass' => 'page-search',
        'q' => $q,
        'type' => $type,
        'posts' => $posts,
        'users' => $users,
        'boards' => $boards,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function page_favorites(): void
{
    $user = require_login();
    $per = 12;
    $page = current_page();
    $total = (int) db_value("SELECT COUNT(*) FROM post_favorites pf JOIN posts p ON p.id = pf.post_id WHERE pf.user_id = ? AND p.status = 'published'", [(int) $user['id']], 0);
    $posts = db_all(
        post_select_sql() . " JOIN post_favorites pf ON pf.post_id = p.id
         WHERE pf.user_id = ? AND p.status = 'published'
         ORDER BY pf.created_at DESC LIMIT {$per} OFFSET " . (($page - 1) * $per),
        [(int) $user['id']]
    );
    preload_posts_badges($posts);
    render('favorites', [
        'pageTitle' => '我的收藏 · ' . setting('site_name'),
        'bodyClass' => 'page-favorites',
        'posts' => $posts,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function page_my_posts(): void
{
    $user = require_login();
    $per = 15;
    $page = current_page();
    $total = (int) db_value('SELECT COUNT(*) FROM posts WHERE user_id = ? AND status <> "deleted"', [(int) $user['id']], 0);
    $posts = db_all(
        post_select_sql() . " WHERE p.user_id = ? AND p.status <> 'deleted' ORDER BY p.created_at DESC LIMIT {$per} OFFSET " . (($page - 1) * $per),
        [(int) $user['id']]
    );
    preload_posts_badges($posts);
    render('my_posts', [
        'pageTitle' => '我的文章 · ' . setting('site_name'),
        'bodyClass' => 'page-my-posts',
        'posts' => $posts,
        'total' => $total,
        'page' => $page,
        'per' => $per,
    ]);
}

function page_login(): void
{
    if (current_user()) {
        redirect(url('me'));
    }
    render('login', [
        'pageTitle' => '登录 · ' . setting('site_name'),
        'bodyClass' => 'page-auth',
    ]);
}

function page_register(): void
{
    if (current_user()) {
        redirect(url('me'));
    }
    if (!setting_bool('register_enabled', true)) {
        render('register', [
            'pageTitle' => '注册 · ' . setting('site_name'),
            'bodyClass' => 'page-auth',
            'closed' => true,
        ]);
        return;
    }
    render('register', [
        'pageTitle' => '注册 · ' . setting('site_name'),
        'bodyClass' => 'page-auth',
        'closed' => false,
    ]);
}

function page_verify_email(): void
{
    $token = trim((string) ($_GET['token'] ?? ''));
    if ($token !== '') {
        [$ok, $message] = verify_email_token($token);
        flash($ok ? 'success' : 'error', $message);
        redirect(url('verify_email'));
    }
    $user = current_user();
    render('verify_email', [
        'pageTitle' => '邮箱验证 · ' . setting('site_name'),
        'bodyClass' => 'page-auth',
        'profile' => $user,
    ]);
}

function page_forgot_password(): void
{
    if (current_user()) {
        redirect(url('me'));
    }
    render('forgot_password', [
        'pageTitle' => '找回密码 · ' . setting('site_name'),
        'bodyClass' => 'page-auth',
    ]);
}

function page_reset_password(): void
{
    $token = trim((string) ($_GET['token'] ?? ''));
    render('reset_password', [
        'pageTitle' => '重置密码 · ' . setting('site_name'),
        'bodyClass' => 'page-auth',
        'token' => $token,
    ]);
}

function page_online(): void
{
    $users = db_all(
        'SELECT id, username, avatar, bio, exp, level, last_active_at FROM users
         WHERE status = "active" AND last_active_at >= DATE_SUB(NOW(), INTERVAL ? MINUTE)
         ORDER BY last_active_at DESC LIMIT 100',
        [setting_int('online_minutes', 15)]
    );
    preload_badges(array_map(fn ($u) => (int) $u['id'], $users));
    render('online', [
        'pageTitle' => '在线用户 · ' . setting('site_name'),
        'bodyClass' => 'page-online',
        'users' => $users,
    ]);
}

function page_not_found(): void
{
    http_response_code(404);
    render('404', [
        'pageTitle' => '页面不存在 · ' . setting('site_name'),
        'bodyClass' => 'page-404',
    ]);
}
