<?php
$me = $profile;
$hasEmail = !empty($me['email']);
$verified = !empty($me['email_verified_at']);
$mailReady = email_configured();
$badges = user_badges((int) $me['id']);
?>
<section class="page-head page-head--compact">
    <div>
        <span class="page-head__eyebrow">Settings</span>
        <h1>设置</h1>
        <p>管理头像、资料、邮箱、密码与消息提醒。</p>
    </div>
    <a class="btn btn--outlined" href="<?= e(url('me')) ?>"><?= icon('arrow_back', '', 18) ?>返回我的</a>
</section>

<div class="settings-layout">
    <aside class="settings-nav">
        <a href="#profile" class="is-active"><?= icon('person', '', 19) ?>个人资料</a>
        <a href="#notifications"><?= icon('notifications', '', 19) ?>消息提醒</a>
        <a href="#account"><?= icon('mail', '', 19) ?>邮箱与账号</a>
        <a href="#security"><?= icon('lock', '', 19) ?>密码安全</a>
        <a href="#appearance"><?= icon('light', '', 19) ?>外观</a>
    </aside>

    <div class="settings-main">
        <section class="panel" id="profile">
            <div class="panel__head"><div><h2>个人资料</h2><p>这些信息会展示在你的个人主页与帖子旁。</p></div></div>
            <div class="avatar-editor">
                <img class="avatar avatar--xl" src="<?= e(avatar_url($me)) ?>" alt="" id="avatar-preview">
                <div>
                    <h3>头像</h3>
                    <p class="muted-text">支持 JPG、PNG、WebP、GIF。会自动压缩至 <?= setting_int('avatar_max_kb', 300) ?>KB 以内。</p>
                    <form action="<?= e(url('profile.avatar')) ?>" method="post" enctype="multipart/form-data" class="avatar-form">
                        <?= csrf_field() ?>
                        <label class="btn btn--tonal btn--sm">
                            <?= icon('camera', '', 17) ?>选择图片
                            <input type="file" name="avatar" accept="image/jpeg,image/png,image/webp,image/gif" required hidden data-avatar-input>
                        </label>
                        <button class="btn btn--primary btn--sm" type="submit">上传头像</button>
                    </form>
                </div>
            </div>

            <form action="<?= e(url('profile.save')) ?>" method="post" class="form-stack">
                <?= csrf_field() ?>
                <?php foreach (['notify_comment', 'notify_mention', 'notify_message', 'notify_system', 'notify_email'] as $prefKey): ?>
                    <?php if ((int) $me[$prefKey] === 1): ?><input type="hidden" name="<?= e($prefKey) ?>" value="1"><?php endif; ?>
                <?php endforeach; ?>
                <label class="field">
                    <span class="field__label">用户名</span>
                    <span class="field__box field__box--disabled"><?= icon('person') ?><input type="text" value="<?= e($me['username']) ?>" disabled></span>
                    <span class="field__hint">用户名暂不支持自行修改。</span>
                </label>
                <label class="field">
                    <span class="field__label">个人简介</span>
                    <span class="field__box field__box--textarea"><?= icon('edit') ?><textarea name="bio" rows="4" maxlength="500" placeholder="用一小段话介绍自己…"><?= e($me['bio']) ?></textarea></span>
                    <span class="field__hint">最多 500 个字符。</span>
                </label>
                <div class="switch-row">
                    <div><strong>展示官方认证</strong><p>关闭后，你的认证标识与官方卡片配色将不在前台显示。</p></div>
                    <label class="switch"><input type="checkbox" name="show_official_badge" value="1" <?= (int) $me['show_official_badge'] === 1 ? 'checked' : '' ?>><span></span></label>
                </div>
                <?php if ($badges): ?>
                    <div class="cert-list">
                        <?php foreach ($badges as $badge): ?>
                            <span class="verify-badge verify-badge--<?= e($badge['type']) ?>" style="--badge-color:<?= e($badge['color']) ?>"><?= icon('verified') ?><span><?= e($badge['name']) ?></span></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="form-actions"><button class="btn btn--primary" type="submit">保存资料</button></div>
            </form>
        </section>

        <section class="panel" id="notifications">
            <div class="panel__head"><div><h2>消息提醒</h2><p>选择你希望收到的站内通知与邮件提醒。</p></div></div>
            <form action="<?= e(url('profile.save')) ?>" method="post" class="form-stack">
                <?= csrf_field() ?>
                <input type="hidden" name="bio" value="<?= e($me['bio']) ?>">
                <?php if ((int) $me['show_official_badge'] === 1): ?><input type="hidden" name="show_official_badge" value="1"><?php endif; ?>
                <div class="switch-list">
                    <div class="switch-row"><div><strong>评论与回复</strong><p>有人评论你的帖子或回复你的评论时提醒。</p></div><label class="switch"><input type="checkbox" name="notify_comment" value="1" <?= (int) $me['notify_comment'] === 1 ? 'checked' : '' ?>><span></span></label></div>
                    <div class="switch-row"><div><strong>@ 提及</strong><p>有人在帖子或评论中 @ 你时提醒。</p></div><label class="switch"><input type="checkbox" name="notify_mention" value="1" <?= (int) $me['notify_mention'] === 1 ? 'checked' : '' ?>><span></span></label></div>
                    <div class="switch-row"><div><strong>私信</strong><p>收到新的私信时提醒。</p></div><label class="switch"><input type="checkbox" name="notify_message" value="1" <?= (int) $me['notify_message'] === 1 ? 'checked' : '' ?>><span></span></label></div>
                    <div class="switch-row"><div><strong>系统消息</strong><p>接收站点公告、认证结果等系统通知。</p></div><label class="switch"><input type="checkbox" name="notify_system" value="1" <?= (int) $me['notify_system'] === 1 ? 'checked' : '' ?>><span></span></label></div>
                    <div class="switch-row"><div><strong>邮件提醒</strong><p>重要互动同时发送到绑定邮箱。<?= $mailReady ? '' : '站点尚未配置 SMTP，邮件暂时不可用。' ?></p></div><label class="switch"><input type="checkbox" name="notify_email" value="1" <?= (int) $me['notify_email'] === 1 ? 'checked' : '' ?>><span></span></label></div>
                </div>
                <div class="form-actions"><button class="btn btn--primary" type="submit">保存提醒设置</button></div>
            </form>
        </section>

        <section class="panel" id="account">
            <div class="panel__head"><div><h2>邮箱与账号</h2><p>邮箱用于登录验证与重要通知。</p></div></div>
            <div class="account-row">
                <div>
                    <span class="account-row__label">当前邮箱</span>
                    <strong><?= e($me['email'] ?: '未绑定') ?></strong>
                </div>
                <div>
                    <?php if (!$hasEmail): ?>
                        <span class="status-chip status-chip--warning">未绑定</span>
                    <?php elseif ($verified): ?>
                        <span class="status-chip status-chip--success"><?= icon('check', '', 14) ?>已验证</span>
                    <?php else: ?>
                        <span class="status-chip status-chip--warning">未验证</span>
                        <a class="text-link" href="<?= e(url('verify_email')) ?>">去验证</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="account-row">
                <div><span class="account-row__label">用户 ID</span><strong>#<?= (int) $me['id'] ?></strong></div>
                <div><span class="account-row__label">注册时间</span><strong><?= e(format_date($me['created_at'], 'Y-m-d H:i')) ?></strong></div>
            </div>
            <details class="settings-details">
                <summary>修改绑定邮箱</summary>
                <form action="<?= e(url('profile.email')) ?>" method="post" class="form-stack">
                    <?= csrf_field() ?>
                    <label class="field"><span class="field__label">新邮箱</span><span class="field__box"><?= icon('mail') ?><input type="email" name="email" placeholder="new@example.com" required></span></label>
                    <label class="field"><span class="field__label">当前密码</span><span class="field__box"><?= icon('lock') ?><input type="password" name="password" placeholder="用于确认身份" required></span></label>
                    <button class="btn btn--primary btn--sm" type="submit">更新邮箱</button>
                </form>
            </details>
            <?php if (!$verified && $hasEmail): ?>
                <form action="<?= e(url('resend_verification')) ?>" method="post" class="resend-row">
                    <?= csrf_field() ?>
                    <span>还没有收到验证邮件？</span>
                    <button class="text-btn" type="submit">重新发送</button>
                </form>
            <?php endif; ?>
        </section>

        <section class="panel" id="security">
            <div class="panel__head"><div><h2>密码安全</h2><p>建议使用 8 位以上、包含字母与数字的独立密码。</p></div></div>
            <form action="<?= e(url('profile.password')) ?>" method="post" class="form-stack">
                <?= csrf_field() ?>
                <label class="field"><span class="field__label">当前密码</span><span class="field__box"><?= icon('lock') ?><input type="password" name="old_password" autocomplete="current-password" required></span></label>
                <label class="field"><span class="field__label">新密码</span><span class="field__box"><?= icon('lock') ?><input type="password" name="new_password" autocomplete="new-password" minlength="8" maxlength="72" required></span></label>
                <label class="field"><span class="field__label">确认新密码</span><span class="field__box"><?= icon('check') ?><input type="password" name="new_password_confirm" autocomplete="new-password" minlength="8" maxlength="72" required></span></label>
                <div class="form-actions"><button class="btn btn--primary" type="submit">更新密码</button></div>
            </form>
        </section>

        <section class="panel" id="appearance">
            <div class="panel__head"><div><h2>外观</h2><p>默认使用白天主题，也可以跟随系统。</p></div></div>
            <div class="theme-choice">
                <button type="button" class="theme-box" data-theme-set="light"><?= icon('light', '', 28) ?><span>白天</span></button>
                <button type="button" class="theme-box" data-theme-set="dark"><?= icon('dark', '', 28) ?><span>夜晚</span></button>
                <button type="button" class="theme-box" data-theme-set="system"><?= icon('system', '', 28) ?><span>跟随系统</span></button>
            </div>
            <p class="muted-text">主题偏好保存在当前浏览器中。</p>
        </section>
    </div>
</div>
