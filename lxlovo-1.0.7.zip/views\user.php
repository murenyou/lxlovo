<?php
$levelInfo = level_progress($profile);
$certifications = user_badges((int) $profile['id']);
$me = current_user();
?>
<section class="profile-hero">
    <div class="profile-hero__cover">
        <span class="profile-hero__glow"></span>
        <span class="profile-hero__initial"><?= e(mb_substr($profile['username'], 0, 1)) ?></span>
    </div>
    <div class="profile-hero__body">
        <img class="avatar avatar--xl profile-hero__avatar" src="<?= e(avatar_url($profile)) ?>" alt="">
        <div class="profile-hero__main">
            <div class="profile-hero__name">
                <h1><?= e($profile['username']) ?></h1>
                <?= badge_html((int) $profile['id'], $profile) ?>
                <?php if (is_online($profile)): ?><span class="online-pill"><i></i>在线</span><?php endif; ?>
            </div>
            <p class="profile-hero__id">ID <?= (int) $profile['id'] ?> · <?= e(format_date($profile['created_at'], 'Y 年 m 月加入')) ?></p>
            <p class="profile-hero__bio"><?= e($profile['bio'] ?: '这个人很神秘，还没有写下简介。') ?></p>
            <div class="profile-hero__level">
                <span class="level-dot" style="--level-color:<?= e($levelInfo['current']['color']) ?>">Lv.<?= (int) $levelInfo['current']['level'] ?> <?= e($levelInfo['current']['name']) ?></span>
                <div class="level-progress level-progress--inline">
                    <div class="level-progress__bar"><span style="width:<?= (int) $levelInfo['progress'] ?>%"></span></div>
                </div>
                <span class="muted-text"><?= (int) $profile['exp'] ?> EXP</span>
            </div>
        </div>
        <div class="profile-hero__actions">
            <?php if ($isSelf): ?>
                <a class="btn btn--outlined" href="<?= e(url('settings')) ?>"><?= icon('settings', '', 18) ?>编辑资料</a>
            <?php elseif ($me): ?>
                <a class="btn btn--primary" href="<?= e(url('messages', ['with' => (int) $profile['id']])) ?>"><?= icon('mail', '', 18) ?>发私信</a>
            <?php else: ?>
                <a class="btn btn--primary" href="<?= e(url('login', ['next' => url('user', ['id' => (int) $profile['id']])])) ?>">登录后互动</a>
            <?php endif; ?>
        </div>
    </div>
    <div class="profile-hero__stats">
        <div><strong><?= short_number($stats['posts']) ?></strong><span>文章</span></div>
        <div><strong><?= short_number($stats['comments']) ?></strong><span>评论</span></div>
        <div><strong><?= short_number($stats['likes']) ?></strong><span>获赞</span></div>
        <div><strong><?= short_number($stats['favorites']) ?></strong><span>被收藏</span></div>
    </div>
</section>

<?php if ($certifications): ?>
    <section class="profile-certs">
        <h2>认证</h2>
        <div class="cert-list">
            <?php foreach ($certifications as $cert): ?>
                <span class="verify-badge verify-badge--<?= e($cert['type']) ?>" style="--badge-color:<?= e($cert['color']) ?>"><?= icon('verified') ?><span><?= e($cert['name']) ?></span></span>
            <?php endforeach; ?>
        </div>
    </section>
<?php endif; ?>

<div class="profile-sections">
    <section class="section">
        <div class="section__head">
            <div><span class="section__eyebrow">Posts</span><h2>最近文章</h2></div>
            <a class="text-link" href="<?= e(url('posts')) ?>">浏览更多<?= icon('chevron_right', '', 17) ?></a>
        </div>
        <?php if ($posts): ?>
            <div class="post-grid">
                <?php foreach ($posts as $post): ?>
                    <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="empty-state empty-state--small"><?= icon('article', '', 32) ?><h3>还没有发布文章</h3><p>期待 <?= e($profile['username']) ?> 的第一篇分享。</p></div>
        <?php endif; ?>
    </section>

    <section class="section">
        <div class="section__head"><div><span class="section__eyebrow">Replies</span><h2>最近评论</h2></div></div>
        <?php if ($comments): ?>
            <div class="comment-history">
                <?php foreach ($comments as $comment): ?>
                    <a class="comment-history__item" href="<?= e(url('post', ['id' => (int) $comment['post_id']])) ?>#comment-<?= (int) $comment['id'] ?>">
                        <span class="comment-history__body">
                            <span class="comment-history__post"><?= e($comment['post_title']) ?></span>
                            <span class="comment-history__text"><?= e(text_excerpt($comment['content'], 120)) ?></span>
                        </span>
                        <time><?= e(time_ago($comment['created_at'])) ?></time>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <p class="muted-text">还没有评论记录。</p>
        <?php endif; ?>
    </section>
</div>
