<?php ?>
<section class="auth-shell auth-shell--simple">
    <div class="auth-card">
        <span class="auth-icon"><?= icon('lock', '', 34) ?></span>
        <div class="auth-card__head">
            <span class="page-head__eyebrow">Reset password</span>
            <h2>找回密码</h2>
            <p>输入注册邮箱，我们会发送一封重置邮件。</p>
        </div>
        <?php if (!email_configured()): ?>
            <div class="notice notice--warning"><?= icon('info', '', 20) ?>站点尚未配置 SMTP，暂时无法发送重置邮件，请联系管理员。</div>
        <?php endif; ?>
        <form action="<?= e(url('forgot_password')) ?>" method="post" class="form-stack">
            <?= csrf_field() ?>
            <label class="field"><span class="field__label">注册邮箱</span><span class="field__box"><?= icon('mail') ?><input type="email" name="email" placeholder="you@example.com" required autofocus></span></label>
            <button class="btn btn--primary btn--full" type="submit" <?= email_configured() ? '' : 'disabled' ?>>发送重置邮件</button>
        </form>
        <a class="auth-back" href="<?= e(url('login')) ?>"><?= icon('arrow_back', '', 16) ?>返回登录</a>
    </div>
</section>
