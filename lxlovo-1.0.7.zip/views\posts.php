<?php
$boardId = $board ? (int) $board['id'] : 0;
$buildUrl = function (int $page) use ($boardId, $sort, $q): string {
    $params = ['page' => $page];
    if ($boardId > 0) {
        $params['board'] = $boardId;
    }
    if ($sort !== 'latest') {
        $params['sort'] = $sort;
    }
    if ($q !== '') {
        $params['q'] = $q;
    }
    return url('posts', $params);
};
?>
<section class="page-head">
    <div>
        <span class="page-head__eyebrow"><?= $board ? 'Board' : 'Articles' ?></span>
        <h1><?= e($board ? $board['name'] : '全部文章') ?></h1>
        <p><?= e($board ? $board['description'] : '阅读社区里的技术、生活与灵感。') ?></p>
    </div>
    <a class="btn btn--primary" href="<?= e(current_user() ? url('publish') : url('login', ['next' => url('publish')])) ?>"><?= icon('edit', '', 18) ?>写文章</a>
</section>

<div class="list-layout">
    <div class="list-main">
        <div class="toolbar">
            <div class="segmented" role="tablist" aria-label="排序">
                <a class="segmented__item<?= $sort === 'latest' ? ' is-active' : '' ?>" href="<?= e(url('posts', array_filter(['board' => $boardId ?: null, 'q' => $q ?: null]))) ?>">最新</a>
                <a class="segmented__item<?= $sort === 'hot' ? ' is-active' : '' ?>" href="<?= e(url('posts', array_filter(['board' => $boardId ?: null, 'q' => $q ?: null, 'sort' => 'hot']))) ?>">最热</a>
                <a class="segmented__item<?= $sort === 'featured' ? ' is-active' : '' ?>" href="<?= e(url('posts', array_filter(['board' => $boardId ?: null, 'q' => $q ?: null, 'sort' => 'featured']))) ?>">精选</a>
            </div>
            <form class="inline-search" action="<?= e(url('posts')) ?>" method="get">
                <input type="hidden" name="r" value="posts">
                <?php if ($boardId): ?><input type="hidden" name="board" value="<?= $boardId ?>"><?php endif; ?>
                <?php if ($sort !== 'latest'): ?><input type="hidden" name="sort" value="<?= e($sort) ?>"><?php endif; ?>
                <?= icon('search', '', 18) ?>
                <input type="search" name="q" value="<?= e($q) ?>" placeholder="在文章中搜索" maxlength="80">
            </form>
        </div>

        <div class="board-filter">
            <a class="chip<?= !$boardId ? ' is-active' : '' ?>" href="<?= e(url('posts', array_filter(['q' => $q ?: null, 'sort' => $sort !== 'latest' ? $sort : null]))) ?>">全部</a>
            <?php foreach ($boards as $item): ?>
                <a class="chip chip--board<?= $boardId === (int) $item['id'] ? ' is-active' : '' ?>" href="<?= e(url('posts', array_filter(['board' => (int) $item['id'], 'q' => $q ?: null, 'sort' => $sort !== 'latest' ? $sort : null]))) ?>" style="--chip-color:<?= e($item['color']) ?>">
                    <?= e($item['name']) ?><span class="chip__count"><?= (int) $item['post_count'] ?></span>
                </a>
            <?php endforeach; ?>
        </div>

        <p class="result-meta">共 <strong><?= (int) $total ?></strong> 篇文章<?= $q !== '' ? '，搜索“' . e($q) . '”' : '' ?></p>

        <?php if ($posts): ?>
            <div class="post-grid">
                <?php foreach ($posts as $post): ?>
                    <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
                <?php endforeach; ?>
            </div>
            <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
        <?php else: ?>
            <div class="empty-state">
                <?= icon('search', '', 38) ?>
                <h3>没有找到文章</h3>
                <p>换一个关键词，或者去发布第一篇。</p>
                <a class="btn btn--primary" href="<?= e(current_user() ? url('publish') : url('register')) ?>">去发布</a>
            </div>
        <?php endif; ?>
    </div>

    <aside class="list-sidebar">
        <section class="side-card">
            <div class="side-card__head"><h2>板块导航</h2></div>
            <div class="side-nav">
                <?php foreach ($boards as $item): ?>
                    <a class="side-nav__item<?= $boardId === (int) $item['id'] ? ' is-active' : '' ?>" href="<?= e(url('posts', ['board' => (int) $item['id']])) ?>">
                        <span class="side-nav__dot" style="background:<?= e($item['color']) ?>"></span>
                        <span><?= e($item['name']) ?></span>
                        <span class="side-nav__count"><?= (int) $item['post_count'] ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
        <section class="side-card">
            <div class="side-card__head"><h2>本周热门</h2></div>
            <div class="rank-list">
                <?php foreach ($sidebarHot as $index => $hotPost): ?>
                    <a class="rank-item" href="<?= e(url('post', ['id' => (int) $hotPost['id']])) ?>">
                        <span class="rank-item__num<?= $index < 3 ? ' is-top' : '' ?>"><?= $index + 1 ?></span>
                        <span class="rank-item__body"><strong><?= e($hotPost['title']) ?></strong><span><?= e($hotPost['board_name']) ?></span></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    </aside>
</div>
