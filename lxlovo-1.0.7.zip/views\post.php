<?php
$me = current_user();
$author = [
    'id' => (int) $post['user_id'],
    'username' => $post['username'] ?? '',
    'avatar' => $post['avatar'] ?? '',
    'show_official_badge' => $post['show_official_badge'] ?? 1,
    'exp' => $post['exp'] ?? 0,
];
$level = level_for_exp((int) $post['exp']);
$officialCard = is_official_card_enabled((int) $post['user_id'], $author);
$canEdit = can_edit_post($post, $me);
$isOwn = $me && (int) $me['id'] === (int) $post['user_id'];
$commentCount = 0;
foreach ($comments as $thread) {
    $commentCount += 1 + count($thread['replies'] ?? []);
}
$readingMinutes = max(1, (int) ceil(mb_strlen(strip_tags($post['content'])) / 400));
$shareUrl = absolute_url(url('post', ['id' => (int) $post['id']]));
?>
<div class="breadcrumb">
    <a href="<?= e(url('home')) ?>">首页</a><?= icon('chevron_right', '', 15) ?>
    <a href="<?= e(url('posts')) ?>">文章</a><?= icon('chevron_right', '', 15) ?>
    <a href="<?= e(url('posts', ['board' => (int) $post['board_id']])) ?>"><?= e($post['board_name']) ?></a>
</div>

<?php if ($post['status'] !== 'published'): ?>
    <div class="notice notice--warning"><?= icon('info', '', 20) ?>这篇帖子当前状态为「<?= $post['status'] === 'deleted' ? '已删除' : '草稿' ?>」，只有作者和管理员可以查看。</div>
<?php endif; ?>

<div class="post-layout">
    <article class="article<?= $officialCard ? ' article--official' : '' ?>"<?= $officialCard ? ' style="--card-accent:' . e(official_color((int) $post['user_id'])) . '"' : '' ?>>
        <header class="article__head">
            <div class="article__chips">
                <a class="chip chip--board" href="<?= e(url('posts', ['board' => (int) $post['board_id']])) ?>" style="--chip-color:<?= e($post['board_color'] ?: '#4F5BD5') ?>"><?= e($post['board_name']) ?></a>
                <?php if ((int) $post['is_pinned'] === 1): ?><span class="chip chip--pin"><?= icon('pin', '', 13) ?>置顶</span><?php endif; ?>
                <?php if ((int) $post['is_featured'] === 1): ?><span class="chip chip--feature"><?= icon('star', '', 13) ?>精选</span><?php endif; ?>
            </div>
            <h1 class="article__title"><?= e($post['title']) ?></h1>
            <div class="article__meta">
                <a class="author-block" href="<?= e(url('user', ['id' => (int) $post['user_id']])) ?>">
                    <img class="avatar avatar--md" src="<?= e(avatar_url($author)) ?>" alt="">
                    <span>
                        <span class="author-block__name"><?= e($post['username']) ?> <?= badge_html((int) $post['user_id'], $author) ?></span>
                        <span class="author-block__sub"><span class="level-dot" style="--level-color:<?= e($level['color']) ?>">Lv.<?= (int) $level['level'] ?> <?= e($level['name']) ?></span></span>
                    </span>
                </a>
                <div class="article__meta-right">
                    <span><?= icon('clock', '', 16) ?><?= e(format_date($post['created_at'], 'Y-m-d H:i')) ?></span>
                    <span><?= icon('eye', '', 16) ?><?= short_number((int) $post['views']) ?> 次阅读</span>
                    <span><?= icon('article', '', 16) ?>约 <?= $readingMinutes ?> 分钟</span>
                </div>
            </div>
        </header>

        <?php if ($post['cover'] !== ''): ?>
            <figure class="article__cover"><img src="<?= e(media_url($post['cover'])) ?>" alt=""></figure>
        <?php endif; ?>

        <div class="article__content prose"><?= render_content($post['content']) ?></div>

        <?php if ($post['updated_at'] !== $post['created_at']): ?>
            <p class="article__updated">最后编辑于 <?= e(format_date($post['updated_at'], 'Y-m-d H:i')) ?></p>
        <?php endif; ?>

        <div class="article__actions">
            <?php if ($me): ?>
                <button class="action-pill<?= $liked ? ' is-active' : '' ?> js-post-like" type="button" data-post-id="<?= (int) $post['id'] ?>" data-count="<?= (int) $post['likes_count'] ?>">
                    <?= icon('thumb_up', '', 19) ?><span>点赞</span><b class="js-like-count"><?= (int) $post['likes_count'] ?></b>
                </button>
                <button class="action-pill<?= $favorited ? ' is-active' : '' ?> js-post-favorite" type="button" data-post-id="<?= (int) $post['id'] ?>" data-count="<?= (int) $post['favorites_count'] ?>">
                    <?= icon($favorited ? 'bookmark' : 'bookmark_border', '', 19) ?><span>收藏</span><b class="js-favorite-count"><?= (int) $post['favorites_count'] ?></b>
                </button>
                <button class="action-pill" type="button" data-open-reward>
                    <?= icon('coin', '', 19) ?><span>打赏</span><?php if ($rewardTotal > 0): ?><b><?= (int) $rewardTotal ?></b><?php endif; ?>
                </button>
            <?php else: ?>
                <a class="action-pill" href="<?= e(url('login', ['next' => url('post', ['id' => (int) $post['id']])])) ?>"><?= icon('thumb_up', '', 19) ?><span>登录后点赞</span></a>
                <a class="action-pill" href="<?= e(url('login', ['next' => url('post', ['id' => (int) $post['id']])])) ?>"><?= icon('bookmark_border', '', 19) ?><span>登录后收藏</span></a>
            <?php endif; ?>
            <button class="action-pill" type="button" data-share-url="<?= e($shareUrl) ?>" data-share-title="<?= e($post['title']) ?>"><?= icon('share', '', 19) ?><span>分享</span></button>
            <?php if ($canFeature): ?>
                <form action="<?= e(url('post.feature')) ?>" method="post" class="inline-form">
                    <?= csrf_field() ?>
                    <input type="hidden" name="post_id" value="<?= (int) $post['id'] ?>">
                    <button class="action-pill<?= (int) $post['is_featured'] === 1 ? ' is-active' : '' ?>" type="submit"><?= icon('star', '', 19) ?><span><?= (int) $post['is_featured'] === 1 ? '取消精选' : '设为精选' ?></span></button>
                </form>
            <?php endif; ?>
            <?php if ($canEdit): ?>
                <details class="menu more-menu">
                    <summary class="action-pill" aria-label="更多操作"><?= icon('more', '', 19) ?><span>管理</span></summary>
                    <div class="menu__panel">
                        <a class="menu__item" href="<?= e(url('publish', ['id' => (int) $post['id']])) ?>"><?= icon('edit') ?><span>编辑帖子</span></a>
                        <form action="<?= e(url('post.delete')) ?>" method="post" data-confirm="确定删除这篇帖子吗？">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int) $post['id'] ?>">
                            <button class="menu__item menu__item--danger" type="submit"><?= icon('trash') ?><span>删除帖子</span></button>
                        </form>
                    </div>
                </details>
            <?php endif; ?>
        </div>

        <?php if ($rewardTotal > 0): ?>
            <p class="reward-summary"><?= icon('coin', '', 17) ?>这篇帖子共收到 <strong><?= (int) $rewardTotal ?></strong> 金币打赏</p>
        <?php endif; ?>

        <div class="author-card">
            <img class="avatar avatar--lg" src="<?= e(avatar_url($author)) ?>" alt="">
            <div class="author-card__body">
                <div class="author-card__name"><?= e($post['username']) ?> <?= badge_html((int) $post['user_id'], $author) ?></div>
                <p><?= e($post['bio'] ?? '这个人很神秘，还没有写下简介。') ?></p>
                <div class="author-card__meta">Lv.<?= (int) $level['level'] ?> <?= e($level['name']) ?> · ID <?= (int) $post['user_id'] ?></div>
            </div>
            <?php if (!$isOwn && $me): ?>
                <a class="btn btn--tonal btn--sm" href="<?= e(url('messages', ['with' => (int) $post['user_id']])) ?>"><?= icon('mail', '', 17) ?>私信</a>
            <?php endif; ?>
        </div>
    </article>

    <aside class="post-sidebar">
        <section class="side-card">
            <div class="side-card__head"><h2>关于作者</h2></div>
            <div class="author-side">
                <img class="avatar avatar--md" src="<?= e(avatar_url($author)) ?>" alt="">
                <div>
                    <a href="<?= e(url('user', ['id' => (int) $post['user_id']])) ?>"><?= e($post['username']) ?></a>
                    <?= badge_html((int) $post['user_id'], $author) ?>
                    <p>Lv.<?= (int) $level['level'] ?> · <?= e($level['name']) ?></p>
                </div>
            </div>
            <a class="btn btn--outlined btn--full btn--sm" href="<?= e(url('user', ['id' => (int) $post['user_id']])) ?>">查看主页</a>
        </section>

        <?php if ($related): ?>
            <section class="side-card">
                <div class="side-card__head"><h2>相关文章</h2></div>
                <div class="mini-post-list">
                    <?php foreach ($related as $relatedPost): ?>
                        <a class="mini-post" href="<?= e(url('post', ['id' => (int) $relatedPost['id']])) ?>">
                            <span class="mini-post__title"><?= e($relatedPost['title']) ?></span>
                            <span class="mini-post__meta"><?= e(time_ago($relatedPost['created_at'])) ?> · <?= (int) $relatedPost['likes_count'] ?> 赞</span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>

        <section class="side-card">
            <div class="side-card__head"><h2>板块维护</h2></div>
            <div class="mod-list">
                <?php foreach ($boardMods as $mod): ?>
                    <a class="mod-item" href="<?= e(url('user', ['id' => (int) $mod['id']])) ?>">
                        <img class="avatar avatar--xs" src="<?= e(avatar_url($mod)) ?>" alt="">
                        <span><?= e($mod['username']) ?></span>
                        <span class="chip chip--soft"><?= $mod['role'] === 'owner' ? '板块主' : '副板块主' ?></span>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>

        <section class="side-card rules-card">
            <div class="side-card__head"><h2><?= icon('shield', '', 18) ?>社区约定</h2></div>
            <ul>
                <li>尊重原创，注明引用来源。</li>
                <li>友善讨论，对事不对人。</li>
                <li>不发布违法、广告与侵权内容。</li>
            </ul>
            <a class="text-link" href="<?= e(url('about')) ?>">阅读更多<?= icon('chevron_right', '', 16) ?></a>
        </section>
    </aside>
</div>

<section class="comments-section" id="comments">
    <div class="comments-section__head">
        <div>
            <span class="section__eyebrow">Comments</span>
            <h2>评论 <span class="count-badge"><?= $commentCount ?></span></h2>
        </div>
    </div>

    <?php if ($me): ?>
        <?php if (setting_bool('email_verify_required') && !email_verified($me)): ?>
            <div class="notice notice--warning"><?= icon('mail', '', 20) ?>请先验证邮箱后再发表评论。<a href="<?= e(url('verify_email')) ?>">去验证</a></div>
        <?php else: ?>
            <form class="comment-form comment-form--main" action="<?= e(url('comment.create')) ?>" method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="post_id" value="<?= (int) $post['id'] ?>">
                <img class="avatar avatar--sm" src="<?= e(avatar_url($me)) ?>" alt="">
                <div class="comment-form__body">
                    <textarea name="content" rows="4" maxlength="1000" placeholder="写下你的想法… 支持 @提及用户" required></textarea>
                    <div class="comment-form__foot">
                        <span>请保持友善与尊重。</span>
                        <button class="btn btn--primary btn--sm" type="submit"><?= icon('send', '', 17) ?>发表评论</button>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    <?php else: ?>
        <div class="comment-login">
            <p>登录后即可参与讨论。</p>
            <a class="btn btn--primary btn--sm" href="<?= e(url('login', ['next' => url('post', ['id' => (int) $post['id']])])) ?>">去登录</a>
            <a class="btn btn--text btn--sm" href="<?= e(url('register')) ?>">注册账号</a>
        </div>
    <?php endif; ?>

    <div class="comment-list">
        <?php if ($comments): ?>
            <?php foreach ($comments as $thread): ?>
                <?php $comment = $thread; $depth = 0; require LXL_VIEWS . '/partials/comment.php'; ?>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="empty-state empty-state--small">
                <?= icon('comment', '', 32) ?>
                <h3>还没有评论</h3>
                <p>来留下第一条友善的回应吧。</p>
            </div>
        <?php endif; ?>
    </div>
</section>

<dialog class="dialog" id="reward-dialog">
    <div class="dialog__head">
        <div><span class="dialog__eyebrow"><?= icon('coin', '', 18) ?> 支持作者</span><h2>打赏金币</h2></div>
        <button class="icon-btn" type="button" data-close-dialog aria-label="关闭"><?= icon('close') ?></button>
    </div>
    <?php if ($me): ?>
        <form action="<?= e(url('post.reward')) ?>" method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="post_id" value="<?= (int) $post['id'] ?>">
            <p class="dialog__text">当前余额 <strong><?= (int) $me['coins'] ?></strong> 金币。打赏会直接转给作者。</p>
            <div class="amount-presets">
                <?php foreach ([1, 5, 10, 20] as $amount): ?>
                    <button class="amount-chip" type="button" data-amount="<?= $amount ?>"><?= $amount ?> 金币</button>
                <?php endforeach; ?>
            </div>
            <label class="field"><span class="field__label">打赏数量</span><span class="field__box"><?= icon('coin') ?><input type="number" name="amount" id="reward-amount" min="1" max="1000" value="5" required></span></label>
            <button class="btn btn--primary btn--full" type="submit">确认打赏</button>
        </form>
    <?php else: ?>
        <p class="dialog__text">登录后即可打赏支持作者。</p>
        <a class="btn btn--primary btn--full" href="<?= e(url('login', ['next' => url('post', ['id' => (int) $post['id']])])) ?>">去登录</a>
    <?php endif; ?>
</dialog>
