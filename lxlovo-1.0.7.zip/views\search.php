<?php
$buildUrl = function (int $page) use ($q, $type): string {
    $params = ['q' => $q, 'page' => $page];
    if ($type !== 'all') {
        $params['type'] = $type;
    }
    return url('search', $params);
};
?>
<section class="search-hero">
    <span class="page-head__eyebrow">Search</span>
    <h1>全局搜索</h1>
    <form action="<?= e(url('search')) ?>" method="get" class="search-hero__form">
        <input type="hidden" name="r" value="search">
        <span class="search-hero__box"><?= icon('search', '', 22) ?><input type="search" name="q" value="<?= e($q) ?>" placeholder="搜索帖子、用户或板块…" maxlength="80" autofocus><button class="btn btn--primary" type="submit">搜索</button></span>
    </form>
    <div class="segmented segmented--center">
        <a class="segmented__item<?= $type === 'all' ? ' is-active' : '' ?>" href="<?= e(url('search', array_filter(['q' => $q ?: null]))) ?>">全部</a>
        <a class="segmented__item<?= $type === 'posts' ? ' is-active' : '' ?>" href="<?= e(url('search', array_filter(['q' => $q ?: null, 'type' => 'posts']))) ?>">帖子</a>
        <a class="segmented__item<?= $type === 'users' ? ' is-active' : '' ?>" href="<?= e(url('search', array_filter(['q' => $q ?: null, 'type' => 'users']))) ?>">用户</a>
        <a class="segmented__item<?= $type === 'boards' ? ' is-active' : '' ?>" href="<?= e(url('search', array_filter(['q' => $q ?: null, 'type' => 'boards']))) ?>">板块</a>
    </div>
</section>

<?php if ($q === ''): ?>
    <div class="empty-state search-empty">
        <?= icon('search', '', 40) ?>
        <h3>输入关键词开始搜索</h3>
        <p>可以搜索标题、正文、用户名、简介与板块。</p>
    </div>
<?php else: ?>
    <p class="result-meta">关于“<strong><?= e($q) ?></strong>”的搜索结果<?= ($type === 'all' || $type === 'posts') ? '，共 ' . (int) $total . ' 篇文章' : '' ?></p>

    <?php if ($posts): ?>
        <section class="section">
            <div class="section__head"><div><span class="section__eyebrow">Posts</span><h2>帖子</h2></div><span class="chip chip--soft"><?= (int) $total ?> 篇</span></div>
            <div class="post-grid">
                <?php foreach ($posts as $post): ?>
                    <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
                <?php endforeach; ?>
            </div>
            <?php if ($type === 'posts' || $type === 'all'): ?><?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?><?php endif; ?>
        </section>
    <?php endif; ?>

    <?php if ($users): ?>
        <section class="section">
            <div class="section__head"><div><span class="section__eyebrow">People</span><h2>用户</h2></div></div>
            <div class="user-grid">
                <?php foreach ($users as $resultUser): ?>
                    <?php $level = level_for_exp((int) $resultUser['exp']); ?>
                    <a class="user-card" href="<?= e(url('user', ['id' => (int) $resultUser['id']])) ?>">
                        <img class="avatar avatar--md" src="<?= e(avatar_url($resultUser)) ?>" alt="">
                        <span class="user-card__body">
                            <span class="user-card__name"><?= e($resultUser['username']) ?> <?= badge_html((int) $resultUser['id'], $resultUser) ?></span>
                            <span class="user-card__bio"><?= e($resultUser['bio'] ?: '这个人还没有写下简介。') ?></span>
                            <span class="user-card__meta">Lv.<?= (int) $level['level'] ?> · <?= is_online($resultUser) ? '在线' : '离线' ?></span>
                        </span>
                        <?= icon('chevron_right', '', 18) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if ($boards): ?>
        <section class="section">
            <div class="section__head"><div><span class="section__eyebrow">Boards</span><h2>板块</h2></div></div>
            <div class="board-grid">
                <?php foreach ($boards as $resultBoard): ?>
                    <a class="board-tile" href="<?= e(url('posts', ['board' => (int) $resultBoard['id']])) ?>" style="--board-color:<?= e($resultBoard['color']) ?>">
                        <span class="board-tile__icon"><?= icon($resultBoard['icon'] ?: 'board', '', 22) ?></span>
                        <span class="board-tile__body"><strong><?= e($resultBoard['name']) ?></strong><span><?= e($resultBoard['description']) ?></span></span>
                        <?= icon('chevron_right', '', 18) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

    <?php if (!$posts && !$users && !$boards): ?>
        <div class="empty-state"><?= icon('search', '', 38) ?><h3>没有找到相关内容</h3><p>试试更短的关键词，或者换一个说法。</p><a class="btn btn--tonal" href="<?= e(url('posts')) ?>">浏览全部文章</a></div>
    <?php endif; ?>
<?php endif; ?>
