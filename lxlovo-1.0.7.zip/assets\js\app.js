(() => {
    'use strict';

    const LXL = window.LXL || {};
    const doc = document;
    const root = doc.documentElement;
    const csrf = (doc.querySelector('meta[name="csrf-token"]') || {}).content || LXL.csrf || '';
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    const $ = (selector, scope = doc) => scope.querySelector(selector);
    const $$ = (selector, scope = doc) => Array.from(scope.querySelectorAll(selector));

    function toast(message, type = 'info', timeout = 3200) {
        let stack = $('.toast-stack');
        if (!stack) {
            stack = doc.createElement('div');
            stack.className = 'toast-stack';
            doc.body.appendChild(stack);
        }
        const item = doc.createElement('div');
        item.className = `toast toast--${type}`;
        item.textContent = message;
        stack.appendChild(item);
        requestAnimationFrame(() => item.classList.add('is-visible'));
        setTimeout(() => {
            item.classList.remove('is-visible');
            setTimeout(() => item.remove(), 250);
        }, timeout);
    }

    async function request(url, options = {}) {
        const headers = new Headers(options.headers || {});
        headers.set('X-Requested-With', 'XMLHttpRequest');
        if (csrf) headers.set('X-CSRF-Token', csrf);
        const response = await fetch(url, { credentials: 'same-origin', ...options, headers });
        let data = null;
        try { data = await response.json(); } catch (e) {}
        if (!response.ok || !data || data.ok === false) {
            throw new Error((data && data.message) || '操作失败，请稍后重试。');
        }
        return data;
    }

    function closeDetailsOutside(event) {
        $$('details.menu[open]').forEach((details) => {
            if (!details.contains(event.target)) details.removeAttribute('open');
        });
    }

    doc.addEventListener('click', closeDetailsOutside);

    /* ----------------------------------------------------------------------
       Theme
       ---------------------------------------------------------------------- */

    const themeMedia = window.matchMedia('(prefers-color-scheme: dark)');

    function applyTheme(mode, persist = false) {
        if (!['light', 'dark', 'system'].includes(mode)) mode = 'light';
        const dark = mode === 'dark' || (mode === 'system' && themeMedia.matches);
        root.dataset.theme = dark ? 'dark' : 'light';
        root.dataset.themeMode = mode;
        if (persist) {
            try { localStorage.setItem('lxlovo-theme', mode); } catch (e) {}
        }
        $$('[data-theme-set]').forEach((button) => {
            button.classList.toggle('is-active', button.dataset.themeSet === mode);
        });
        const meta = doc.querySelector('meta[name="theme-color"]');
        if (meta) meta.setAttribute('content', dark ? '#131318' : '#fbf8ff');
    }

    applyTheme(root.dataset.themeMode || 'light');

    $$('[data-theme-set]').forEach((button) => {
        button.addEventListener('click', () => {
            applyTheme(button.dataset.themeSet, true);
            const details = button.closest('details');
            if (details) details.removeAttribute('open');
        });
    });

    themeMedia.addEventListener('change', () => {
        if (root.dataset.themeMode === 'system') applyTheme('system');
    });

    /* ----------------------------------------------------------------------
       Drawer / dialogs / flashes
       ---------------------------------------------------------------------- */

    const drawer = $('#site-drawer');
    const drawerScrim = $('.drawer-scrim');

    function setDrawer(open) {
        if (!drawer) return;
        drawer.classList.toggle('is-open', open);
        drawer.setAttribute('aria-hidden', open ? 'false' : 'true');
        if (drawerScrim) drawerScrim.hidden = !open;
        doc.body.classList.toggle('no-scroll', open);
    }

    $$('[data-drawer-open]').forEach((button) => button.addEventListener('click', () => setDrawer(true)));
    $$('[data-drawer-close]').forEach((button) => button.addEventListener('click', () => setDrawer(false)));
    if (drawer) {
        $$('a', drawer).forEach((link) => link.addEventListener('click', () => setDrawer(false)));
    }

    const adminSidebar = $('#admin-sidebar');
    const adminScrim = $('.admin-scrim');

    function setAdminMenu(open) {
        if (!adminSidebar) return;
        adminSidebar.classList.toggle('is-open', open);
        if (adminScrim) adminScrim.hidden = !open;
        doc.body.classList.toggle('no-scroll', open);
    }

    $$('[data-admin-menu-open]').forEach((button) => button.addEventListener('click', () => setAdminMenu(true)));
    $$('[data-admin-menu-close]').forEach((button) => button.addEventListener('click', () => setAdminMenu(false)));

    $$('[data-close-dialog]').forEach((button) => {
        button.addEventListener('click', () => {
            const dialog = button.closest('dialog');
            if (dialog) dialog.close();
        });
    });

    $$('dialog').forEach((dialog) => {
        dialog.addEventListener('click', (event) => {
            if (event.target !== dialog) return;
            const rect = dialog.getBoundingClientRect();
            if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) {
                dialog.close();
            }
        });
    });

    $$('[data-dismiss="flash"]').forEach((button) => {
        button.addEventListener('click', () => {
            const flash = button.closest('.flash');
            if (flash) {
                flash.style.opacity = '0';
                flash.style.transform = 'translateY(-6px)';
                setTimeout(() => flash.remove(), 200);
            }
        });
    });

    const searchDialog = $('#search-dialog');
    $$('[data-open-search]').forEach((button) => {
        button.addEventListener('click', () => {
            if (searchDialog && !searchDialog.open) {
                searchDialog.showModal();
                const input = $('input[type="search"]', searchDialog);
                if (input) setTimeout(() => input.focus(), 50);
            }
        });
    });

    /* ----------------------------------------------------------------------
       Broken images
       ---------------------------------------------------------------------- */

    $$('img.avatar').forEach((img) => {
        img.addEventListener('error', () => {
            if (img.dataset.fallbackApplied) return;
            img.dataset.fallbackApplied = '1';
            img.src = `${LXL.base}/assets/img/default-avatar.svg`;
        });
        if (img.complete && img.naturalWidth === 0) {
            img.dataset.fallbackApplied = '1';
            img.src = `${LXL.base}/assets/img/default-avatar.svg`;
        }
    });

    $$('.post-card__cover img, .article__cover img').forEach((img) => {
        const removeBroken = () => {
            const wrapper = img.closest('.post-card__cover, .article__cover');
            if (wrapper) wrapper.remove();
        };
        img.addEventListener('error', removeBroken);
        if (img.complete && img.naturalWidth === 0) removeBroken();
    });

    /* ----------------------------------------------------------------------
       Announcements
       ---------------------------------------------------------------------- */

    const announcementDialog = $('#announcement-dialog');
    if (announcementDialog) {
        const logged = announcementDialog.dataset.logged === '1';
        let marked = false;
        setTimeout(() => {
            if (!announcementDialog.open) {
                try { announcementDialog.showModal(); } catch (e) {}
            }
        }, 420);

        const markSeen = async () => {
            if (marked) return;
            marked = true;
            const now = new Date();
            const localDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
            const items = $$('[data-announcement-id]', announcementDialog);
            for (const item of items) {
                const id = item.dataset.announcementId;
                const mode = item.dataset.mode;
                if (!id) continue;
                if (!logged) {
                    const value = mode === 'once' ? '1' : localDate;
                    doc.cookie = `lxl_ann_${id}=${encodeURIComponent(value)}; path=/; max-age=31536000; SameSite=Lax`;
                } else {
                    try {
                        await fetch(LXL.routes.announcementSeen, {
                            method: 'POST',
                            credentials: 'same-origin',
                            headers: {
                                'Content-Type': 'application/x-www-form-urlencoded',
                                'X-Requested-With': 'XMLHttpRequest',
                                'X-CSRF-Token': csrf
                            },
                            body: new URLSearchParams({ id, _token: csrf })
                        });
                    } catch (e) {}
                }
            }
        };

        $$('[data-announcement-close]', announcementDialog).forEach((button) => {
            button.addEventListener('click', () => {
                markSeen().finally(() => announcementDialog.close());
            });
        });
        announcementDialog.addEventListener('close', markSeen);
    }

    /* ----------------------------------------------------------------------
       Carousel
       ---------------------------------------------------------------------- */

    $$('[data-carousel]').forEach((carousel) => {
        const slides = $$('[data-slide]', carousel);
        const dots = $$('[data-carousel-dot]', carousel);
        if (slides.length < 2) return;
        let index = 0;
        let timer = null;

        const show = (next) => {
            index = (next + slides.length) % slides.length;
            slides.forEach((slide, i) => slide.classList.toggle('is-active', i === index));
            dots.forEach((dot, i) => dot.classList.toggle('is-active', i === index));
        };
        const start = () => {
            if (reduceMotion) return;
            stop();
            timer = setInterval(() => show(index + 1), 6500);
        };
        const stop = () => { if (timer) clearInterval(timer); };

        const prev = $('[data-carousel-prev]', carousel);
        const next = $('[data-carousel-next]', carousel);
        if (prev) prev.addEventListener('click', () => { show(index - 1); start(); });
        if (next) next.addEventListener('click', () => { show(index + 1); start(); });
        dots.forEach((dot) => dot.addEventListener('click', () => { show(Number(dot.dataset.carouselDot)); start(); }));
        carousel.addEventListener('mouseenter', stop);
        carousel.addEventListener('mouseleave', start);
        start();
    });

    /* ----------------------------------------------------------------------
       Post interactions
       ---------------------------------------------------------------------- */

    $$('.js-post-like').forEach((button) => {
        button.addEventListener('click', async () => {
            button.disabled = true;
            try {
                const data = await request(LXL.routes.like, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ post_id: button.dataset.postId, _token: csrf })
                });
                button.classList.toggle('is-active', data.liked);
                const count = button.querySelector('.js-like-count');
                if (count) count.textContent = data.count;
                button.dataset.count = data.count;
            } catch (error) {
                toast(error.message, 'error');
            } finally {
                button.disabled = false;
            }
        });
    });

    $$('.js-post-favorite').forEach((button) => {
        button.addEventListener('click', async () => {
            button.disabled = true;
            try {
                const data = await request(LXL.routes.favorite, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ post_id: button.dataset.postId, _token: csrf })
                });
                button.classList.toggle('is-active', data.favorited);
                const count = button.querySelector('.js-favorite-count');
                if (count) count.textContent = data.count;
                toast(data.favorited ? '已收藏' : '已取消收藏', 'success', 1800);
            } catch (error) {
                toast(error.message, 'error');
            } finally {
                button.disabled = false;
            }
        });
    });

    $$('.js-comment-like').forEach((button) => {
        button.addEventListener('click', async () => {
            button.disabled = true;
            try {
                const data = await request(`${LXL.base}/index.php?r=comment.like`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams({ comment_id: button.dataset.commentId, _token: csrf })
                });
                button.classList.toggle('is-active', data.liked);
                const count = button.querySelector('.js-like-count');
                if (count) count.textContent = data.count;
            } catch (error) {
                toast(error.message, 'error');
            } finally {
                button.disabled = false;
            }
        });
    });

    $$('[data-reply-toggle]').forEach((button) => {
        button.addEventListener('click', () => {
            const form = $(`[data-reply-form="${button.dataset.replyToggle}"]`);
            if (!form) return;
            form.hidden = !form.hidden;
            if (!form.hidden) {
                const textarea = $('textarea', form);
                if (textarea) textarea.focus();
            }
        });
    });

    const rewardDialog = $('#reward-dialog');
    $$('[data-open-reward]').forEach((button) => {
        button.addEventListener('click', () => {
            if (rewardDialog && !rewardDialog.open) rewardDialog.showModal();
        });
    });
    $$('.amount-chip').forEach((button) => {
        button.addEventListener('click', () => {
            $$('.amount-chip').forEach((item) => item.classList.remove('is-active'));
            button.classList.add('is-active');
            const input = $('#reward-amount');
            if (input) input.value = button.dataset.amount;
        });
    });

    $$('[data-share-url]').forEach((button) => {
        button.addEventListener('click', async () => {
            const url = button.dataset.shareUrl;
            const title = button.dataset.shareTitle || doc.title;
            try {
                if (navigator.share) {
                    await navigator.share({ title, url });
                    return;
                }
                await navigator.clipboard.writeText(url);
                toast('链接已复制', 'success');
            } catch (error) {
                if (error && error.name === 'AbortError') return;
                const textarea = doc.createElement('textarea');
                textarea.value = url;
                textarea.style.position = 'fixed';
                textarea.style.opacity = '0';
                doc.body.appendChild(textarea);
                textarea.select();
                try {
                    doc.execCommand('copy');
                    toast('链接已复制', 'success');
                } catch (e) {
                    toast(url, 'info', 6000);
                }
                textarea.remove();
            }
        });
    });

    $$('form[data-confirm]').forEach((form) => {
        form.addEventListener('submit', (event) => {
            if (!window.confirm(form.dataset.confirm || '确定继续吗？')) event.preventDefault();
        });
    });

    /* ----------------------------------------------------------------------
       Admin batch selection
       ---------------------------------------------------------------------- */

    const checkItems = $$('[data-check-item]');
    if (checkItems.length) {
        const updateBatchState = (group) => {
            const items = $$(`[data-check-item="${group}"]`);
            const checked = items.filter((item) => item.checked).length;
            $$(`[data-check-all="${group}"]`).forEach((box) => {
                box.checked = items.length > 0 && checked === items.length;
                box.indeterminate = checked > 0 && checked < items.length;
            });
            $$(`[data-check-count="${group}"]`).forEach((count) => {
                count.textContent = String(checked);
            });
        };

        $$('[data-check-all]').forEach((box) => {
            box.addEventListener('change', () => {
                const group = box.dataset.checkAll;
                $$(`[data-check-item="${group}"]`).forEach((item) => {
                    item.checked = box.checked;
                });
                updateBatchState(group);
            });
        });

        checkItems.forEach((item) => {
            item.addEventListener('change', () => updateBatchState(item.dataset.checkItem));
        });

        $$('[data-batch-form]').forEach((form) => {
            form.addEventListener('submit', (event) => {
                const action = form.querySelector('[data-batch-action]')?.value || '';
                const group = form.querySelector('[data-check-group]')?.value
                    || form.dataset.checkGroup
                    || 'posts';
                const checked = $$(`[data-check-item="${group}"]`).filter((item) => item.checked).length;
                if (checked === 0) {
                    event.preventDefault();
                    toast('请先选择要处理的帖子。', 'error');
                    return;
                }
                if (!action) {
                    event.preventDefault();
                    toast('请选择批量操作。', 'error');
                    return;
                }
                if (action === 'purge' && !window.confirm(`将彻底删除选中的 ${checked} 篇帖子，删除后无法恢复，相关评论、互动数据与未被引用的本地图片也会被清理。确定继续吗？`)) {
                    event.preventDefault();
                    return;
                }
                if (action === 'delete' && !window.confirm(`将选中的 ${checked} 篇帖子移入回收站？`)) {
                    event.preventDefault();
                }
            });
        });
    }

    /* ----------------------------------------------------------------------
       Avatar preview
       ---------------------------------------------------------------------- */

    const avatarInput = $('[data-avatar-input]');
    if (avatarInput) {
        avatarInput.addEventListener('change', () => {
            const file = avatarInput.files && avatarInput.files[0];
            if (!file) return;
            const preview = $('#avatar-preview');
            if (preview) preview.src = URL.createObjectURL(file);
        });
    }

    /* ----------------------------------------------------------------------
       Rich editor
       ---------------------------------------------------------------------- */

    const editor = $('#rich-content');
    if (editor) {
        const source = $('#content-source');
        const form = $('#post-form');
        const counter = $('#editor-word-count');
        let savedRange = null;

        if (source && source.value.trim() !== '') {
            editor.innerHTML = source.value;
        }

        const updateCount = () => {
            if (counter) counter.textContent = `${(editor.innerText || '').trim().length} 字`;
        };
        updateCount();
        editor.addEventListener('input', updateCount);

        const saveSelection = () => {
            const selection = window.getSelection();
            if (selection && selection.rangeCount && editor.contains(selection.anchorNode)) {
                savedRange = selection.getRangeAt(0).cloneRange();
            }
        };
        doc.addEventListener('selectionchange', saveSelection);

        const restoreSelection = () => {
            editor.focus();
            if (!savedRange) return;
            const selection = window.getSelection();
            if (!selection) return;
            selection.removeAllRanges();
            selection.addRange(savedRange);
        };

        const command = (name, value = null) => {
            restoreSelection();
            try { doc.execCommand(name, false, value); } catch (e) {}
            updateCount();
            saveSelection();
        };

        $$('[data-cmd]', editor.closest('.rich-editor')).forEach((button) => {
            button.addEventListener('click', () => command(button.dataset.cmd));
        });
        $$('[data-block]', editor.closest('.rich-editor')).forEach((button) => {
            button.addEventListener('click', () => {
                const current = doc.queryCommandValue('formatBlock');
                const tag = (current || '').toLowerCase() === button.dataset.block ? 'p' : button.dataset.block;
                command('formatBlock', tag);
            });
        });
        const colorInput = $('[data-fore-color]');
        if (colorInput) colorInput.addEventListener('input', () => command('foreColor', colorInput.value));
        const sizeSelect = $('[data-font-size]');
        if (sizeSelect) sizeSelect.addEventListener('change', () => {
            if (sizeSelect.value) command('fontSize', sizeSelect.value);
            sizeSelect.value = '';
        });

        const insertDialog = $('#insert-dialog');
        const insertForm = $('#insert-form');
        const insertUrl = $('#insert-url');
        const insertText = $('#insert-text');
        const insertTextField = $('#insert-text-field');
        let insertType = 'link';

        const openInsert = (type) => {
            insertType = type;
            if (!insertDialog) return;
            const labels = {
                link: ['插入链接', '链接地址', '显示文字', '支持站外链接。'],
                image: ['插入图片', '图片地址', '图片描述（可选）', '支持 http(s) 外链图片。'],
                video: ['插入视频', '视频页面地址', '视频标题（可选）', '支持 Bilibili、YouTube、腾讯视频、优酷。']
            };
            const config = labels[type] || labels.link;
            $('#insert-dialog-title').textContent = config[0];
            $('#insert-url-label').textContent = config[1];
            $('#insert-hint').textContent = config[3];
            insertTextField.hidden = type === 'video';
            insertUrl.value = '';
            insertText.value = '';
            insertDialog.showModal();
            setTimeout(() => insertUrl.focus(), 60);
        };

        $$('[data-insert]', editor.closest('.rich-editor')).forEach((button) => {
            button.addEventListener('click', () => openInsert(button.dataset.insert));
        });

        const escapeAttr = (value) => String(value).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

        if (insertForm) {
            insertForm.addEventListener('submit', (event) => {
                event.preventDefault();
                const url = insertUrl.value.trim();
                if (!/^https?:\/\//i.test(url)) {
                    toast('请输入以 http:// 或 https:// 开头的地址', 'error');
                    return;
                }
                const text = insertText.value.trim();
                let html = '';
                if (insertType === 'link') {
                    html = `<a href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">${escapeAttr(text || url)}</a>`;
                } else if (insertType === 'image') {
                    html = `<p><img src="${escapeAttr(url)}" alt="${escapeAttr(text)}" loading="lazy"></p>`;
                } else {
                    html = `<div class="video-embed" data-video="${escapeAttr(url)}"><a href="${escapeAttr(url)}" target="_blank" rel="noopener">${escapeAttr(text || ('视频：' + url))}</a></div>`;
                }
                restoreSelection();
                try { doc.execCommand('insertHTML', false, html); } catch (e) {}
                insertDialog.close();
                updateCount();
                saveSelection();
            });
        }

        const uploadButton = $('[data-upload-image]');
        const imageInput = $('#editor-image-input');
        if (uploadButton && imageInput) {
            uploadButton.addEventListener('click', () => imageInput.click());
            imageInput.addEventListener('change', async () => {
                const file = imageInput.files && imageInput.files[0];
                if (!file) return;
                const maxKb = Number(editor.closest('.rich-editor').dataset.maxKb || 100);
                if (file.size > 12 * 1024 * 1024) {
                    toast('原图不能超过 12MB', 'error');
                    return;
                }
                const formData = new FormData();
                formData.append('image', file);
                uploadButton.disabled = true;
                toast('正在上传并压缩图片…', 'info', 1500);
                try {
                    const data = await request(LXL.routes.upload, { method: 'POST', body: formData });
                    restoreSelection();
                    doc.execCommand('insertHTML', false, `<p><img src="${escapeAttr(data.url)}" alt="${escapeAttr(file.name)}" loading="lazy"></p>`);
                    toast('图片已插入', 'success');
                    updateCount();
                } catch (error) {
                    toast(error.message, 'error');
                } finally {
                    uploadButton.disabled = false;
                    imageInput.value = '';
                }
            });
        }

        if (form) {
            form.addEventListener('submit', (event) => {
                const text = (editor.innerText || '').trim();
                if (!text) {
                    event.preventDefault();
                    toast('正文内容不能为空。', 'error');
                    editor.focus();
                    return;
                }
                if (source) source.value = editor.innerHTML;
            });
        }
    }

    /* ----------------------------------------------------------------------
       Settings tabs / anchors
       ---------------------------------------------------------------------- */

    const tabs = $('[data-settings-tabs]');
    if (tabs) {
        const activate = (name) => {
            $$('.settings-tab', tabs).forEach((tab) => tab.classList.toggle('is-active', tab.dataset.tab === name));
            $$('.settings-panel').forEach((panel) => panel.classList.toggle('is-active', panel.dataset.panel === name));
        };
        $$('.settings-tab', tabs).forEach((tab) => tab.addEventListener('click', () => activate(tab.dataset.tab)));
        if (window.location.hash === '#email') {
            activate('email');
            setTimeout(() => $('#email')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 80);
        }
    }

    /* ----------------------------------------------------------------------
       Misc
       ---------------------------------------------------------------------- */

    const chatMessages = $('#chat-messages');
    if (chatMessages) chatMessages.scrollTop = chatMessages.scrollHeight;

    const settingsNavLinks = $$('.settings-nav a');
    if (settingsNavLinks.length && 'IntersectionObserver' in window) {
        const panels = settingsNavLinks.map((link) => $(link.getAttribute('href'))).filter(Boolean);
        const observer = new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
                if (!entry.isIntersecting) return;
                settingsNavLinks.forEach((link) => link.classList.toggle('is-active', link.getAttribute('href') === `#${entry.target.id}`));
            });
        }, { rootMargin: '-25% 0px -60% 0px', threshold: 0 });
        panels.forEach((panel) => observer.observe(panel));
    }

    $$('a[href^="#"]').forEach((link) => {
        link.addEventListener('click', () => {
            $$('.settings-nav a').forEach((item) => item.classList.toggle('is-active', item === link));
        });
    });
})();
