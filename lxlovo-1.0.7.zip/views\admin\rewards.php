<?php ?>
<div class="admin-page-head"><div><span class="admin-eyebrow">Check-in</span><h2>签到奖励</h2><p>连续签到达到对应天数时发放奖励；超过最高配置后一直按最高档计算。</p></div></div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>新增奖励档位</h3></div>
        <form action="<?= e(admin_url('reward.save')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="0">
            <div class="admin-form-grid">
                <label class="field"><span class="field__label">连续天数</span><span class="field__box"><input type="number" name="streak_days" min="1" max="3650" required></span></label>
                <label class="field"><span class="field__label">经验</span><span class="field__box"><input type="number" name="exp" min="0" value="3" required></span></label>
                <label class="field"><span class="field__label">金币</span><span class="field__box"><input type="number" name="coins" min="0" value="1" required></span></label>
            </div>
            <div class="form-actions"><button class="btn btn--primary" type="submit">添加档位</button></div>
        </form>
    </section>
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>规则说明</h3></div>
        <div class="admin-note">
            <p>每日普通签到默认 3 经验 + 1 金币；连续签到按天数取满足条件的最高档位。</p>
            <p>例如连续 31 天仍按 30 天档位发放，未配置的天数不会中断签到。</p>
        </div>
    </section>
</div>

<div class="admin-stack">
    <?php foreach ($items as $item): ?>
        <section class="admin-panel admin-edit-row">
            <form action="<?= e(admin_url('reward.save')) ?>" method="post" class="reward-row">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int) $item['id'] ?>">
                <span class="reward-row__badge"><?= icon('gift', '', 20) ?>第 <?= (int) $item['streak_days'] ?> 天</span>
                <label class="field"><span class="field__label">连续天数</span><span class="field__box"><input type="number" name="streak_days" value="<?= (int) $item['streak_days'] ?>" min="1" required></span></label>
                <label class="field"><span class="field__label">经验</span><span class="field__box"><input type="number" name="exp" value="<?= (int) $item['exp'] ?>" min="0" required></span></label>
                <label class="field"><span class="field__label">金币</span><span class="field__box"><input type="number" name="coins" value="<?= (int) $item['coins'] ?>" min="0" required></span></label>
                <button class="btn btn--tonal btn--sm" type="submit">保存</button>
            </form>
            <form action="<?= e(admin_url('reward.delete')) ?>" method="post" data-confirm="确定删除这个奖励档位吗？" class="admin-delete-form admin-delete-form--inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $item['id'] ?>"><button class="table-action table-action--danger" type="submit">删除</button></form>
        </section>
    <?php endforeach; ?>
</div>
