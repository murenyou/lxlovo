<?php ?>
<section class="page-head">
    <div>
        <span class="page-head__eyebrow">Friends</span>
        <h1>友情链接</h1>
        <p>一些值得被看见的站点与伙伴。</p>
    </div>
    <a class="btn btn--outlined" href="<?= e(url('about')) ?>">关于本站</a>
</section>

<?php if ($groups): ?>
    <?php foreach ($groups as $tag => $items): ?>
        <section class="section links-section">
            <div class="section__head"><div><span class="section__eyebrow">Links</span><h2><?= e($tag) ?></h2></div><span class="chip chip--soft"><?= count($items) ?> 个</span></div>
            <div class="link-grid">
                <?php foreach ($items as $link): ?>
                    <a class="link-card" href="<?= e($link['url']) ?>" target="_blank" rel="noopener">
                        <span class="link-card__logo">
                            <?php if ($link['logo'] !== ''): ?>
                                <img src="<?= e(media_url($link['logo'])) ?>" alt="" loading="lazy">
                            <?php else: ?>
                                <?= e(mb_substr($link['name'], 0, 1)) ?>
                            <?php endif; ?>
                        </span>
                        <span class="link-card__body">
                            <strong><?= e($link['name']) ?></strong>
                            <span><?= e($link['description'] ?: '一个值得访问的站点') ?></span>
                        </span>
                        <?= icon('external', '', 18) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
<?php else: ?>
    <div class="empty-state"><?= icon('link', '', 38) ?><h3>还没有友链</h3><p>管理员可以在后台添加友情链接。</p></div>
<?php endif; ?>

<section class="callout">
    <div>
        <span class="callout__icon"><?= icon('link', '', 24) ?></span>
        <div><h2>想交换友链？</h2><p>欢迎认真运营、内容友善的站点。请联系管理员并提供站点名称、地址与简介。</p></div>
    </div>
    <a class="btn btn--outlined" href="<?= e(url('about')) ?>">了解我们</a>
</section>
