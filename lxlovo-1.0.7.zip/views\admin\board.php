<?php
$isEdit = $board !== null;
$coownerIds = array_pad($coownerIds, 3, 0);
?>
<div class="admin-page-head">
    <div><span class="admin-eyebrow">Board</span><h2><?= $isEdit ? '编辑板块' : '新建板块' ?></h2><p>设置板块信息与维护团队。</p></div>
    <a class="btn btn--outlined btn--sm" href="<?= e(admin_url('boards')) ?>"><?= icon('arrow_back', '', 17) ?>返回列表</a>
</div>

<div class="admin-grid admin-grid--2">
    <section class="admin-panel">
        <div class="admin-panel__head"><h3>基本信息</h3></div>
        <form action="<?= e(admin_url('board.save')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) ($board['id'] ?? 0) ?>">
            <div class="admin-form-grid">
                <label class="field"><span class="field__label">板块名称</span><span class="field__box"><input type="text" name="name" value="<?= e($board['name'] ?? '') ?>" maxlength="40" required></span></label>
                <label class="field"><span class="field__label">板块标识</span><span class="field__box"><input type="text" name="slug" value="<?= e($board['slug'] ?? '') ?>" maxlength="60" placeholder="例如 tech"></span><span class="field__hint">小写字母、数字和短横线。</span></label>
                <label class="field field--span-2"><span class="field__label">简介</span><span class="field__box field__box--textarea"><textarea name="description" rows="3" maxlength="255" placeholder="这个板块聊些什么？"><?= e($board['description'] ?? '') ?></textarea></span></label>
                <label class="field"><span class="field__label">图标</span><span class="field__box"><input type="text" name="icon" value="<?= e($board['icon'] ?? 'board') ?>" maxlength="40" placeholder="board"></span><span class="field__hint">可用：board、forum、code、coffee、campaign、image。</span></label>
                <label class="field"><span class="field__label">颜色</span><span class="field__box field__box--color"><input type="color" name="color" value="<?= e($board['color'] ?? '#6750A4') ?>"></span></label>
                <label class="field"><span class="field__label">排序</span><span class="field__box"><input type="number" name="sort" value="<?= (int) ($board['sort'] ?? 10) ?>"></span></label>
                <label class="field"><span class="field__label">状态</span><span class="field__box field__box--select"><select name="status"><option value="active" <?= ($board['status'] ?? 'active') === 'active' ? 'selected' : '' ?>>显示</option><option value="hidden" <?= ($board['status'] ?? '') === 'hidden' ? 'selected' : '' ?>>隐藏</option></select></span></label>
            </div>
            <div class="form-actions"><button class="btn btn--primary" type="submit">保存板块</button></div>
        </form>
    </section>

    <section class="admin-panel">
        <div class="admin-panel__head"><h3>板块维护</h3><span>1 位板块主 + 最多 3 位副板块主</span></div>
        <?php if ($isEdit): ?>
        <form action="<?= e(admin_url('board.save')) ?>" method="post" class="admin-form">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) ($board['id'] ?? 0) ?>">
            <input type="hidden" name="name" value="<?= e($board['name'] ?? '') ?>">
            <input type="hidden" name="slug" value="<?= e($board['slug'] ?? 'board-' . time()) ?>">
            <input type="hidden" name="description" value="<?= e($board['description'] ?? '') ?>">
            <input type="hidden" name="icon" value="<?= e($board['icon'] ?? 'board') ?>">
            <input type="hidden" name="color" value="<?= e($board['color'] ?? '#6750A4') ?>">
            <input type="hidden" name="sort" value="<?= (int) ($board['sort'] ?? 10) ?>">
            <input type="hidden" name="status" value="<?= e($board['status'] ?? 'active') ?>">
            <label class="field"><span class="field__label">板块主</span><span class="field__box field__box--select"><select name="owner_id"><option value="0">暂不设置</option><?php foreach ($users as $user): ?><option value="<?= (int) $user['id'] ?>" <?= $ownerId === (int) $user['id'] ? 'selected' : '' ?>>#<?= (int) $user['id'] ?> · <?= e($user['username']) ?></option><?php endforeach; ?></select></span></label>
            <?php foreach ([0, 1, 2] as $index): ?>
                <label class="field"><span class="field__label">副板块主 <?= $index + 1 ?></span><span class="field__box field__box--select"><select name="coowner_ids[]"><option value="0">不设置</option><?php foreach ($users as $user): ?><option value="<?= (int) $user['id'] ?>" <?= (int) ($coownerIds[$index] ?? 0) === (int) $user['id'] ? 'selected' : '' ?>>#<?= (int) $user['id'] ?> · <?= e($user['username']) ?></option><?php endforeach; ?></select></span></label>
            <?php endforeach; ?>
            <p class="field__hint">保存后会覆盖该板块原有的维护者配置。</p>
            <div class="form-actions"><button class="btn btn--primary" type="submit">保存维护团队</button></div>
        </form>
        <?php else: ?>
            <div class="admin-note"><p>先保存板块基本信息，再设置板块主与副板块主。</p></div>
        <?php endif; ?>
        <?php if ($isEdit): ?>
            <div class="danger-zone danger-zone--admin">
                <h4>删除板块</h4>
                <p>只有板块内没有帖子时才能删除，否则请设为隐藏。</p>
                <form action="<?= e(admin_url('board.delete')) ?>" method="post" data-confirm="确定删除这个板块吗？"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $board['id'] ?>"><button class="btn btn--danger btn--sm" type="submit"><?= icon('trash', '', 16) ?>删除板块</button></form>
            </div>
        <?php endif; ?>
    </section>
</div>
