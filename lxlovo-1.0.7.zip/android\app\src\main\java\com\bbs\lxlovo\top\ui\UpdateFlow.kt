package com.bbs.lxlovo.top.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.BuildConfig
import com.bbs.lxlovo.top.data.AppRelease
import com.bbs.lxlovo.top.data.UpdateInfo
import com.bbs.lxlovo.top.util.ApkDownloader
import com.bbs.lxlovo.top.util.installApk
import java.io.File
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

private enum class UpdateStage { Prompt, Downloading, Downloaded, Error, PageOpened }

@Composable
fun UpdateFlowDialog(
    info: UpdateInfo,
    onDismiss: (Boolean) -> Unit,
    onOpenPage: (String) -> Unit,
) {
    val latest = info.latest ?: return
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val force = info.forceUpdate
    val newer = info.newerReleases(BuildConfig.VERSION_CODE)
    val displayReleases = if (newer.isEmpty()) listOf(latest) else newer

    var stage by remember(latest.versionCode) { mutableStateOf(UpdateStage.Prompt) }
    var progress by remember(latest.versionCode) { mutableFloatStateOf(0f) }
    var downloadedBytes by remember(latest.versionCode) { mutableLongStateOf(0L) }
    var totalBytes by remember(latest.versionCode) { mutableLongStateOf(0L) }
    var downloadedFile by remember(latest.versionCode) { mutableStateOf<File?>(null) }
    var errorMessage by remember(latest.versionCode) { mutableStateOf<String?>(null) }
    var job by remember(latest.versionCode) { mutableStateOf<Job?>(null) }

    fun startDownload() {
        if (latest.downloadUrl.isBlank()) {
            errorMessage = "更新链接为空，请联系管理员。"
            stage = UpdateStage.Error
            return
        }
        stage = UpdateStage.Downloading
        progress = 0f
        downloadedBytes = 0L
        totalBytes = 0L
        errorMessage = null
        job?.cancel()
        job = scope.launch {
            try {
                val file = ApkDownloader.download(context, latest.downloadUrl) { downloaded, total ->
                    downloadedBytes = downloaded
                    totalBytes = total
                    progress = if (total > 0) {
                        (downloaded.toFloat() / total.toFloat()).coerceIn(0f, 1f)
                    } else {
                        0f
                    }
                }
                downloadedFile = file
                stage = UpdateStage.Downloaded
            } catch (exception: Exception) {
                errorMessage = exception.message ?: "下载失败，请重试。"
                stage = UpdateStage.Error
            }
        }
    }

    fun openUpdatePage() {
        if (latest.downloadUrl.isBlank()) {
            errorMessage = "更新链接为空，请联系管理员。"
            stage = UpdateStage.Error
            return
        }
        onOpenPage(latest.downloadUrl)
        if (force) {
            stage = UpdateStage.PageOpened
        } else {
            onDismiss(false)
        }
    }

    DisposableEffect(Unit) {
        onDispose { job?.cancel() }
    }

    when (stage) {
        UpdateStage.Prompt -> {
            AlertDialog(
                onDismissRequest = { if (!force) onDismiss(true) },
                icon = { Icon(Icons.Outlined.Download, contentDescription = null) },
                title = { Text("发现新版本 ${latest.versionName}") },
                text = {
                    Column {
                        if (force) {
                            Surface(
                                color = MaterialTheme.colorScheme.errorContainer,
                                shape = MaterialTheme.shapes.medium,
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(
                                    "此版本为强制更新，必须完成更新后才能继续使用。",
                                    modifier = Modifier.padding(12.dp),
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    style = MaterialTheme.typography.bodyMedium,
                                )
                            }
                            Spacer(Modifier.height(12.dp))
                        }
                        Text(
                            "当前版本 ${BuildConfig.VERSION_NAME}  →  最新版本 ${latest.versionName}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("累计更新内容", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        CumulativeChangelog(displayReleases)
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (latest.directDownload) {
                                "将直接下载 APK 安装包，并显示下载进度。"
                            } else {
                                "将通过更新页面下载安装包。"
                            },
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.outline,
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        if (latest.directDownload) startDownload() else openUpdatePage()
                    }) {
                        Text(if (latest.directDownload) "立即更新" else "打开更新页面")
                    }
                },
                dismissButton = if (!force) {
                    { TextButton(onClick = { onDismiss(true) }) { Text("下次更新") } }
                } else {
                    null
                },
            )
        }

        UpdateStage.Downloading -> {
            val percent = (progress * 100).toInt()
            AlertDialog(
                onDismissRequest = {},
                title = { Text("正在下载更新") },
                text = {
                    Column {
                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(10.dp))
                        Text(
                            if (totalBytes > 0) {
                                "$percent% · ${formatBytes(downloadedBytes)} / ${formatBytes(totalBytes)}"
                            } else {
                                "正在连接下载源… ${formatBytes(downloadedBytes)}"
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                confirmButton = {},
                dismissButton = if (!force) {
                    {
                        TextButton(onClick = {
                            job?.cancel()
                            stage = UpdateStage.Prompt
                        }) { Text("取消") }
                    }
                } else {
                    null
                },
            )
        }

        UpdateStage.Downloaded -> {
            AlertDialog(
                onDismissRequest = { if (!force) onDismiss(true) },
                title = { Text("更新包已下载") },
                text = {
                    Column {
                        Text("安装包已下载完成，点击下方按钮安装更新。")
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "若无法安装，请允许 lxlovo 安装未知应用后再次点击安装。",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.outline,
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val file = downloadedFile
                        if (file != null) {
                            val launched = installApk(context, file)
                            if (launched && !force) onDismiss(false)
                        }
                    }) {
                        Text("安装更新")
                    }
                },
                dismissButton = if (!force) {
                    { TextButton(onClick = { onDismiss(true) }) { Text("下次更新") } }
                } else {
                    null
                },
            )
        }

        UpdateStage.Error -> {
            AlertDialog(
                onDismissRequest = { if (!force) onDismiss(true) },
                title = { Text("更新失败") },
                text = {
                    Text(errorMessage ?: "下载失败，请重试。")
                },
                confirmButton = {
                    Button(onClick = {
                        if (latest.directDownload) startDownload() else openUpdatePage()
                    }) {
                        Text("重试")
                    }
                },
                dismissButton = if (!force) {
                    { TextButton(onClick = { onDismiss(true) }) { Text("下次更新") } }
                } else {
                    null
                },
            )
        }

        UpdateStage.PageOpened -> {
            AlertDialog(
                onDismissRequest = {},
                title = { Text("等待完成更新") },
                text = {
                    Text("已打开更新页面。请完成安装后重新打开 lxlovo。此版本为强制更新，不能跳过。")
                },
                confirmButton = {
                    Button(onClick = { openUpdatePage() }) { Text("再次打开更新页面") }
                },
            )
        }
    }
}

@Composable
private fun CumulativeChangelog(releases: List<AppRelease>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 340.dp)
            .verticalScroll(rememberScrollState()),
    ) {
        releases.forEachIndexed { index, release ->
            if (index > 0) {
                Spacer(Modifier.height(10.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "v${release.versionName}",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (release.isForced) {
                    Spacer(Modifier.width(6.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = MaterialTheme.shapes.small,
                    ) {
                        Text(
                            "强制",
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                        )
                    }
                }
            }
            val lines = release.changelogLines()
            if (lines.isEmpty()) {
                Text(
                    "本次更新暂无说明。",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            } else {
                lines.forEach { line ->
                    Row(modifier = Modifier.padding(top = 3.dp)) {
                        Text("•", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(6.dp))
                        Text(
                            line,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

private fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    return String.format("%.1f MB", kb / 1024)
}
