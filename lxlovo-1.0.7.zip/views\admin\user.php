<?php
$levelInfo = level_progress($profile);
$badges = user_badges((int) $profile['id']);
$isSelf = (int) current_user()['id'] === (int) $profile['id'];
?>
<div class="admin-user-head">
    <div class="admin-user-head__identity">
        <img class="avatar avatar--lg" src="<?= e(avatar_url($profile)) ?>" alt="">
        <div>
            <div class="admin-user-head__name"><h2><?= e($profile['username']) ?></h2><?= badge_html((int) $profile['id'], $profile) ?></div>
            <p>#<?= (int) $profile['id'] ?> · <?= e($profile['email'] ?: '未绑定邮箱') ?> · <?= e(format_date($profile['created_at'], 'Y-m-d H:i')) ?> 注册</p>
            <div class="admin-user-head__chips">
                <span class="status-chip status-chip--<?= $profile['status'] === 'active' ? 'success' : 'danger' ?>"><?= $profile['status'] === 'active' ? '正常' : '已封禁' ?></span>
                <span class="status-chip status-chip--violet"><?= $profile['role'] === 'admin' ? '管理员' : '普通用户' ?></span>
                <span class="status-chip status-chip--neutral">Lv.<?= (int) $profile['level'] ?> <?= e($levelInfo['current']['name']) ?></span>
                <?php if (!empty($profile['email_verified_at'])): ?><span class="status-chip status-chip--success">邮箱已验证</span><?php else: ?><span class="status-chip status-chip--warning">邮箱未验证</span><?php endif; ?>
            </div>
        </div>
    </div>
    <a class="btn btn--tonal btn--sm" href="<?= e(url('user', ['id' => (int) $profile['id']])) ?>" target="_blank"><?= icon('external', '', 17) ?>查看主页</a>
</div>

<div class="admin-grid admin-grid--sidebar">
    <div class="admin-stack">
        <section class="admin-panel">
            <div class="admin-panel__head"><h3>编辑资料</h3><span>用户 ID 不可修改</span></div>
            <form action="<?= e(admin_url('user.update')) ?>" method="post" class="admin-form">
                <?= csrf_field() ?>
                <input type="hidden" name="id" value="<?= (int) $profile['id'] ?>">
                <div class="admin-form-grid">
                    <label class="field"><span class="field__label">用户名</span><span class="field__box"><input type="text" name="username" value="<?= e($profile['username']) ?>" required maxlength="32"></span></label>
                    <label class="field"><span class="field__label">邮箱</span><span class="field__box"><input type="email" name="email" value="<?= e($profile['email']) ?>" maxlength="190"></span></label>
                    <label class="field"><span class="field__label">角色</span><span class="field__box field__box--select"><select name="role"><option value="user" <?= $profile['role'] === 'user' ? 'selected' : '' ?>>普通用户</option><option value="admin" <?= $profile['role'] === 'admin' ? 'selected' : '' ?>>管理员</option></select></span></label>
                    <label class="field"><span class="field__label">状态</span><span class="field__box field__box--select"><select name="status"><option value="active" <?= $profile['status'] === 'active' ? 'selected' : '' ?>>正常</option><option value="banned" <?= $profile['status'] === 'banned' ? 'selected' : '' ?>>封禁</option></select></span></label>
                    <label class="field"><span class="field__label">经验值</span><span class="field__box"><input type="number" name="exp" value="<?= (int) $profile['exp'] ?>" min="0"></span></label>
                    <label class="field"><span class="field__label">金币</span><span class="field__box"><input type="number" name="coins" value="<?= (int) $profile['coins'] ?>" min="0"></span></label>
                    <label class="field field--span-2"><span class="field__label">个人简介</span><span class="field__box field__box--textarea"><textarea name="bio" rows="3" maxlength="500"><?= e($profile['bio']) ?></textarea></span></label>
                    <label class="field"><span class="field__label">重置密码（可选）</span><span class="field__box"><input type="password" name="new_password" minlength="8" maxlength="72" placeholder="留空则不修改"></span></label>
                    <label class="check-line"><input type="checkbox" name="email_verified" value="1" <?= !empty($profile['email_verified_at']) ? 'checked' : '' ?>><span>邮箱标记为已验证</span></label>
                </div>
                <div class="form-actions"><button class="btn btn--primary" type="submit">保存用户资料</button></div>
            </form>
        </section>

        <section class="admin-panel">
            <div class="admin-panel__head"><h3>最近帖子</h3><a href="<?= e(admin_url('posts')) ?>">全部</a></div>
            <div class="table-wrap">
                <table class="data-table">
                    <thead><tr><th>标题</th><th>状态</th><th>数据</th><th>时间</th></tr></thead>
                    <tbody>
                    <?php foreach ($posts as $post): ?>
                        <tr><td><a class="table-title" href="<?= e(url('post', ['id' => (int) $post['id']])) ?>" target="_blank"><?= e($post['title']) ?></a></td><td><span class="status-chip status-chip--neutral"><?= e($post['status']) ?></span></td><td><?= (int) $post['views'] ?> 阅 · <?= (int) $post['likes_count'] ?> 赞</td><td><?= e(time_ago($post['created_at'])) ?></td></tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if (!$posts): ?><div class="admin-empty">暂无帖子。</div><?php endif; ?>
            </div>
        </section>

        <section class="admin-panel">
            <div class="admin-panel__head"><h3>最近评论</h3><a href="<?= e(admin_url('comments')) ?>">全部</a></div>
            <div class="admin-list">
                <?php foreach ($comments as $comment): ?>
                    <div class="admin-list__item">
                        <span class="admin-list__body"><strong><?= e(text_excerpt($comment['content'], 80)) ?></strong><span>在《<?= e($comment['post_title'] ?: '已删除帖子') ?>》 · <?= e(time_ago($comment['created_at'])) ?></span></span>
                        <form action="<?= e(admin_url('comment.delete')) ?>" method="post" data-confirm="确定删除这条评论吗？"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int) $comment['id'] ?>"><button class="table-action table-action--danger" type="submit">删除</button></form>
                    </div>
                <?php endforeach; ?>
                <?php if (!$comments): ?><div class="admin-empty">暂无评论。</div><?php endif; ?>
            </div>
        </section>
    </div>

    <aside class="admin-stack">
        <section class="admin-panel">
            <div class="admin-panel__head"><h3>账号数据</h3></div>
            <div class="admin-mini-stats">
                <div><strong><?= (int) $stats['posts'] ?></strong><span>帖子</span></div>
                <div><strong><?= (int) $stats['comments'] ?></strong><span>评论</span></div>
                <div><strong><?= (int) $stats['checkins'] ?></strong><span>签到</span></div>
            </div>
            <div class="admin-kv"><span>连续签到</span><strong><?= (int) $profile['checkin_streak'] ?> 天</strong></div>
            <div class="admin-kv"><span>最后活跃</span><strong><?= e($profile['last_active_at'] ? time_ago($profile['last_active_at']) : '—') ?></strong></div>
            <div class="admin-kv"><span>板块职务</span><strong><?= $boards ? count($boards) . ' 个' : '—' ?></strong></div>
            <?php foreach ($boards as $board): ?><div class="admin-kv"><span><?= e($board['name']) ?></span><strong><?= $board['role'] === 'owner' ? '板块主' : '副板块主' ?></strong></div><?php endforeach; ?>
        </section>

        <section class="admin-panel">
            <div class="admin-panel__head"><h3>认证</h3><span><?= count($badges) ?> 个</span></div>
            <?php if ($badges): ?>
                <div class="cert-list cert-list--stack">
                    <?php foreach ($badges as $badge): ?>
                        <div class="admin-cert-row">
                            <span class="verify-badge verify-badge--<?= e($badge['type']) ?>" style="--badge-color:<?= e($badge['color']) ?>"><?= icon('verified') ?><span><?= e($badge['name']) ?></span></span>
                            <form action="<?= e(admin_url('user.cert.remove')) ?>" method="post" data-confirm="确定移除这个认证吗？"><?= csrf_field() ?><input type="hidden" name="user_id" value="<?= (int) $profile['id'] ?>"><input type="hidden" name="cert_id" value="<?= (int) $badge['id'] ?>"><button class="icon-btn icon-btn--tiny" type="submit" aria-label="移除"><?= icon('close', '', 16) ?></button></form>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?><p class="admin-empty">暂无认证。</p><?php endif; ?>
            <form action="<?= e(admin_url('user.cert')) ?>" method="post" class="admin-inline-form">
                <?= csrf_field() ?>
                <input type="hidden" name="user_id" value="<?= (int) $profile['id'] ?>">
                <select name="cert_id" required>
                    <option value="">选择认证</option>
                    <?php foreach ($certs as $cert): ?><option value="<?= (int) $cert['id'] ?>"><?= e($cert['name']) ?>（<?= e($cert['type']) ?>）</option><?php endforeach; ?>
                </select>
                <button class="btn btn--tonal btn--sm" type="submit">授予</button>
            </form>
        </section>

        <section class="admin-panel">
            <div class="admin-panel__head"><h3>发送系统消息</h3></div>
            <form action="<?= e(admin_url('user.notify')) ?>" method="post" class="admin-form">
                <?= csrf_field() ?>
                <input type="hidden" name="user_id" value="<?= (int) $profile['id'] ?>">
                <label class="field"><span class="field__label">消息内容</span><span class="field__box field__box--textarea"><textarea name="message" rows="4" maxlength="500" placeholder="发送给该用户的系统通知…" required></textarea></span></label>
                <button class="btn btn--primary btn--sm btn--full" type="submit"><?= icon('send', '', 16) ?>发送</button>
            </form>
        </section>

        <?php if ($applications): ?>
            <section class="admin-panel">
                <div class="admin-panel__head"><h3>认证申请</h3><a href="<?= e(admin_url('applications')) ?>">审核</a></div>
                <div class="admin-list">
                    <?php foreach ($applications as $application): ?>
                        <div class="admin-list__item"><span class="admin-list__body"><strong><?= $application['type'] === 'sponsor' ? '赞助认证' : '用户认证' ?></strong><span><?= e(time_ago($application['created_at'])) ?> · <?= e($application['status']) ?></span></span></div>
                    <?php endforeach; ?>
                </div>
            </section>
        <?php endif; ?>
    </aside>
</div>
