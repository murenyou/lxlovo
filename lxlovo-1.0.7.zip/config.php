<?php
/**
 * lxlovo 绀惧尯閰嶇疆鏂囦欢
 * 閮ㄧ讲鍒板疂濉旈潰鏉垮悗锛屽彧闇€瑕佷慨鏀硅繖閲岀殑鏁版嵁搴撲俊鎭嵆鍙€? */
return [
    'db' => [
        'host' => '127.0.0.1',
        'port' => 3306,
        'name' => 'bbs_lxlovo_top',
        'user' => 'bbs_lxlovo_top',
        'pass' => 'lxl207803',
        'charset' => 'utf8mb4',
    ],
    'app' => [
        'debug' => false,
        'timezone' => 'Asia/Shanghai',
        'session_name' => 'lxlovo_session',
        'site_url' => '',
        'upload_dir' => __DIR__ . '/uploads',
        'upload_url' => 'uploads',
        'version' => '1.0.7',
    ],
];

