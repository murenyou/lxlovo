<?php
$themeSetting = setting('theme_default', 'light');
if (!in_array($themeSetting, ['light', 'dark', 'system'], true)) {
    $themeSetting = 'light';
}
$adminRoute = (string) ($_GET['r'] ?? 'dashboard');
$adminGroups = [
    '概览' => [
        ['dashboard', '控制台', 'admin'],
    ],
    '内容' => [
        ['posts', '帖子', 'article'],
        ['comments', '评论', 'comment'],
        ['boards', '板块', 'board'],
        ['carousels', '轮播图', 'image'],
        ['announcements', '公告', 'mega'],
    ],
    '用户' => [
        ['users', '用户', 'users'],
        ['applications', '认证审核', 'shield'],
        ['certifications', '认证配置', 'verified'],
    ],
    '站点' => [
        ['navigation', '快捷栏', 'grid'],
        ['links', '友情链接', 'link'],
        ['levels', '用户等级', 'star'],
        ['rewards', '签到奖励', 'gift'],
    ],
    '系统' => [
        ['settings', '站点设置', 'settings'],
        ['app', 'App 管理', 'phone'],
        ['broadcast', '系统广播', 'send'],
    ],
];
?>
<!doctype html>
<html lang="zh-CN" data-theme="light" data-theme-mode="<?= e($themeSetting) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#fbf8ff">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <title><?= e($adminPageTitle ?? '后台') ?> · <?= e(setting('site_name')) ?> 管理后台</title>
    <script>
    (function () {
        try {
            var mode = localStorage.getItem('lxlovo-theme') || <?= json_encode($themeSetting) ?>;
            var dark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
            document.documentElement.dataset.theme = dark ? 'dark' : 'light';
            document.documentElement.dataset.themeMode = mode;
        } catch (e) {}
    })();
    </script>
    <link rel="icon" type="image/png" sizes="64x64" href="<?= e(asset('assets/img/favicon.png')) ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?= e(asset('assets/img/apple-touch-icon.png')) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>?v=<?= e(LXL_VERSION) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/css/admin.css')) ?>?v=<?= e(LXL_VERSION) ?>">
</head>
<body class="admin-body" data-route="<?= e($adminRoute) ?>" data-base="<?= e(base_url()) ?>">
<div class="admin-shell">
    <div class="admin-scrim" data-admin-menu-close hidden></div>
    <aside class="admin-sidebar" id="admin-sidebar">
        <div class="admin-sidebar__brand">
            <a class="brand brand--admin" href="<?= e(admin_url()) ?>">
                <span class="brand__glyph">l</span>
                <span class="brand__text">lxlovo<span class="admin-badge">ADMIN</span></span>
            </a>
            <button class="icon-btn admin-sidebar__close" type="button" data-admin-menu-close aria-label="关闭菜单"><?= icon('close') ?></button>
        </div>
        <nav class="admin-nav">
            <?php foreach ($adminGroups as $group => $items): ?>
                <p class="admin-nav__group"><?= e($group) ?></p>
                <?php foreach ($items as [$itemRoute, $label, $iconName]): ?>
                    <?php
                    $isActive = $adminRoute === $itemRoute
                        || ($itemRoute === 'users' && $adminRoute === 'user')
                        || ($itemRoute === 'boards' && $adminRoute === 'board');
                    ?>
                    <a class="admin-nav__link<?= $isActive ? ' is-active' : '' ?>" href="<?= e(admin_url($itemRoute)) ?>">
                        <?= icon($iconName, '', 20) ?><span><?= e($label) ?></span>
                        <?php if ($itemRoute === 'applications'): ?>
                            <?php $pendingCount = (int) db_value("SELECT COUNT(*) FROM verify_applications WHERE status = 'pending'", [], 0); ?>
                            <?php if ($pendingCount > 0): ?><span class="admin-nav__count"><?= $pendingCount ?></span><?php endif; ?>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </nav>
        <div class="admin-sidebar__foot">
            <a class="admin-nav__link" href="<?= e(url('home')) ?>"><?= icon('external', '', 20) ?><span>访问前台</span></a>
            <form action="<?= e(url('logout')) ?>" method="post">
                <?= csrf_field() ?>
                <button class="admin-nav__link" type="submit"><?= icon('logout', '', 20) ?><span>退出登录</span></button>
            </form>
        </div>
    </aside>

    <div class="admin-main">
        <header class="admin-topbar">
            <div class="admin-topbar__left">
                <button class="icon-btn admin-menu-btn" type="button" data-admin-menu-open aria-label="打开管理菜单"><?= icon('menu') ?></button>
                <div>
                    <span class="admin-topbar__eyebrow">lxlovo 管理后台</span>
                    <h1><?= e($adminPageTitle ?? '控制台') ?></h1>
                </div>
            </div>
            <div class="admin-topbar__actions">
                <a class="admin-user" href="<?= e(url('me')) ?>">
                    <img class="avatar avatar--xs" src="<?= e(avatar_url($currentUser)) ?>" alt="">
                    <span><?= e($currentUser['username']) ?></span>
                </a>
                <details class="menu theme-menu">
                    <summary class="icon-btn" aria-label="切换主题"><?= icon('light', 'theme-icon theme-icon--light', 21) ?><?= icon('dark', 'theme-icon theme-icon--dark', 21) ?></summary>
                    <div class="menu__panel theme-menu__panel">
                        <p class="menu__label">外观</p>
                        <button type="button" class="menu__item" data-theme-set="light"><?= icon('light') ?><span>白天</span></button>
                        <button type="button" class="menu__item" data-theme-set="dark"><?= icon('dark') ?><span>夜晚</span></button>
                        <button type="button" class="menu__item" data-theme-set="system"><?= icon('system') ?><span>跟随系统</span></button>
                    </div>
                </details>
            </div>
        </header>

        <main class="admin-content">
            <?php if ($flashes): ?>
                <div class="flash-stack" role="status" aria-live="polite">
                    <?php foreach ($flashes as $flash): ?>
                        <div class="flash flash--<?= e($flash['type']) ?>">
                            <?= icon($flash['type'] === 'success' ? 'check' : ($flash['type'] === 'error' ? 'info' : 'notifications'), '', 20) ?>
                            <span><?= e($flash['message']) ?></span>
                            <button class="icon-btn icon-btn--tiny" type="button" data-dismiss="flash" aria-label="关闭"><?= icon('close', '', 18) ?></button>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <?= $content ?>
        </main>
        <footer class="admin-footer">lxlovo admin · <?= date('Y') ?> · 开源免费</footer>
    </div>
</div>
<script>
window.LXL = {
    base: <?= json_encode(base_url()) ?>,
    csrf: <?= json_encode(csrf_token()) ?>,
    isLoggedIn: true,
    routes: {
        like: <?= json_encode(url('post.like')) ?>,
        favorite: <?= json_encode(url('post.favorite')) ?>,
        upload: <?= json_encode(url('upload.image')) ?>,
        announcementSeen: <?= json_encode(url('announcement.seen')) ?>
    }
};
</script>
<script src="<?= e(asset('assets/js/app.js')) ?>?v=<?= e(LXL_VERSION) ?>" defer></script>
</body>
</html>
