<?php
$buildUrl = fn (int $page): string => url('favorites', ['page' => $page]);
?>
<section class="page-head page-head--compact">
    <div><span class="page-head__eyebrow">Saved</span><h1>我的收藏</h1><p>共 <?= (int) $total ?> 篇收藏，随时回来继续阅读。</p></div>
    <a class="btn btn--outlined" href="<?= e(url('me')) ?>"><?= icon('arrow_back', '', 18) ?>返回我的</a>
</section>
<?php if ($posts): ?>
    <div class="post-grid">
        <?php foreach ($posts as $post): ?>
            <?php $showBoard = true; $compact = false; require LXL_VIEWS . '/partials/post-card.php'; ?>
        <?php endforeach; ?>
    </div>
    <?= pager((int) $total, (int) $per, (int) $page, $buildUrl) ?>
<?php else: ?>
    <div class="empty-state"><?= icon('bookmark', '', 38) ?><h3>还没有收藏</h3><p>在文章底部点击收藏，就能在这里找到它。</p><a class="btn btn--primary" href="<?= e(url('posts')) ?>">去阅读</a></div>
<?php endif; ?>
