package com.bbs.lxlovo.top.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.bbs.lxlovo.top.data.ApiClient
import com.bbs.lxlovo.top.data.Post
import com.bbs.lxlovo.top.data.PostPage
import com.bbs.lxlovo.top.ui.EmptyBox
import com.bbs.lxlovo.top.ui.ErrorBox
import com.bbs.lxlovo.top.ui.LoadingBox
import com.bbs.lxlovo.top.ui.PostCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostCollectionScreen(
    api: ApiClient,
    title: String,
    loader: suspend (Int) -> PostPage,
    onBack: () -> Unit,
    onPostClick: (Int) -> Unit,
    onUserClick: (Int) -> Unit,
) {
    var posts by remember { mutableStateOf<List<Post>>(emptyList()) }
    var page by remember { mutableIntStateOf(1) }
    var pages by remember { mutableIntStateOf(1) }
    var loading by remember { mutableStateOf(true) }
    var loadingMore by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(retry) {
        loading = true
        error = null
        page = 1
        try {
            val result = loader(1)
            posts = result.items
            pages = result.pages
            page = result.page
        } catch (exception: Exception) {
            error = exception.message ?: "加载失败。"
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Outlined.ArrowBack, contentDescription = "返回")
                    }
                },
            )
        },
    ) { padding ->
        when {
            loading && posts.isEmpty() -> LoadingBox(Modifier.padding(padding))
            error != null && posts.isEmpty() -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                ErrorBox(error!!) { retry++ }
            }
            posts.isEmpty() -> EmptyBox("暂无内容", Modifier.fillMaxSize().padding(padding))
            else -> LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                items(posts, key = { it.id }) { post ->
                    PostCard(post, { onPostClick(post.id) }, onUserClick)
                }
                item {
                    if (page < pages) {
                        Box(Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                            if (loadingMore) {
                                CircularProgressIndicator(Modifier.padding(4.dp), strokeWidth = 2.dp)
                            } else {
                                TextButton(onClick = {
                                    if (!loadingMore) {
                                        loadingMore = true
                                        scope.launch {
                                            try {
                                                val next = page + 1
                                                val result = loader(next)
                                                posts = posts + result.items.filter { item -> posts.none { it.id == item.id } }
                                                page = result.page
                                                pages = result.pages
                                            } catch (exception: Exception) {
                                                error = exception.message
                                            } finally {
                                                loadingMore = false
                                            }
                                        }
                                    }
                                }) { Text("加载更多") }
                            }
                        }
                    } else {
                        Text(
                            "已经到底了",
                            modifier = Modifier.fillMaxWidth().padding(16.dp),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.outline,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }
    }
}
