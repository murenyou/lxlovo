<?php
$siteName = setting('site_name', 'lxlovo');
$siteTagline = setting('site_tagline', '');
$route = (string) ($_GET['r'] ?? 'home');
$layoutUser = $currentUser ?? current_user();
$navLinks = db_all('SELECT * FROM nav_links WHERE enabled = 1 ORDER BY sort ASC, id ASC');
$footerLinks = db_all('SELECT * FROM friend_links WHERE enabled = 1 ORDER BY sort ASC, id ASC LIMIT 8');
$announcements = displayable_announcements();
$unreadNotifications = $layoutUser ? notification_count((int) $layoutUser['id']) : 0;
$unreadMessages = $layoutUser ? unread_message_count((int) $layoutUser['id']) : 0;
$activeNav = function (string $target) use ($route): bool {
    if ($route === $target) {
        return true;
    }
    if ($target === 'posts' && in_array($route, ['post', 'board', 'publish'], true)) {
        return true;
    }
    return false;
};
$themeSetting = setting('theme_default', 'light');
if (!in_array($themeSetting, ['light', 'dark', 'system'], true)) {
    $themeSetting = 'light';
}
?>
<!doctype html>
<html lang="zh-CN" data-theme="light" data-theme-mode="<?= e($themeSetting) ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="theme-color" content="#fbf8ff" media="(prefers-color-scheme: light)">
    <meta name="theme-color" content="#131318" media="(prefers-color-scheme: dark)">
    <meta name="csrf-token" content="<?= e(csrf_token()) ?>">
    <meta name="description" content="<?= e($pageDescription ?? setting('site_description')) ?>">
    <meta name="keywords" content="<?= e(setting('site_keywords')) ?>">
    <meta property="og:site_name" content="<?= e($siteName) ?>">
    <meta property="og:title" content="<?= e($pageTitle ?? $siteName) ?>">
    <meta property="og:description" content="<?= e($pageDescription ?? setting('site_description')) ?>">
    <meta property="og:type" content="website">
    <title><?= e($pageTitle ?? $siteName) ?></title>
    <script>
    (function () {
        try {
            var mode = localStorage.getItem('lxlovo-theme') || <?= json_encode($themeSetting) ?>;
            var dark = mode === 'dark' || (mode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
            document.documentElement.dataset.theme = dark ? 'dark' : 'light';
            document.documentElement.dataset.themeMode = mode;
        } catch (e) {}
    })();
    </script>
    <link rel="icon" type="image/png" sizes="64x64" href="<?= e(asset('assets/img/favicon.png')) ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?= e(asset('assets/img/apple-touch-icon.png')) ?>">
    <link rel="stylesheet" href="<?= e(asset('assets/css/app.css')) ?>?v=<?= e(LXL_VERSION) ?>">
</head>
<body class="<?= e($bodyClass ?? '') ?>" data-route="<?= e($route) ?>" data-base="<?= e(base_url()) ?>">
<a class="skip-link" href="#main">跳到主要内容</a>

<header class="app-bar">
    <div class="app-bar__inner">
        <button class="icon-btn app-bar__menu" type="button" data-drawer-open aria-label="打开导航">
            <?= icon('menu', '', 24) ?>
        </button>
        <a class="brand" href="<?= e(url('home')) ?>" aria-label="<?= e($siteName) ?> 首页">
            <span class="brand__glyph" aria-hidden="true">l</span>
            <span class="brand__text"><?= e($siteName) ?></span>
        </a>

        <nav class="nav-links" aria-label="主导航">
            <?php foreach ($navLinks as $link): ?>
                <?php
                $linkRoute = '';
                if (preg_match('/[?&]r=([^&]+)/', $link['url'], $m)) {
                    $linkRoute = urldecode($m[1]);
                }
                $isActive = $linkRoute !== '' && $activeNav($linkRoute);
                ?>
                <a class="nav-link<?= $isActive ? ' is-active' : '' ?>" href="<?= e($link['url']) ?>"><?= e($link['label']) ?></a>
            <?php endforeach; ?>
        </nav>

        <form class="top-search" action="<?= e(url('search')) ?>" method="get" role="search">
            <input type="hidden" name="r" value="search">
            <?= icon('search', 'top-search__icon', 19) ?>
            <input type="search" name="q" value="<?= e($_GET['q'] ?? '') ?>" placeholder="搜索帖子、用户…" aria-label="全局搜索" maxlength="80">
        </form>

        <div class="app-bar__actions">
            <button class="icon-btn top-search__mobile" type="button" data-open-search aria-label="搜索">
                <?= icon('search', '', 22) ?>
            </button>
            <details class="menu theme-menu">
                <summary class="icon-btn" aria-label="切换主题" title="主题">
                    <?= icon('light', 'theme-icon theme-icon--light', 22) ?>
                    <?= icon('dark', 'theme-icon theme-icon--dark', 22) ?>
                </summary>
                <div class="menu__panel theme-menu__panel">
                    <p class="menu__label">外观</p>
                    <button type="button" class="menu__item" data-theme-set="light"><?= icon('light') ?><span>白天</span></button>
                    <button type="button" class="menu__item" data-theme-set="dark"><?= icon('dark') ?><span>夜晚</span></button>
                    <button type="button" class="menu__item" data-theme-set="system"><?= icon('system') ?><span>跟随系统</span></button>
                </div>
            </details>
            <?php if ($layoutUser): ?>
                <a class="icon-btn notification-btn" href="<?= e(url('notifications')) ?>" aria-label="通知">
                    <?= icon('notifications', '', 22) ?>
                    <?php if ($unreadNotifications > 0): ?><span class="count-dot"><?= $unreadNotifications > 99 ? '99+' : $unreadNotifications ?></span><?php endif; ?>
                </a>
                <a class="icon-btn hide-sm" href="<?= e(url('messages')) ?>" aria-label="私信">
                    <?= icon('mail', '', 22) ?>
                    <?php if ($unreadMessages > 0): ?><span class="count-dot"><?= $unreadMessages > 99 ? '99+' : $unreadMessages ?></span><?php endif; ?>
                </a>
                <details class="menu user-menu">
                    <summary class="user-chip" aria-label="账号菜单">
                        <img class="avatar avatar--xs" src="<?= e(avatar_url($layoutUser)) ?>" alt="">
                        <span class="user-chip__name hide-sm"><?= e($layoutUser['username']) ?></span>
                    </summary>
                    <div class="menu__panel user-menu__panel">
                        <div class="user-menu__head">
                            <img class="avatar avatar--sm" src="<?= e(avatar_url($layoutUser)) ?>" alt="">
                            <div><strong><?= e($layoutUser['username']) ?></strong><span>ID <?= (int) $layoutUser['id'] ?></span></div>
                        </div>
                        <a class="menu__item" href="<?= e(url('me')) ?>"><?= icon('person') ?><span>我的</span></a>
                        <a class="menu__item" href="<?= e(url('settings')) ?>"><?= icon('settings') ?><span>设置</span></a>
                        <a class="menu__item" href="<?= e(url('my_posts')) ?>"><?= icon('article') ?><span>我的文章</span></a>
                        <a class="menu__item" href="<?= e(url('favorites')) ?>"><?= icon('bookmark') ?><span>我的收藏</span></a>
                        <?php if (is_admin($layoutUser)): ?>
                            <a class="menu__item" href="<?= e(admin_url()) ?>"><?= icon('admin') ?><span>管理后台</span></a>
                        <?php endif; ?>
                        <div class="menu__divider"></div>
                        <form action="<?= e(url('logout')) ?>" method="post">
                            <?= csrf_field() ?>
                            <button class="menu__item menu__item--danger" type="submit"><?= icon('logout') ?><span>退出登录</span></button>
                        </form>
                    </div>
                </details>
            <?php else: ?>
                <a class="btn btn--tonal btn--sm hide-xs" href="<?= e(url('login')) ?>">登录</a>
                <a class="btn btn--primary btn--sm hide-xs" href="<?= e(url('register')) ?>">注册</a>
            <?php endif; ?>
        </div>
    </div>
</header>

<div class="drawer-scrim" data-drawer-close hidden></div>
<aside class="drawer" id="site-drawer" aria-label="移动导航" aria-hidden="true">
    <div class="drawer__head">
        <a class="brand" href="<?= e(url('home')) ?>"><span class="brand__glyph">l</span><span class="brand__text"><?= e($siteName) ?></span></a>
        <button class="icon-btn" type="button" data-drawer-close aria-label="关闭导航"><?= icon('close') ?></button>
    </div>
    <?php if ($layoutUser): ?>
        <a class="drawer__profile" href="<?= e(url('me')) ?>">
            <img class="avatar avatar--md" src="<?= e(avatar_url($layoutUser)) ?>" alt="">
            <div><strong><?= e($layoutUser['username']) ?></strong><span><?= e(level_for_user($layoutUser)['name']) ?> · ID <?= (int) $layoutUser['id'] ?></span></div>
            <?= icon('chevron_right') ?>
        </a>
    <?php else: ?>
        <div class="drawer__auth">
            <a class="btn btn--primary" href="<?= e(url('login')) ?>">登录</a>
            <a class="btn btn--outlined" href="<?= e(url('register')) ?>">注册</a>
        </div>
    <?php endif; ?>
    <nav class="drawer__nav">
        <?php foreach ($navLinks as $link): ?>
            <?php
            $linkRoute = '';
            if (preg_match('/[?&]r=([^&]+)/', $link['url'], $m)) {
                $linkRoute = urldecode($m[1]);
            }
            ?>
            <a class="drawer__link<?= $linkRoute !== '' && $activeNav($linkRoute) ? ' is-active' : '' ?>" href="<?= e($link['url']) ?>">
                <?= icon($link['icon'] ?: 'link', '', 22) ?><span><?= e($link['label']) ?></span>
            </a>
        <?php endforeach; ?>
        <a class="drawer__link<?= $activeNav('me') ? ' is-active' : '' ?>" href="<?= e(url('me')) ?>"><?= icon('person', '', 22) ?><span>我的</span></a>
        <a class="drawer__link" href="<?= e(url('links')) ?>"><?= icon('link', '', 22) ?><span>友情链接</span></a>
        <a class="drawer__link" href="<?= e(url('about')) ?>"><?= icon('info', '', 22) ?><span>关于</span></a>
    </nav>
    <div class="drawer__foot">
        <p><?= e($siteName) ?> · <?= e($siteTagline) ?></p>
        <span><?= date('Y') ?> · lxlovo</span>
    </div>
    <div class="drawer__theme">
        <span>外观</span>
        <div>
            <button type="button" data-theme-set="light"><?= icon('light', '', 17) ?>白天</button>
            <button type="button" data-theme-set="dark"><?= icon('dark', '', 17) ?>夜晚</button>
            <button type="button" data-theme-set="system"><?= icon('system', '', 17) ?>跟随系统</button>
        </div>
    </div>
</aside>

<main class="site-main" id="main">
    <?php if ($flashes): ?>
        <div class="flash-stack" role="status" aria-live="polite">
            <?php foreach ($flashes as $flash): ?>
                <div class="flash flash--<?= e($flash['type']) ?>">
                    <?= icon($flash['type'] === 'success' ? 'check' : ($flash['type'] === 'error' ? 'info' : 'notifications'), '', 20) ?>
                    <span><?= e($flash['message']) ?></span>
                    <button class="icon-btn icon-btn--tiny" type="button" data-dismiss="flash" aria-label="关闭"><?= icon('close', '', 18) ?></button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?= $content ?>
</main>

<footer class="site-footer">
    <div class="site-footer__inner">
        <div class="site-footer__brand">
            <a class="brand" href="<?= e(url('home')) ?>"><span class="brand__glyph">l</span><span class="brand__text"><?= e($siteName) ?></span></a>
            <p><?= e($siteTagline) ?></p>
            <p class="site-footer__desc"><?= e(setting('site_description')) ?></p>
        </div>
        <div class="site-footer__col">
            <h3>探索</h3>
            <?php foreach (array_slice($navLinks, 0, 5) as $link): ?>
                <a href="<?= e($link['url']) ?>"><?= e($link['label']) ?></a>
            <?php endforeach; ?>
            <a href="<?= e(url('online')) ?>">在线用户</a>
        </div>
        <div class="site-footer__col">
            <h3>友链</h3>
            <?php foreach (array_slice($footerLinks, 0, 5) as $link): ?>
                <a href="<?= e($link['url']) ?>" target="_blank" rel="noopener"><?= e($link['name']) ?></a>
            <?php endforeach; ?>
            <a href="<?= e(url('links')) ?>">全部友链</a>
        </div>
        <div class="site-footer__col">
            <h3>关于</h3>
            <a href="<?= e(url('about')) ?>">关于我们</a>
            <a href="<?= e(url('verify')) ?>">账号认证</a>
            <a href="<?= e(url('settings')) ?>">账号设置</a>
            <?php if ($layoutUser && is_admin($layoutUser)): ?><a href="<?= e(admin_url()) ?>">管理后台</a><?php endif; ?>
        </div>
    </div>
    <div class="site-footer__bottom">
        <div>
            © <?= date('Y') ?> <a href="https://bbs.lxlovo.top" target="_blank" rel="noopener">lxlovo</a> by <a href="https://qm.qq.com/q/Glc9lMTqMi" target="_blank" rel="noopener">夭获</a>
            <?php if (setting('filing_info') !== ''): ?><span class="footer-dot">·</span><span><?= e(setting('filing_info')) ?></span><?php endif; ?>
        </div>
        <div class="site-footer__meta">
            <?php if (setting('footer_extra') !== ''): ?><span><?= e(setting('footer_extra')) ?></span><?php endif; ?>
            <span>开放 · 自由 · 原创</span>
        </div>
    </div>
</footer>

<nav class="mobile-tabbar" aria-label="移动端主导航">
    <a class="mobile-tab<?= $activeNav('home') ? ' is-active' : '' ?>" href="<?= e(url('home')) ?>">
        <span class="mobile-tab__icon"><?= icon('home', '', 24) ?></span><span>首页</span>
    </a>
    <a class="mobile-tab<?= ($route === 'posts' || $route === 'post' || $route === 'board') ? ' is-active' : '' ?>" href="<?= e(url('posts')) ?>">
        <span class="mobile-tab__icon"><?= icon('article', '', 24) ?></span><span>文章</span>
    </a>
    <a class="mobile-tab<?= $activeNav('me') ? ' is-active' : '' ?>" href="<?= e($layoutUser ? url('me') : url('login')) ?>">
        <span class="mobile-tab__icon"><?= icon('person', '', 24) ?></span><span>我的</span>
    </a>
</nav>

<?php if (!in_array($route, ['publish', 'login', 'register', 'messages', 'settings', 'forgot_password', 'reset_password', 'verify_email', 'posts', 'board', 'boards'], true)): ?>
    <a class="fab" href="<?= e($layoutUser ? url('publish') : url('login', ['next' => url('publish')])) ?>" aria-label="发布文章">
        <?= icon('add', '', 26) ?>
    </a>
<?php endif; ?>

<dialog class="dialog search-dialog" id="search-dialog">
    <div class="dialog__head">
        <h2>全局搜索</h2>
        <button class="icon-btn" type="button" data-close-dialog aria-label="关闭"><?= icon('close') ?></button>
    </div>
    <form action="<?= e(url('search')) ?>" method="get" class="search-dialog__form">
        <input type="hidden" name="r" value="search">
        <label class="field">
            <span class="field__label">搜索帖子、用户或板块</span>
            <span class="field__box"><?= icon('search') ?><input type="search" name="q" placeholder="输入关键词…" autofocus maxlength="80"></span>
        </label>
        <button class="btn btn--primary btn--full" type="submit">搜索</button>
    </form>
</dialog>

<?php if ($announcements): ?>
    <dialog class="dialog announcement-dialog" id="announcement-dialog" data-logged="<?= $layoutUser ? '1' : '0' ?>">
        <div class="dialog__head">
            <div class="dialog__eyebrow"><?= icon('mega', '', 18) ?> 站点公告</div>
            <button class="icon-btn" type="button" data-announcement-close aria-label="关闭公告"><?= icon('close') ?></button>
        </div>
        <div class="announcement-list">
            <?php foreach ($announcements as $announcement): ?>
                <article class="announcement" data-announcement-id="<?= (int) $announcement['id'] ?>" data-mode="<?= e($announcement['display_mode']) ?>">
                    <h2><?= e($announcement['title']) ?></h2>
                    <div class="prose"><?= render_content($announcement['content']) ?></div>
                </article>
            <?php endforeach; ?>
        </div>
        <div class="dialog__actions">
            <button class="btn btn--primary" type="button" data-announcement-close>我知道了</button>
        </div>
    </dialog>
<?php endif; ?>

<script>
window.LXL = {
    base: <?= json_encode(base_url()) ?>,
    csrf: <?= json_encode(csrf_token()) ?>,
    isLoggedIn: <?= $layoutUser ? 'true' : 'false' ?>,
    routes: {
        like: <?= json_encode(url('post.like')) ?>,
        favorite: <?= json_encode(url('post.favorite')) ?>,
        upload: <?= json_encode(url('upload.image')) ?>,
        announcementSeen: <?= json_encode(url('announcement.seen')) ?>
    }
};
</script>
<script src="<?= e(asset('assets/js/app.js')) ?>?v=<?= e(LXL_VERSION) ?>" defer></script>
</body>
</html>
